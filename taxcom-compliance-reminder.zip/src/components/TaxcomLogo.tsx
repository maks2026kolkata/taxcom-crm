import React from 'react';

interface TaxcomLogoProps {
  className?: string;
  iconOnly?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  theme?: 'light' | 'dark';
}

export default function TaxcomLogo({ className = '', iconOnly = false, size = 'md', theme = 'light' }: TaxcomLogoProps) {
  // Height classes for the horizontal brand image
  const heights = {
    sm: 'h-7 md:h-8',
    md: 'h-9 md:h-10',
    lg: 'h-14 md:h-16',
    xl: 'h-24 md:h-28',
  };

  // Red circle with white "t" size mapping for iconOnly/avatar modes
  const iconSizes = {
    sm: 'w-7.5 h-6.5 text-[15px]',
    md: 'w-9.5 h-8 text-lg',
    lg: 'w-14 h-12 text-3xl',
    xl: 'w-24 h-20 text-5xl',
  };

  const currentHeight = heights[size];
  const currentIconSize = iconSizes[size];

  // Render iconOnly mode (the red brand oval)
  if (iconOnly) {
    return (
      <div 
        className={`${currentIconSize} rounded-[48%] bg-[#FF2D37] flex items-center justify-center text-white font-black leading-none shrink-0 shadow-xs select-none ${className}`}
        style={{ fontFamily: '"Inter", sans-serif' }}
      >
        <span className="transform -translate-y-[1px] -translate-x-[0.5px]">t</span>
      </div>
    );
  }

  // Render full logo using official PNG link
  return (
    <div className={`inline-flex items-center select-none ${className}`}>
      {theme === 'dark' ? (
        // For dark backgrounds, wrap the brand in a premium, ultra-clean white pill-capsule 
        // to maintain perfect legibility, contrast, and professional logo presentation.
        <div className="bg-white px-3.5 py-1.5 rounded-xl shadow-xs border border-slate-200/50 flex items-center justify-center">
          <img 
            src="https://i.ibb.co/gLhKZT3z/TAXCOM.png" 
            alt="Taxcom Technologies Logo"
            className={`${currentHeight} w-auto object-contain pointer-events-none select-none`}
            style={{ pointerEvents: 'none', userSelect: 'none' }}
            draggable={false}
            onContextMenu={(e) => e.preventDefault()}
            referrerPolicy="no-referrer"
          />
        </div>
      ) : (
        <img 
          src="https://i.ibb.co/gLhKZT3z/TAXCOM.png" 
          alt="Taxcom Technologies Logo"
          className={`${currentHeight} w-auto object-contain pointer-events-none select-none`}
          style={{ pointerEvents: 'none', userSelect: 'none' }}
          draggable={false}
          onContextMenu={(e) => e.preventDefault()}
          referrerPolicy="no-referrer"
        />
      )}
    </div>
  );
}

