import React, { useState, useEffect } from 'react';
import { doc } from 'firebase/firestore';
import { db, isFirebaseEnabled, setFirebaseEnabled, getDoc } from '../db/firebase';
import TaxcomLogo from './TaxcomLogo';

export interface BrandingData {
  logoUrl?: string;
  companyName?: string;
  tagline?: string;
}

export function useBranding() {
  const [branding, setBranding] = useState<BrandingData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBranding = async () => {
      try {
        if (isFirebaseEnabled && db) {
          const docRef = doc(db, 'settings', 'branding');
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            setBranding(docSnap.data() as BrandingData);
            return;
          }
        }
        
        // Fallback to local storage
        const local = localStorage.getItem('app_branding');
        if (local) {
          setBranding(JSON.parse(local));
        }
      } catch (err: any) {
        const isPermissionError = err?.code === 'permission-denied' || (err?.message && err.message.includes('permission'));
        if (isPermissionError) {
          console.warn('[FIRESTORE] Branding fetch failed due to permission denial. Keeping Firebase enabled.');
        } else if (err?.code === 'unavailable' || (err?.message && err.message.includes('offline'))) {
          console.warn('Network unavailable, falling back to local branding.');
        } else {
          console.error("Failed to fetch branding:", err);
        }
        const local = localStorage.getItem('app_branding');
        if (local) {
          try {
            setBranding(JSON.parse(local));
          } catch (e) {}
        }
      } finally {
        setLoading(false);
      }
    };
    fetchBranding();
  }, []);

  return { branding, loading };
}

export default function Logo() {
  const { branding, loading } = useBranding();

  if (loading) return null;

  if (!branding || (!branding.logoUrl && !branding.companyName && !branding.tagline)) {
    return <TaxcomLogo size="lg" className="mb-6 lg:mb-8 flex justify-center" />;
  }

  return (
    <div className="flex flex-col items-center text-center space-y-3 mb-6 lg:mb-8">
      {branding.logoUrl ? (
        <img 
          src={branding.logoUrl} 
          alt="Company Logo" 
          className="h-16 md:h-20 w-auto object-contain" 
        />
      ) : (
        <TaxcomLogo size="lg" iconOnly />
      )}
      {(branding.companyName || branding.tagline) && (
        <div>
          {branding.companyName && (
            <h1 className="text-xl md:text-3xl font-black tracking-tight text-slate-900 leading-tight">
              {branding.companyName}
            </h1>
          )}
          {branding.tagline && (
            <p className="text-sm font-bold uppercase tracking-widest text-[#F5405E] mt-1">
              {branding.tagline}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
