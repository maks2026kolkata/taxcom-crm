import React, { useState, useEffect } from 'react';
import { X, Send, Mail, CheckCircle2, AlertCircle } from 'lucide-react';
import { sendEmail } from '../services/emailService';
import { useAuth } from './AuthContext';
import { useToast } from './Toast';

interface EmailModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTo: string;
  initialSubject: string;
  initialBody: string;
}

export const EmailModal: React.FC<EmailModalProps> = ({
  isOpen,
  onClose,
  initialTo,
  initialSubject,
  initialBody
}) => {
  const [to, setTo] = useState(initialTo);
  const [subject, setSubject] = useState(initialSubject);
  const [body, setBody] = useState(initialBody);

  useEffect(() => {
    if (isOpen) {
      setTo(initialTo);
      setSubject(initialSubject);
      setBody(initialBody);
      setStatus({ type: 'idle', message: '' });
    }
  }, [isOpen, initialTo, initialSubject, initialBody]);

  const [isSending, setIsSending] = useState(false);
  const [status, setStatus] = useState<{ type: 'idle' | 'error' | 'success', message: string }>({ type: 'idle', message: '' });

  const { currentUser } = useAuth();
  const { showToast } = useToast();
  if (!isOpen) return null;

  const staffName = currentUser?.name || 'Staff';
  const companyName = 'Taxcom Technologies LLP';

  const previewBody = body
    .replace(/\{\{staffName\}\}/g, staffName)
    .replace(/\{\{companyName\}\}/g, companyName);

  const isValidEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const isFormValid = to && isValidEmail(to) && subject && body;

  const handleSend = async () => {
    if (!isFormValid) return;
    
    setIsSending(true);
    setStatus({ type: 'idle', message: '' });
    
    try {
      const result = await sendEmail({ to, subject, body });
      if (result.success) {
        setStatus({ type: 'success', message: result.message });
        showToast(result.message, 'success');
        setTimeout(() => onClose(), 2000);
      } else {
        setStatus({ type: 'error', message: result.message });
        showToast(result.message, 'error');
      }
    } catch (err: any) {
      setStatus({ type: 'error', message: err.message || 'Failed to send email.' });
      showToast(err.message || 'Failed to send email.', 'error');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col animate-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-slate-100 bg-slate-50">
          <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
            <Mail className="w-5 h-5 text-[#F43F5E]" />
            Email Preview
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content area: Responsive layout */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 flex flex-col lg:flex-row gap-6">
          
          {/* Edit Column */}
          <div className="flex-1 space-y-4">
            <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-2 border-b border-slate-100 pb-2">Email Settings</h4>
            
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">Recipient (To)</label>
              <input
                type="email"
                value={to}
                onChange={(e) => { setTo(e.target.value); setStatus({ type: 'idle', message: '' }); }}
                placeholder="client@example.com"
                className={`w-full border rounded-xl p-2.5 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:border-[#F43F5E] transition-all ${to && !isValidEmail(to) ? 'border-rose-300 focus:ring-rose-200' : 'border-slate-200 focus:ring-[#F43F5E]/20'}`}
              />
              {to && !isValidEmail(to) && (
                <p className="text-[10px] text-rose-500 font-bold mt-1">Please enter a valid email address.</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">Subject</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Email Subject"
                className="w-full border border-slate-200 rounded-xl p-2.5 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#F43F5E]/20 focus:border-[#F43F5E] transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">Message Body</label>
              <textarea
                rows={10}
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Type your email message..."
                className="w-full border border-slate-200 rounded-xl p-3 bg-slate-50 text-sm font-sans text-slate-800 leading-relaxed focus:outline-none focus:ring-2 focus:ring-[#F43F5E]/20 focus:border-[#F43F5E] transition-all resize-y min-h-[200px]"
              />
            </div>
          </div>

          {/* Preview Column */}
          <div className="flex-1 lg:max-w-md flex flex-col">
            <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-2 border-b border-slate-100 pb-2">Live Preview</h4>
            
            <div className="bg-slate-100 rounded-2xl border border-slate-200 p-4 flex-1 flex flex-col shadow-inner overflow-hidden">
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col flex-1">
                
                {/* Email Header Preview */}
                <div className="p-4 border-b border-slate-100 bg-slate-50/80">
                  <div className="grid grid-cols-[40px_1fr] gap-2 items-center text-sm">
                    <span className="text-slate-400 font-medium text-right text-xs">To:</span>
                    <span className="text-slate-800 font-medium truncate">{to || <span className="text-slate-400 italic">No recipient</span>}</span>
                    
                    <span className="text-slate-400 font-medium text-right text-xs">Sub:</span>
                    <span className="text-slate-900 font-bold truncate">{subject || <span className="text-slate-400 italic">No subject</span>}</span>
                  </div>
                </div>

                {/* Email Body Preview */}
                <div className="p-5 flex-1 overflow-y-auto bg-white">
                  <div className="text-sm text-slate-800 whitespace-pre-wrap leading-relaxed font-sans">
                    {previewBody || <span className="text-slate-400 italic">Message body is empty...</span>}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex-1 w-full text-sm">
            {status.type === 'error' && (
              <div className="flex items-center text-rose-600 bg-rose-50 px-3 py-2 rounded-lg border border-rose-100">
                <AlertCircle className="w-4 h-4 mr-2 shrink-0" />
                <span className="font-bold whitespace-pre-line">{status.message}</span>
              </div>
            )}
            {status.type === 'success' && (
              <div className="flex items-center text-emerald-600 bg-emerald-50 px-3 py-2 rounded-lg border border-emerald-100">
                <CheckCircle2 className="w-4 h-4 mr-2 shrink-0" />
                <span className="font-bold">{status.message}</span>
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              disabled={isSending}
              className="flex-1 sm:flex-none px-5 py-2.5 text-sm font-bold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-all disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSend}
              disabled={!isFormValid || isSending}
              className="flex-1 sm:flex-none inline-flex items-center justify-center px-6 py-2.5 text-sm font-bold text-white bg-[#F43F5E] hover:bg-rose-600 rounded-xl shadow-sm transition-all disabled:opacity-50 disabled:hover:bg-[#F43F5E] disabled:cursor-not-allowed"
            >
              {isSending ? (
                <>
                  <div className="w-4 h-4 mr-2 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Send Email
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
