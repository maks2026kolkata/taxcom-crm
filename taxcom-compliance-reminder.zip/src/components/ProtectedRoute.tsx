import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { firebaseUser, currentUser, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center font-sans">
        <div className="w-8 h-8 rounded-full border-2 border-slate-200 border-t-[#F5405E] animate-spin mb-4"></div>
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Verifying Authentication...</p>
      </div>
    );
  }

  if (!firebaseUser || !currentUser) {
    // Redirect to login, preserving the location they tried to access
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
}
