import React, { useState, useRef } from 'react';
import { Upload, AlertCircle, CheckCircle, ArrowRight, ShieldAlert, FileSpreadsheet, Eye, HelpCircle } from 'lucide-react';
import { useToast } from './Toast';
import * as XLSX from 'xlsx';

interface FieldDefinition {
  key: string;
  label: string;
  required: boolean;
  validation?: (value: any) => string | null;
}

interface ImportWizardProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  fields: FieldDefinition[];
  existingKeys: string[]; // for duplicate check
  duplicateCheckKey: string; // which mapped field to match against existingKeys
  onImport: (mappedData: any[]) => void;
}

export default function ImportWizard({
  isOpen,
  onClose,
  title,
  fields,
  existingKeys,
  duplicateCheckKey,
  onImport,
}: ImportWizardProps) {
  const { showToast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Wizard Steps
  // 1: Upload, 2: Column Mapping, 3: Validation & Preview, 4: Success
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [fileName, setFileName] = useState('');
  const [parsedHeaders, setParsedHeaders] = useState<string[]>([]);
  const [parsedRows, setParsedRows] = useState<string[][]>([]);
  const [columnMapping, setColumnMapping] = useState<{ [dbKey: string]: string }>({});
  
  // Validation State
  const [validatedRows, setValidatedRows] = useState<any[]>([]);
  const [errorsList, setErrorsList] = useState<{ row: number; column: string; message: string; severity: 'error' | 'warning' }[]>([]);

  if (!isOpen) return null;

  const resetState = () => {
    setStep(1);
    setFileName('');
    setParsedHeaders([]);
    setParsedRows([]);
    setColumnMapping({});
    setValidatedRows([]);
    setErrorsList([]);
  };

  // 1. Parse File CSV format (simple & robust split)
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processFile(file);
  };

  const processFile = (file: File) => {
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert sheet to 2D array of string/any
        const json = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];
        if (!json || json.length === 0) {
          showToast('The uploaded file is empty.', 'error');
          return;
        }

        const headers = json[0].map(h => h === undefined || h === null ? '' : String(h).trim());
        const rows = json.slice(1).map(row => 
          row.map(cell => cell === undefined || cell === null ? '' : String(cell).trim())
        );

        setParsedHeaders(headers);
        setParsedRows(rows);

        // Auto map matching columns
        const initialMap: { [dbKey: string]: string } = {};
        fields.forEach(f => {
          const matched = headers.find(h => 
            h.toLowerCase() === f.label.toLowerCase() || 
            h.toLowerCase() === f.key.toLowerCase() ||
            h.toLowerCase().replace(/[^a-z0-9]/g, '') === f.key.toLowerCase()
          );
          if (matched) {
            initialMap[f.key] = matched;
          }
        });
        setColumnMapping(initialMap);
        setStep(2);
      } catch (err: any) {
        console.error('Error processing spreadsheet file:', err);
        showToast(`Could not parse spreadsheet file: ${err.message || err}`, 'error');
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  // 2. Column Mapping
  const handleMapChange = (dbKey: string, fileHeader: string) => {
    setColumnMapping(prev => ({
      ...prev,
      [dbKey]: fileHeader,
    }));
  };

  const validateMapping = () => {
    // Check if any required field is not mapped
    const missingRequired = fields.filter(f => f.required && !columnMapping[f.key]);
    if (missingRequired.length > 0) {
      showToast(`Please map all required fields: ${missingRequired.map(f => f.label).join(', ')}`, 'warning');
      return;
    }

    // Move to validation & preview
    runValidationAndPreview();
    setStep(3);
  };

  // 3. Validation & Preview
  const runValidationAndPreview = () => {
    const validated: any[] = [];
    const errors: typeof errorsList = [];

    parsedRows.forEach((row, rowIndex) => {
      const rowNum = rowIndex + 2; // header is row 1
      const mappedRowObj: any = {};

      fields.forEach(field => {
        const mappedHeader = columnMapping[field.key];
        const headerIndex = parsedHeaders.indexOf(mappedHeader);
        const cellValue = headerIndex !== -1 && row[headerIndex] !== undefined ? row[headerIndex] : '';

        // Clean values
        mappedRowObj[field.key] = cellValue;

        // 1. Required Field Validation
        if (field.required && !cellValue) {
          errors.push({
            row: rowNum,
            column: field.label,
            message: `Required field "${field.label}" is missing.`,
            severity: 'error',
          });
        }

        // 2. Custom validation checks (like regex)
        if (cellValue && field.validation) {
          const errMsg = field.validation(cellValue);
          if (errMsg) {
            errors.push({
              row: rowNum,
              column: field.label,
              message: errMsg,
              severity: 'warning',
            });
          }
        }
      });

      // 3. Duplicate Checking
      const checkVal = mappedRowObj[duplicateCheckKey];
      if (checkVal && existingKeys.includes(checkVal)) {
        errors.push({
          row: rowNum,
          column: duplicateCheckKey,
          message: `Duplicate item found. Identical value "${checkVal}" already exists in database.`,
          severity: 'warning',
        });
        mappedRowObj._isDuplicate = true;
      }

      validated.push(mappedRowObj);
    });

    setValidatedRows(validated);
    setErrorsList(errors);
  };

  const confirmImport = () => {
    // Exclude rows with fatal required field errors
    const fatalRows = errorsList.filter(e => e.severity === 'error').map(e => e.row);
    const importableData = validatedRows.filter((_, idx) => !fatalRows.includes(idx + 2));

    if (importableData.length === 0) {
      showToast('No valid rows available to import due to validation errors.', 'error');
      return;
    }

    onImport(importableData);
    setStep(4);
    showToast(`Successfully imported ${importableData.length} records!`, 'success');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-4xl w-full max-h-[85vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center">
              <FileSpreadsheet className="w-5 h-5 text-rose-500 mr-2" />
              {title} Wizard
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">Excel/CSV Importer • Compliance Audited</p>
          </div>
          <button
            onClick={() => {
              resetState();
              onClose();
            }}
            className="text-slate-400 hover:text-slate-600 font-bold p-1 rounded-lg hover:bg-slate-200 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Wizard Steps indicator */}
        <div className="px-6 py-3 bg-slate-100/50 border-b border-slate-200/50 flex items-center space-x-4 text-xs font-semibold">
          <span className={`${step === 1 ? 'text-[#F5405E]' : 'text-slate-400'}`}>1. Upload</span>
          <ArrowRight className="w-3 h-3 text-slate-300" />
          <span className={`${step === 2 ? 'text-[#F5405E]' : 'text-slate-400'}`}>2. Column Map</span>
          <ArrowRight className="w-3 h-3 text-slate-300" />
          <span className={`${step === 3 ? 'text-[#F5405E]' : 'text-slate-400'}`}>3. Validation & Preview</span>
          <ArrowRight className="w-3 h-3 text-slate-300" />
          <span className={`${step === 4 ? 'text-[#F5405E]' : 'text-slate-400'}`}>4. Complete</span>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 p-6 overflow-y-auto min-h-[300px]">
          
          {/* STEP 1: UPLOAD */}
          {step === 1 && (
            <div className="space-y-6">
              <div
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 hover:border-[#F5405E] bg-slate-50/50 hover:bg-rose-50/5 rounded-2xl p-10 flex flex-col items-center justify-center text-center cursor-pointer transition-all group"
              >
                <div className="p-4 rounded-full bg-slate-100 text-slate-500 group-hover:bg-rose-50 group-hover:text-[#F5405E] transition-colors mb-4">
                  <Upload className="w-8 h-8" />
                </div>
                <p className="text-sm font-bold text-slate-800">
                  Drag & Drop Excel/CSV files here
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  or click to browse your computer
                </p>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                  accept=".csv,.xlsx,.xls"
                  className="hidden"
                />
              </div>

              {/* Sample format hint */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center">
                  <HelpCircle className="w-3.5 h-3.5 mr-1" />
                  Expected Columns / Fields
                </h4>
                <div className="flex flex-wrap gap-2">
                  {fields.map((f) => (
                    <span
                      key={f.key}
                      className={`text-[10px] px-2 py-1 rounded-md font-semibold ${
                        f.required
                          ? 'bg-rose-100 text-rose-800 border border-rose-200'
                          : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {f.label} {f.required && '*'}
                    </span>
                  ))}
                </div>
                <span className="block text-[10px] text-slate-400 mt-2">* Red fields are strictly required for validation.</span>
              </div>
            </div>
          )}

          {/* STEP 2: COLUMN MAPPING */}
          {step === 2 && (
            <div className="space-y-5">
              <div>
                <h3 className="font-bold text-slate-800 text-sm">Map File Headers to Database Fields</h3>
                <p className="text-xs text-slate-500">We matched some columns automatically. Verify or map the rest manually.</p>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden divide-y divide-slate-100">
                {fields.map((field) => (
                  <div key={field.key} className="grid grid-cols-2 p-3 items-center hover:bg-slate-50">
                    <div className="flex items-center">
                      <span className="text-xs font-bold text-slate-800">
                        {field.label} {field.required && <strong className="text-rose-500">*</strong>}
                      </span>
                    </div>
                    <div>
                      <select
                        value={columnMapping[field.key] || ''}
                        onChange={(e) => handleMapChange(field.key, e.target.value)}
                        className="block w-full text-xs border border-slate-300 rounded px-2.5 py-1.5 bg-white"
                      >
                        <option value="">-- Do Not Import --</option>
                        {parsedHeaders.map((header) => (
                          <option key={header} value={header}>
                            {header}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  onClick={() => setStep(1)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
                >
                  Back
                </button>
                <button
                  onClick={validateMapping}
                  className="px-4 py-2 text-xs font-bold text-white bg-[#F5405E] hover:bg-rose-600 rounded-lg"
                >
                  Validate Data
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: PREVIEW & ERROR REPORTS */}
          {step === 3 && (
            <div className="space-y-6">
              
              {/* Validation Alert */}
              <div className={`p-4 rounded-xl flex items-start space-x-3 border ${
                errorsList.some(e => e.severity === 'error')
                  ? 'bg-rose-50 border-rose-200 text-rose-800'
                  : errorsList.length > 0
                  ? 'bg-amber-50 border-amber-200 text-amber-800'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-800'
              }`}>
                {errorsList.some(e => e.severity === 'error') ? (
                  <ShieldAlert className="w-5 h-5 text-rose-500 shrink-0" />
                ) : (
                  <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />
                )}
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider">Validation Audit Report</h3>
                  <p className="text-xs mt-1 font-medium">
                    {errorsList.some(e => e.severity === 'error')
                      ? 'We found major errors. Rows with missing required fields will be automatically excluded.'
                      : errorsList.length > 0
                      ? 'No critical errors found! Some warnings/duplicate entries detected but they are safe to bypass.'
                      : 'All checks passed perfectly! Highly compliant dataset structure.'}
                  </p>
                </div>
              </div>

              {/* Error Details Log */}
              {errorsList.length > 0 && (
                <div className="p-4 rounded-xl bg-slate-900 text-slate-100 max-h-40 overflow-y-auto font-mono text-xs space-y-1.5 border border-slate-800 shadow-sm">
                  <div className="text-[10px] text-slate-400 font-semibold tracking-widest uppercase mb-1">Issue Log (Rows 2-{parsedRows.length + 1}):</div>
                  {errorsList.map((err, i) => (
                    <div key={i} className="flex items-start">
                      <span className={`inline-block px-1 rounded text-[9px] font-bold uppercase mr-2 ${
                        err.severity === 'error' ? 'bg-rose-900 text-rose-200' : 'bg-amber-900 text-amber-200'
                      }`}>
                        {err.severity}
                      </span>
                      <span>
                        Row {err.row}, Column "{err.column}": {err.message}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {/* Visual Preview Table */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-700 flex items-center">
                  <Eye className="w-4 h-4 mr-1" />
                  File Rows Preview ({validatedRows.length} total parsed)
                </h4>
                <div className="border border-slate-200 rounded-xl overflow-auto max-h-60">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-50 sticky top-0 border-b border-slate-200 font-semibold text-slate-600">
                      <tr>
                        <th className="p-2 border-r border-slate-200 text-center">Row</th>
                        {fields.map((f) => (
                          <th key={f.key} className="p-2 border-r border-slate-200">
                            {f.label}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {validatedRows.map((row, idx) => {
                        const rowNum = idx + 2;
                        const hasError = errorsList.some(e => e.row === rowNum && e.severity === 'error');
                        return (
                          <tr key={idx} className={hasError ? 'bg-rose-50/40 text-rose-700 line-through' : row._isDuplicate ? 'bg-amber-50/30' : 'hover:bg-slate-50/50'}>
                            <td className="p-2 border-r border-slate-200 text-center font-bold text-slate-400">{rowNum}</td>
                            {fields.map((f) => (
                              <td key={f.key} className="p-2 border-r border-slate-200 truncate max-w-[120px]">
                                {row[f.key] || <em className="text-slate-300">empty</em>}
                              </td>
                            ))}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setStep(2)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
                >
                  Back to Mapping
                </button>
                <button
                  onClick={confirmImport}
                  className="px-5 py-2 text-xs font-bold text-white bg-[#F5405E] hover:bg-rose-600 rounded-lg shadow-sm"
                >
                  Confirm & Import Records
                </button>
              </div>

            </div>
          )}

          {/* STEP 4: SUCCESS CONGRATS */}
          {step === 4 && (
            <div className="py-10 flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-16 h-16 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center border-2 border-emerald-100 animate-bounce">
                <CheckCircle className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-extrabold text-slate-900">Import Session Completed Successfully</h3>
              <p className="text-xs text-slate-500 max-w-sm">
                The compliance spreadsheet records have been verified, cross-checked for duplicates, and successfully integrated into our primary Live Firestore cache.
              </p>
              <button
                onClick={() => {
                  resetState();
                  onClose();
                }}
                className="mt-4 px-6 py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
              >
                Close Importer
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
