import { query, where } from "firebase/firestore";
import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  getAuth, 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  sendPasswordResetEmail,
  signOut,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  app, 
  auth, 
  db, 
  isFirebaseEnabled, 
  setFirebaseEnabled,
  requestFCMToken,
  handleFirestoreError,
  OperationType,
  instrumentedSetDoc
} from '../db/firebase';
import { 
  getLoggedInUser, 
  setLoggedInUser, 
  CurrentUserState, 
  startFirestoreSync, 
  stopFirestoreSync, 
  getStaff,
  addAuditLog
} from '../db/storage';
import { 
  collection, 
  doc, 
  getDocs
} from 'firebase/firestore';
import {
  setDoc,
  getDoc,
  deleteDoc,
  onSnapshot
} from '../db/firebase';
import { UserRole } from '../types';

interface AuthContextType {
  firebaseUser: FirebaseUser | null;
  currentUser: CurrentUserState | null;
  isLoading: boolean;
  isSyncing: boolean;
  isAuthenticated: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [currentUser, setCurrentUser] = useState<CurrentUserState | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);

  const logout = async () => {
    setError(null);
    const user = currentUser || getLoggedInUser();
    if (!auth) return;
    try {
      if (user && user.id) {
        await addAuditLog('User Logout', user.id, user.name, undefined, `Email: ${user.email}, Role: ${user.role}`);
      }
      await signOut(auth);
    } catch (err: any) {
      console.error('Logout failed:', err);
      setError(err.message || 'Logout failed');
    }
  };
  const [error, setError] = useState<string | null>(null);

  const instrumentedSetCurrentUser = (newVal: CurrentUserState | null | ((prev: CurrentUserState | null) => CurrentUserState | null)) => {
    setCurrentUser(prev => {
      const resolvedNewVal = typeof newVal === 'function' ? (newVal as Function)(prev) : newVal;
      console.log('[INSTRUMENT] setCurrentUser() called');
      console.log('  Previous object:', JSON.stringify(prev, null, 2));
      console.log('  New object:', JSON.stringify(resolvedNewVal, null, 2));
      return resolvedNewVal;
    });
  };

  // Keep state synchronized with storage system (e.g. for offline/demo/profile changes)
  useEffect(() => {
    const handleSync = () => {
      const loggedIn = getLoggedInUser();
      if (loggedIn) {
        instrumentedSetCurrentUser(prev => {
          if (!prev) return loggedIn;
          if (
            prev.id !== loggedIn.id ||
            prev.name !== loggedIn.name ||
            prev.role !== loggedIn.role ||
            prev.email !== loggedIn.email
          ) {
            return loggedIn;
          }
          return prev;
        });
      }
    };
    window.addEventListener('database-sync', handleSync);
    return () => window.removeEventListener('database-sync', handleSync);
  }, []);

  // Real-time listener for the authenticated user's staff profile
  useEffect(() => {
    if (!auth) {
      // Trigger configuration diagnostic error immediately
      const event = new CustomEvent('firestore-permission-error', {
        detail: { 
          code: 'MISSING_FIREBASE_CONFIGURATION', 
          message: 'Firebase SDK is not initialized. The environment variables in .env are missing, invalid, or empty.', 
          path: 'N/A', 
          operation: 'auth_init' 
        }
      });
      window.dispatchEvent(event);
      setIsLoading(false);
      return;
    }

    if (!firebaseUser) {
      instrumentedSetCurrentUser(null);
      setLoggedInUser(null);
      setIsLoading(false);
      return;
    }

    let unsub: (() => void) | null = null;
    let isCancelled = false;


    const checkAndSubscribe = async () => {
      setIsLoading(true);
      const staffDocRef = doc(db, 'staff', firebaseUser.uid);
      
      console.log('--- PRODUCTION AUDIT ---');
      console.log('Auth UID:', firebaseUser.uid);
      console.log('Email:', firebaseUser.email);
      console.log('Queried Firestore path: staff/' + firebaseUser.uid);

      let checkSnap: any = null;
      try {
        checkSnap = await getDoc(staffDocRef);
        console.log('Document exists:', checkSnap.exists());
        
        if (checkSnap.exists()) {
          console.log('Complete document:', JSON.stringify(checkSnap.data(), null, 2));
          const data = checkSnap.data();
          if (!data.role) {
            console.warn('REPORT: Document exists but role is missing');
          }
          if (data.id && data.id !== firebaseUser.uid) {
            console.warn('REPORT: Document exists but UID does not match Authentication UID');
          }
        } else {
          console.log('UID searched:', firebaseUser.uid);
          
          // Let's verify if the app incorrectly saved it by email
          if (firebaseUser.email) {
            try {
              const emailQ = query(collection(db, 'staff'), where('email', '==', firebaseUser.email));
              const emailSnap = await getDocs(emailQ);
              if (!emailSnap.empty) {
                console.log('REPORT: Found staff document using email query instead of UID!');
                emailSnap.forEach(d => {
                  console.log('Found doc ID:', d.id);
                  console.log('Found doc data:', JSON.stringify(d.data(), null, 2));
                });
              } else {
                const emailDocRef = doc(db, 'staff', firebaseUser.email);
                const emailDocSnap = await getDoc(emailDocRef);
                if (emailDocSnap.exists()) {
                  console.log('REPORT: Found staff document where ID is the email!');
                }
              }
            } catch(fallbackErr: any) {
              console.warn("Fallback query failed (likely permission denied, which confirms rule enforcement):", fallbackErr.message);
            }
          }
        }
      } catch (checkErr: any) {
        console.error("Failed to read staff document during login pre-check:", checkErr);
        setIsLoading(false);
        throw checkErr;
      }

      if (!checkSnap.exists()) {
        console.error("Staff profile not found in Firestore. Logging out.");
        logout();
        setError("Account profile not found. Please contact your administrator.");
        setIsLoading(false);
        return;
      }

      console.log('[AUTH DEBUG] Subscribing to real-time Firestore listener for staff/' + firebaseUser.uid);


      const unsubscribe = onSnapshot(staffDocRef, async (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();

          console.log('[STEP 2 INSTRUMENT] COMPLETE Firestore Document (staff/' + firebaseUser.uid + '):', JSON.stringify(data, null, 2));

          if (data.active === false) {
            console.warn('[AUTH DEBUG] User is inactive in Firestore, logging out.');
            logout();
            return;
          }

          const profile: CurrentUserState = {
            id: firebaseUser.uid,
            name: data.name || 'User',
            role: (data.role as UserRole) || 'Staff',
            email: data.email || firebaseUser.email || '',
            ...data,
          };

          console.log('[STEP 3 INSTRUMENT] Object assigned to currentUser:', JSON.stringify(profile, null, 2));

          instrumentedSetCurrentUser(profile);
          setLoggedInUser(profile);
          setIsLoading(false);
          window.dispatchEvent(new Event('database-sync'));
        } else {
          console.warn('[AUTH DEBUG] Active profile document was deleted/does not exist in snapshot.');
          setIsLoading(false);
        }
      }, (snapError) => {
        console.error('[AUTH DEBUG] onSnapshot error on staff document:', snapError);
        setIsLoading(false);
      });

      return unsubscribe;
    };

    const setup = async () => {
      try {
        const cleanup = await checkAndSubscribe();
        if (cleanup) {
          if (isCancelled) {
            cleanup();
          } else {
            unsub = cleanup;
          }
        }
      } catch (e) {
        console.error('Failed to setup auth and subscription:', e);
      }
    };

    setup();

    return () => {
      isCancelled = true;
      if (unsub) unsub();
    };
  }, [firebaseUser]);

  useEffect(() => {
    if (!auth) return;

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      console.log('[AUTH DEBUG] onAuthStateChanged fired. User:', fbUser ? fbUser.email : 'null');
      if (fbUser) {
        // STEP 1 Instrument Firebase Authentication
        console.log('[STEP 1 INSTRUMENT] Firebase Authentication Detected User:');
        console.log('  uid:', fbUser.uid);
        console.log('  email:', fbUser.email);
        console.log('  provider:', fbUser.providerId || fbUser.providerData?.map(p => p.providerId).join(', ') || 'N/A');
        console.log('  login timestamp:', new Date().toISOString());

        setFirebaseUser(fbUser);
        startFirestoreSync();
        
        if (sessionStorage.getItem('pending_login_audit') === 'true') {
          sessionStorage.removeItem('pending_login_audit');
          const currentLoggedIn = getLoggedInUser();
          addAuditLog('User Login', fbUser.uid, currentLoggedIn?.name || fbUser.email || 'User', undefined, `Email: ${fbUser.email}`);
        }
      } else {
        setFirebaseUser(null);
        instrumentedSetCurrentUser(null);
        setLoggedInUser(null);
        stopFirestoreSync();
      }
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, password: string) => {
    setError(null);
    if (!auth) throw new Error('Firebase Authentication is not configured. Please initialize Firebase.');
    console.log('[AUTH DEBUG] Email passed to signInWithEmailAndPassword():', email.trim());
    try {
      sessionStorage.setItem('pending_login_audit', 'true');
      const response = await signInWithEmailAndPassword(auth, email.trim(), password);
      console.log('[AUTH DEBUG] Firebase authentication response successfully received:', {
        uid: response.user?.uid,
        email: response.user?.email,
        emailVerified: response.user?.emailVerified,
      });
      // Let onAuthStateChanged handle setting isLoading to false upon successful profile load
    } catch (err: any) {
      sessionStorage.removeItem('pending_login_audit');
      console.error('[AUTH DEBUG] Firebase authentication failed with error code:', err.code, 'and message:', err.message, 'stack:', err.stack || err);
      console.error('Login failed:', err);
      let msg = 'Authentication failed. Please check your credentials.';
      if (err.code === 'auth/configuration-not-found' || (err.message && err.message.includes('configuration-not-found'))) {
        msg = 'Firebase Authentication Configuration Required: Please enable the "Email/Password" sign-in provider in your Firebase Console (under Build > Authentication > Sign-in method).';
      }
      setError(msg);
      throw err;
    }
  };

  const resetPassword = async (email: string) => {
    setError(null);
    if (!auth) throw new Error('Firebase Authentication is not configured. Please initialize Firebase.');
    try {
      await sendPasswordResetEmail(auth, email.trim());
    } catch (err: any) {
      console.error('Password reset failed:', err);
      setError(err.message || 'Password reset failed');
      throw err;
    }
  };


  return (
    <AuthContext.Provider value={{
      firebaseUser,
      currentUser,
      isLoading,
      isSyncing,
      isAuthenticated: !!firebaseUser && !!currentUser,
      error,
      login,
      resetPassword,
      logout
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
