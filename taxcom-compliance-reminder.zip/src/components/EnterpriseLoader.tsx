import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, CheckCircle2 } from 'lucide-react';
import { collection, getDocs, limit, query } from "firebase/firestore";
import { db } from "../db/firebase";
import Logo from './Logo';

interface EnterpriseLoaderProps {
  isLoading: boolean;
  isAuthenticated: boolean;
  userName?: string;
  onComplete: () => void;
}

const ROTATING_MESSAGES = [
  'Connecting securely...',
  'Verifying credentials...',
  'Loading your workspace...',
  'Almost ready...'
];

export default function EnterpriseLoader({ isLoading, isAuthenticated, userName, onComplete }: EnterpriseLoaderProps) {
  const [msgIndex, setMsgIndex] = useState(0);
  const [isDone, setIsDone] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isLongLoading, setIsLongLoading] = useState(false);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
    
    return () => {
      document.body.style.overflow = '';
      document.documentElement.style.overflow = '';
    };
  }, []);

  // Rotating Messages
  useEffect(() => {
    if (isDone) return;
    const interval = setInterval(() => {
      setMsgIndex((prev) => Math.min(prev + 1, ROTATING_MESSAGES.length - 1));
    }, 2000);
    return () => clearInterval(interval);
  }, [isDone]);

  // Long Loading Detection
  useEffect(() => {
    if (isDone) return;
    const timeout = setTimeout(() => {
      setIsLongLoading(true);
    }, 5000);
    return () => clearTimeout(timeout);
  }, [isDone]);

  // Real-time initialization tasks
  useEffect(() => {
    let isCancelled = false;
    
    const runInitialization = async () => { 
      if (!isAuthenticated || isLoading) return;

      try {
        let databaseNotFound = false;
        const fetchCheck = async (colName: string) => {
          try {
             const fetchPromise = getDocs(query(collection(db, colName), limit(1)));
             const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 1000));
             await Promise.race([fetchPromise, timeoutPromise]);
          } catch (e: any) {
             if (e && (e.code === 'not-found' || (e.message && e.message.includes('not-found')))) {
               databaseNotFound = true;
             }
          }
        };

        // Run checks in parallel to avoid sequential timeout blocking
        await Promise.all([
          fetchCheck('clients'),
          fetchCheck('tasks'),
          fetchCheck('events'),
          fetchCheck('reminders'),
          fetchCheck('audit_logs'),
          fetchCheck('message_templates'),
          fetchCheck('staff')
        ]);

        if (databaseNotFound) {
          console.warn('[FIRESTORE] Firestore database does not exist or is not initialized in the Firebase Console.');
          localStorage.setItem('firestore_database_not_found', 'true');
        } else {
          localStorage.removeItem('firestore_database_not_found');
        }

        if (isCancelled) return;

        setIsDone(true);
        setMsgIndex(ROTATING_MESSAGES.length - 1);
        setIsTransitioning(true);

        setTimeout(() => {
          if (!isCancelled) onComplete();
        }, 800);

      } catch (err) {
        console.error('Initialization error:', err);
        if (!isCancelled) onComplete();
      }
    };

    if (isAuthenticated && !isLoading) {
      runInitialization();
    } else if (!isAuthenticated && !isLoading) {
      onComplete();
    }

    return () => {
      isCancelled = true;
    };
  }, [isLoading, isAuthenticated, onComplete]);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-gradient-to-br from-[#F8FAFC] to-[#EEF2F7] font-sans h-[100dvh] min-h-[100dvh] w-full overflow-hidden overscroll-none">
      {/* Background Particles/Shields */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none w-full h-full">
        <motion.div 
          animate={{ y: [0, -20, 0], opacity: [0.03, 0.05, 0.03] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-[10%] left-[-5%] transform rotate-12 flex justify-center items-center max-w-[45vw] md:max-w-[35vw] lg:max-w-[25vw]"
        >
          <Shield className="w-full h-auto text-slate-900" />
        </motion.div>
        <motion.div 
          animate={{ y: [0, 20, 0], opacity: [0.03, 0.05, 0.03] }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute bottom-[10%] right-[-5%] transform -rotate-12 flex justify-center items-center max-w-[45vw] md:max-w-[35vw] lg:max-w-[25vw]"
        >
          <Shield className="w-full h-auto text-slate-900" />
        </motion.div>
      </div>

      <AnimatePresence mode="wait">
        {!isTransitioning ? (
          <motion.div
            key="loading-card"
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 1.05, filter: "blur(4px)" }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="relative z-10 bg-white/70 backdrop-blur-xl border border-white/40 shadow-2xl rounded-3xl p-[20px] md:p-[32px] lg:p-[48px] flex flex-col items-center justify-center w-[calc(100%-32px)] md:w-[90%] lg:w-[480px] lg:max-w-[480px] max-h-[80vh] overflow-hidden"
          >
            {/* Dynamic Logo Area */}
            <Logo />

            <div className="flex flex-col items-center text-center space-y-3 shrink-0">
              <h2 className="text-xl md:text-2xl font-bold text-slate-800">Initializing Secure Workspace</h2>
              
              {/* Animated loading indicator */}
              <div className="py-6 flex justify-center items-center">
                <div className="w-12 h-12 rounded-full border-4 border-slate-200 border-t-blue-500 animate-spin"></div>
              </div>

              {/* Rotating status text */}
              <div className="h-8 w-full">
                <AnimatePresence mode="wait">
                  <motion.p
                    key={msgIndex}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    className="text-sm font-medium text-slate-500 text-center"
                  >
                    {ROTATING_MESSAGES[msgIndex]}
                  </motion.p>
                </AnimatePresence>
              </div>

              {isLongLoading && !isDone && (
                <p className="text-xs text-slate-400 mt-2">
                  Still preparing... this might take a moment.
                </p>
              )}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="success-state"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative z-10 flex flex-col items-center justify-center text-center"
          >
            <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mb-6 shadow-xl shadow-emerald-500/30">
              <CheckCircle2 className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight mb-2">Authentication Successful</h2>
            <p className="text-lg text-slate-600 font-medium">Welcome back, {userName || 'User'}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
