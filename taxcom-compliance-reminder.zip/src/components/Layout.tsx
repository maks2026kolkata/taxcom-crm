import React from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  CheckSquare,
  Bell,
  Calendar,
  FileText,
  CreditCard,
  BarChart3,
  Users2,
  FileCode,
  Settings as SettingsIcon,
  LogOut,
  User,
  Sparkles,
  Menu,
  X,
  Database,
  Shield,
  RefreshCw
} from 'lucide-react';
import { useAuth } from './AuthContext';
import { isFirebaseEnabled } from '../db/firebase';
import { AnimatePresence, motion } from 'motion/react';
import TaxcomLogo from './TaxcomLogo';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { currentUser, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = React.useState(false);
  const [isOnline, setIsOnline] = React.useState(navigator.onLine);

  React.useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const navItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard },
    { name: 'Clients', path: '/clients', icon: Users },
    { name: 'Tasks', path: '/tasks', icon: CheckSquare },
    { name: 'Reminders', path: '/reminders', icon: Bell },
    { name: 'Calendar', path: '/calendar', icon: Calendar },
    { name: 'Docs Pending', path: '/documents', icon: FileText },
    { name: 'Payments', path: '/payments', icon: CreditCard },
    { name: 'Reports', path: '/reports', icon: BarChart3 },
    { name: 'Team', path: '/team', icon: Users2 },
    { name: 'Templates', path: '/templates', icon: FileCode },
    { name: 'Audit', path: '/audit-logs', icon: Shield },
    { name: 'Settings', path: '/settings', icon: SettingsIcon },
  ];

  const handleLogout = async () => {
    setShowLogoutConfirm(false);
    await logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen md:h-screen md:overflow-hidden flex flex-col md:flex-row bg-slate-50 text-slate-900 font-sans">
      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-slate-200 shrink-0 print:hidden">
        <div className="p-6 border-b border-slate-100 flex justify-center">
          <TaxcomLogo size="md" />
        </div>

        {/* Navigation links */}
        <nav className="flex-1 p-4 space-y-1.5 overflow-y-auto">
          {navItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center px-3.5 py-2 text-sm font-semibold rounded-lg transition-all duration-150 group ${
                  isActive
                    ? 'bg-slate-100 text-[#F5405E]'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`
              }
            >
              <item.icon className="mr-3 h-4.5 w-4.5 shrink-0 transition-transform group-hover:scale-105" />
              {item.name}
            </NavLink>
          ))}
        </nav>

        {/* User context role and Secure Sign Out */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/70 space-y-3">
          <div className="flex flex-col gap-1 overflow-hidden">
            <div className="flex items-center justify-between">
              <p className="text-xs font-bold text-slate-800 truncate leading-none" title={currentUser?.name ? currentUser.name.replace(/\b\w/g, l => l.toUpperCase()) : 'User'}>
                {currentUser?.name ? currentUser.name.replace(/\b\w/g, l => l.toUpperCase()) : 'User'}
              </p>
              <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-rose-50 text-[#F5405E] border border-rose-100/50 shrink-0">
                {currentUser?.role || 'ADMIN'}
              </span>
            </div>
            {currentUser?.email && (!currentUser?.name || currentUser.name !== currentUser.email) && (
              <p className="text-[10px] font-medium text-slate-500 truncate" title={currentUser.email}>
                {currentUser.email}
              </p>
            )}
          </div>
          
          <button
            onClick={() => setShowLogoutConfirm(true)}
            className="w-full py-2 px-3 text-left rounded-lg text-xs font-bold text-slate-600 hover:bg-rose-50 hover:text-[#F5405E] transition-all flex items-center gap-2 cursor-pointer border border-transparent hover:border-rose-100"
          >
            <LogOut className="w-3.5 h-3.5" />
            Secure Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile Header & Burger */}
      <header className="md:hidden flex items-center justify-between px-4 py-3 bg-white border-b border-slate-200 shadow-xs print:hidden">
        <div className="flex items-center">
          <TaxcomLogo size="sm" />
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-slate-600 hover:bg-slate-100 focus:outline-none"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </header>

      {/* Mobile Drawer menu */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex justify-end print:hidden" onClick={() => setMobileMenuOpen(false)}>
          <div className="w-64 bg-white h-full shadow-xl flex flex-col p-4 animate-in slide-in-from-right duration-200" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
              <span className="font-bold text-lg text-slate-800">Navigation</span>
              <button onClick={() => setMobileMenuOpen(false)} className="p-1 rounded-lg hover:bg-slate-100">
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="flex-1 space-y-1 overflow-y-auto">
              {navItems.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={({ isActive }) =>
                    `flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-colors group ${
                      isActive
                        ? 'bg-rose-50 text-[#F5405E]'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                    }`
                  }
                >
                  <item.icon className="mr-3 h-5 w-5" />
                  {item.name}
                </NavLink>
              ))}
            </nav>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 mt-4 space-y-3">
              <div className="flex flex-col gap-1 overflow-hidden">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-bold text-slate-800 truncate leading-none" title={currentUser?.name ? currentUser.name.replace(/\b\w/g, l => l.toUpperCase()) : 'User'}>
                    {currentUser?.name ? currentUser.name.replace(/\b\w/g, l => l.toUpperCase()) : 'User'}
                  </p>
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-rose-50 text-[#F5405E] border border-rose-100/50 shrink-0">
                    {currentUser?.role || 'ADMIN'}
                  </span>
                </div>
                {currentUser?.email && (
                  <p className="text-[10px] font-medium text-slate-500 truncate" title={currentUser.email}>
                    {currentUser.email}
                  </p>
                )}
              </div>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  setShowLogoutConfirm(true);
                }}
                className="w-full py-2 px-3 text-left rounded bg-rose-50 text-[#F5405E] text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                Secure Sign Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 pb-16 md:pb-0 h-full overflow-hidden">
        {/* Dynamic header banner for system alerts, PWA installations, demo flags */}
        {!isFirebaseEnabled && (
          <div className="bg-slate-900 text-slate-300 px-6 py-2 text-xs font-medium flex items-center justify-between border-b border-slate-800 shrink-0 select-none print:hidden">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-3.5 h-3.5 text-[#F5405E] animate-pulse shrink-0" />
              <span>
                Taxcom Technologies CRM is running in Offline Local Mode. Connect Firebase to persistent cloud storage.
              </span>
            </div>
            <span className="hidden sm:inline-flex bg-slate-800 text-slate-400 px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider">
              Local Sandbox
            </span>
          </div>
        )}

        {/* Content Children */}
        <div className="flex-1 p-6 pb-24 md:pb-8 md:p-8 overflow-y-auto bg-slate-50">
          {children}
        </div>

        {/* Status Bar Footer */}
        <footer className="h-7 sm:h-8 bg-slate-100 border-t border-slate-200 px-3 sm:px-6 flex items-center justify-between text-[8px] sm:text-[9px] md:text-[10px] text-slate-500 font-semibold shrink-0 select-none print:hidden gap-2">
          <div className="flex gap-2 sm:gap-4 uppercase tracking-wider items-center">
            {isFirebaseEnabled ? (
              <>
                <div className="flex items-center gap-1" title={isOnline ? "Cloud Connected" : "Disconnected"}>
                  <span className={`h-1.5 w-1.5 sm:h-2 sm:w-2 rounded-full ${isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'} shrink-0`}></span>
                  <span className={`${isOnline ? 'text-emerald-600' : 'text-red-500'} font-black hidden sm:inline`}>{isOnline ? 'Connected' : 'Disconnected'}</span>
                  <span className={`${isOnline ? 'text-emerald-600' : 'text-red-500'} font-black inline sm:hidden`}>{isOnline ? 'Cloud' : 'Offline'}</span>
                </div>
                
                <span className="h-2.5 w-[1px] bg-slate-200"></span>
                
                <div className="flex items-center gap-1" title="Last Sync">
                  <RefreshCw className={`w-2.5 h-2.5 sm:w-3 sm:h-3 ${isOnline ? 'text-emerald-600 animate-[spin_12s_linear_infinite]' : 'text-slate-400'} shrink-0`} />
                  <span className="hidden md:inline text-slate-400">Last Sync:</span>
                  <span className="font-bold text-slate-600">{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>

                <span className="hidden md:inline h-2.5 w-[1px] bg-slate-200"></span>

                <div className="hidden md:flex items-center gap-1">
                  <span className="text-slate-400">Environment:</span>
                  <span className="text-emerald-600 font-bold">Production</span>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center gap-1" title="Offline Mode">
                  <span className="h-1.5 w-1.5 sm:h-2 sm:w-2 rounded-full bg-rose-500 animate-pulse shrink-0"></span>
                  <span className="text-rose-500 font-black hidden sm:inline">Offline Mode</span>
                  <span className="text-rose-500 font-black inline sm:hidden">Offline</span>
                </div>

                <span className="hidden md:inline h-2.5 w-[1px] bg-slate-200"></span>

                <div className="hidden md:flex items-center gap-1">
                  <span className="text-slate-400">Environment:</span>
                  <span className="text-amber-600 font-bold">Local Sandbox</span>
                </div>
              </>
            )}
          </div>
          <div className="text-[8px] sm:text-[9px] md:text-[10px] text-slate-400 font-medium">
            <span className="hidden md:inline">v1.0.5 - Taxcom Technologies LLP</span>
            <span className="inline md:hidden">v1.0.5</span>
          </div>
        </footer>
      </main>

      {/* Bottom Nav Bar for Mobile devices */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 h-[60px] pb-1 px-1 bg-white border-t border-slate-200 flex items-center justify-between z-40 shadow-lg gap-0.5 print:hidden">
        {navItems.slice(0, 5).map((item) => {
          const isActive = location.pathname === item.path || (item.path !== '/' && location.pathname.startsWith(item.path));
          return (
            <NavLink
              key={item.name}
              to={item.path}
              className={`flex flex-col items-center justify-center flex-1 min-w-0 h-12 rounded-lg transition-colors ${
                isActive ? 'text-[#F5405E]' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <item.icon className="h-4.5 w-4.5 shrink-0" />
              <span className="text-[9px] font-bold tracking-tight mt-1 truncate w-full text-center px-0.5">{item.name}</span>
            </NavLink>
          );
        })}
        {/* Extra Bottom Nav toggle for more items */}
        <NavLink
          to="/reports"
          className={`flex flex-col items-center justify-center flex-1 min-w-0 h-12 rounded-lg transition-colors ${
            location.pathname === '/reports' ? 'text-[#F5405E]' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <BarChart3 className="h-4.5 w-4.5 shrink-0" />
          <span className="text-[9px] font-bold tracking-tight mt-1 truncate w-full text-center px-0.5">Reports</span>
        </NavLink>
      </nav>

      <AnimatePresence>
        {showLogoutConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowLogoutConfirm(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs"
            />
            
            {/* Modal Content */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 10 }}
              transition={{ type: 'spring', duration: 0.3 }}
              className="relative w-full max-w-sm bg-white rounded-2xl shadow-xl border border-slate-200/60 p-6 overflow-hidden z-10 space-y-4"
            >
              <div className="flex items-start gap-4">
                <div className="p-3 bg-rose-50 text-[#F5405E] rounded-xl shrink-0">
                  <LogOut className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider">Secure Sign Out</h3>
                  <p className="text-xs font-semibold text-slate-500 leading-relaxed">
                    Are you sure you want to securely sign out of your Taxcom Technologies session? You will need to enter your credentials to log in again.
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowLogoutConfirm(false)}
                  className="flex-1 py-2 px-4 border border-slate-200 rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-50 active:scale-[0.98] transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleLogout}
                  className="flex-1 py-2 px-4 bg-[#F5405E] text-white rounded-xl text-xs font-bold hover:bg-rose-600 shadow-md shadow-rose-200 active:scale-[0.98] transition-all cursor-pointer"
                >
                  Yes, Sign Out
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
