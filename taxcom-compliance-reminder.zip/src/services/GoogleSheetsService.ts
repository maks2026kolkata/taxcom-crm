import { Client } from '../types';

export const syncClientToSheets = async (action: 'CREATE' | 'UPDATE' | 'DELETE', client: Client) => {
  const url = import.meta.env.VITE_APPS_SCRIPT_URL || 'https://script.google.com/macros/s/AKfycbwhLIozlRUfAP0KBvxd16kskv9FMbSVS_QQ8iwlNoayGXEzEWj2eMkit5nhxv5hCyZV-A/exec';
  
  if (!url) {
    console.warn('Google Apps Script URL is not configured.');
    return;
  }

  const payload = {
    action,
    client: {
      id: client.id,
      name: client.name || '',
      tradeName: client.tradeName || '',
      entityType: client.entityType || '',
      mobileNumber: client.mobileNumber || '',
      whatsappNumber: client.whatsappNumber || '',
      emailAddress: client.emailAddress || '',
      gstin: client.gstin || '',
      pan: client.pan || '',
      cinOrLlpin: client.cinOrLlpin || '',
      fssaiNumber: client.fssaiNumber || '',
      assignedStaffName: client.assignedStaffName || 'Unassigned',
      status: client.status || 'Active',
      notes: client.notes || ''
    },
    portalCredentials: (client.portalCredentials || []).map(pc => ({
      portalName: pc.portalName || '',
      customPortalName: pc.customPortalName || '',
      portalUrl: pc.portalUrl || '',
      userId: pc.userId || '',
      password: pc.password || ''
    })),
    customFields: (client.customFields || []).map(cf => ({
      fieldName: cf.fieldName || '',
      fieldValue: cf.fieldValue || ''
    }))
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8' // Fixed for CORS
      },
      body: JSON.stringify(payload)
    });

    console.log(`HTTP Status: ${response.status}`);
    
    const responseText = await response.text();
    console.log(`Raw Response Body: ${responseText}`);

    if (!response.ok) {
      throw new Error(`HTTP Error: ${response.status} - ${responseText}`);
    }

  } catch (error: any) {
    console.error('Google Sheets sync failed:', error);
    window.dispatchEvent(new CustomEvent('google-sheets-sync-failed', {
      detail: { error: 'Google Sheets sync failed. Firestore data saved successfully.' }
    }));
  }
};
