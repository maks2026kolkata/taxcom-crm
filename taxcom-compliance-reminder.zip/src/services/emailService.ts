export interface EmailPayload {
  to: string;
  subject: string;
  body: string;
}

export interface EmailServiceResponse {
  success: boolean;
  message: string;
}

export const sendEmail = async (payload: EmailPayload): Promise<EmailServiceResponse> => {
  try {
    const response = await fetch('/.netlify/functions/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        to: payload.to,
        subject: payload.subject,
        html: payload.body.replace(/\n/g, '<br>'),
        text: payload.body, // The textarea is plain text
      }),
    });

    const responseText = await response.text();
    console.log('HTTP Status:', response.status);
    console.log('Raw Response:', responseText);

    let data: any = {};
    try {
      if (responseText) {
        data = JSON.parse(responseText);
      } else {
        throw new Error("Empty response from server");
      }
    } catch (e) {
      throw new Error(`Server returned invalid JSON: ${responseText}`);
    }

    if (response.ok && data.success) {
      return {
        success: true,
        message: 'Email sent successfully!',
      };
    } else {
      return {
        success: false,
        message: data.error || 'Failed to send email.',
      };
    }
  } catch (error: any) {
    console.error('Error sending email via Netlify function:', error);
    return {
      success: false,
      message: error.message || 'An unexpected error occurred.',
    };
  }
};
