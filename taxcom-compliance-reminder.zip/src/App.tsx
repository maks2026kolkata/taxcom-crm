import React, { Suspense, lazy, useState } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ToastProvider, useToast } from './components/Toast';
import Layout from './components/Layout';
import { AuthProvider, useAuth } from './components/AuthContext';
import Login from './pages/Login';
import { isFirebaseEnabled } from './db/firebase';
import { processDailyAuditArchive } from './db/storage';
import EnterpriseLoader from './components/EnterpriseLoader';
import ProtectedRoute from './components/ProtectedRoute';

// Lazy Loaded Pages
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Clients = lazy(() => import('./pages/Clients'));
const Tasks = lazy(() => import('./pages/Tasks'));
const Reminders = lazy(() => import('./pages/Reminders'));
const CalendarView = lazy(() => import('./pages/CalendarView'));
const DocumentsPending = lazy(() => import('./pages/DocumentsPending'));
const Payments = lazy(() => import('./pages/Payments'));
const Reports = lazy(() => import('./pages/Reports'));
const Team = lazy(() => import('./pages/Team'));
const MessageTemplates = lazy(() => import('./pages/MessageTemplates'));
const Settings = lazy(() => import('./pages/Settings'));
const AuditLogs = lazy(() => import('./pages/AuditLogs'));

function MainAppContent() {
  const { showToast } = useToast();
  const { firebaseUser, currentUser, isLoading, isSyncing } = useAuth();
  const [showLoader, setShowLoader] = useState(true);
  const [dbNotFound, setDbNotFound] = useState(localStorage.getItem('firestore_database_not_found') === 'true');
  const isAuthenticated = !!firebaseUser && !!currentUser;
  

  React.useEffect(() => {
    const handleGoogleSheetsSyncError = (e: Event) => {
      const customEvent = e as CustomEvent;
      showToast(customEvent.detail.error, 'error');
    };
    window.addEventListener('google-sheets-sync-failed', handleGoogleSheetsSyncError);
    return () => {
      window.removeEventListener('google-sheets-sync-failed', handleGoogleSheetsSyncError);
    };
  }, [showToast]);

  React.useEffect(() => {
    const checkDb = () => {
      setDbNotFound(localStorage.getItem('firestore_database_not_found') === 'true');
    };
    checkDb();
    window.addEventListener('storage', checkDb);
    window.addEventListener('database-sync', checkDb);
    return () => {
      window.removeEventListener('storage', checkDb);
      window.removeEventListener('database-sync', checkDb);
    };
  }, []);

  React.useEffect(() => {
    const handlePermissionError = (e: Event) => {
      const customEvent = e as CustomEvent;
      console.warn("Caught permission error in UI:", customEvent.detail);
      // Just log it. Do not crash the UI.
    };
    window.addEventListener('firestore-permission-error', handlePermissionError);
    return () => {
      window.removeEventListener('firestore-permission-error', handlePermissionError);
    };
  }, []);

  React.useEffect(() => {
    if (isAuthenticated && (currentUser?.role === 'Admin' || currentUser?.role === 'Manager')) {
      processDailyAuditArchive().catch(e => {
        console.error("Daily audit archive failed", e);
      });
    }
  }, [isAuthenticated, currentUser?.role]);

  React.useEffect(() => {
    if (isLoading) {
      { console.log("setShowLoader(true)"); setShowLoader(true); }
    } else if (!isLoading && !firebaseUser) {
      { console.log("setShowLoader(false)"); setShowLoader(false); }
    }
  }, [isLoading, firebaseUser]);



  if (showLoader) {
    return (
      <EnterpriseLoader 
        isLoading={isLoading}
        isAuthenticated={isAuthenticated}
        userName={currentUser?.name || 'User'}
        onComplete={() => setShowLoader(false)}
      />
    );
  }

  return (
    <Routes>
      <Route 
        path="/login" 
        element={isAuthenticated ? <Navigate to="/" replace /> : <Login />} 
      />
      <Route 
        path="/*" 
        element={
          <ProtectedRoute>
            <Layout>
              {isSyncing && (
                <div className="bg-[#F5405E] text-white text-[10px] py-1 text-center font-black uppercase tracking-wider animate-pulse relative z-50">
                  Syncing Cloud Firestore Collections in Background...
                </div>
              )}
              {dbNotFound && (
                <div className="bg-amber-500 text-white text-[11px] py-1.5 px-4 text-center font-bold relative z-50 flex items-center justify-center gap-1.5 shadow-sm">
                  <span>⚠️ Firestore Database '(default)' not found or not initialized in project 'taxcom-technologies-crm'. Running in Local Mode. Please enable Firestore in the Firebase Console under Build &gt; Firestore Database.</span>
                </div>
              )}
              <Suspense fallback={
                <div className="min-h-[50vh] flex flex-col items-center justify-center font-sans">
                  <div className="w-8 h-8 rounded-full border-2 border-slate-200 border-t-[#F5405E] animate-spin mb-4"></div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Loading Module...</p>
                </div>
              }>
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/clients" element={<Clients />} />
                  <Route path="/tasks" element={<Tasks />} />
                  <Route path="/reminders" element={<Reminders />} />
                  <Route path="/calendar" element={<CalendarView />} />
                  <Route path="/documents" element={<DocumentsPending />} />
                  <Route path="/payments" element={<Payments />} />
                  <Route path="/reports" element={<Reports />} />
                  <Route path="/team" element={<Team />} />
                  <Route path="/templates" element={<MessageTemplates />} />
                  <Route path="/settings" element={<Settings />} />
                  <Route path="/audit-logs" element={<AuditLogs />} />
                  
                  {/* Catch all redirecting back to landing page dashboard */}
                  <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
              </Suspense>
            </Layout>
          </ProtectedRoute>
        } 
      />
    </Routes>
  );
}

export default function App() {
  React.useEffect(() => {
    // Clear old mock/dummy cached data
    localStorage.removeItem('taxcom_clients');
    localStorage.removeItem('taxcom_tasks');
    localStorage.removeItem('taxcom_payments');
    localStorage.removeItem('taxcom_reminders');
    localStorage.removeItem('taxcom_reminder_history');
    localStorage.removeItem('taxcom_audit_logs');
    localStorage.removeItem('taxcom_templates');
    localStorage.removeItem('taxcom_team');
    localStorage.removeItem('taxcom_staff');

    // Ensure currently cached user profile name is updated from "Admin" or "Manager" to the actual names
    // And clear old Manager auth states (with email meera@taxcom.co.in) so the email change takes effect immediately
    try {
      const cachedUserStr = localStorage.getItem('taxcom_current_user');
      if (cachedUserStr) {
        const cachedUser = JSON.parse(cachedUserStr);
        if (cachedUser.email === 'meera@taxcom.co.in') {
          localStorage.removeItem('taxcom_current_user');
          localStorage.removeItem('isAuthenticated');
        }
      }
    } catch (e) {
      console.error('Error migrating cached user name:', e);
    }

    // Dispatch a sync event to force update components
    window.dispatchEvent(new Event('database-sync'));
  }, []);

  return (
    <ToastProvider>
      <AuthProvider>
        <Router>
          <MainAppContent />
        </Router>
      </AuthProvider>
    </ToastProvider>
  );
}
