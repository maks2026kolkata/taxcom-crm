export type UserRole = 'Admin' | 'Manager' | 'Staff';

export interface Staff {
  id: string;
  name: string;
  role: UserRole;
  email: string;
  phone?: string;
  active: boolean;
  createdAt: string;
  designation?: string;
  avatar?: string;
}

export interface Client {
  id: string; // Custom ID or Firestore ID
  clientId: string; // User-facing Client ID e.g. TAX-001
  name: string;
  tradeName: string;
  entityType: string; // Prop, Partnership, LLP, Pvt Ltd, etc.
  mobileNumber?: string;
  whatsappNumber?: string;
  emailAddress?: string;
  gstin?: string;
  pan?: string;
  cinOrLlpin?: string;
  fssaiNumber?: string;
  address?: string;
  assignedStaffId?: string; // Staff.id
  assignedStaffName?: string; // Resolved from Staff
  status: 'Active' | 'Inactive' | 'Archived';
  notes?: string;
  createdAt: string;
  updatedAt?: string;
  isDeleted?: boolean;
  // Enhanced Fields
  primaryContactPerson?: string;
  state?: string;
  pinCode?: string;
  servicesAvailed?: string[];
  customFields?: Array<{ fieldName: string; fieldValue: string }>;
  portalCredentials?: Array<{ portalName: string; customPortalName?: string; portalUrl?: string; userId: string; password?: string }>;
}

export type ServiceCategory =
  | 'GST'
  | 'Income Tax'
  | 'TDS'
  | 'MCA or ROC'
  | 'LLP Compliance'
  | 'FSSAI'
  | 'PF'
  | 'ESI'
  | 'Professional Tax'
  | 'Trade Licence'
  | 'DSC Renewal'
  | 'Udyam'
  | 'IEC'
  | 'Trademark'
  | 'Custom Service';

export type TaskStatus =
  | 'Not Started'
  | 'Documents Pending'
  | 'Client Confirmation Pending'
  | 'In Progress'
  | 'Ready to File'
  | 'Filed'
  | 'Completed'
  | 'On Hold';

export type PaymentStatus = 'Paid' | 'Partial' | 'Pending';

export type RecurrenceType =
  | 'Monthly'
  | 'Quarterly'
  | 'Half-Yearly'
  | 'Annual'
  | 'One-Time'
  | 'Custom Recurrence';

export interface TaskPayment {
  id: string;
  date: string;
  amount: number;
  mode: string;
  transactionId: string;
  remarks: string;
}

export interface TaskDocumentDetail {
  docName: string;
  fileName?: string;
  fileData?: string; // base64 or data url
  receivedDate?: string;
  receivedBy?: string;
  remarks?: string;
}

export interface TaskNoteHistoryItem {
  id: string;
  timestamp: string;
  userName: string;
  note: string;
}

export interface ComplianceTask {
  id: string;
  clientId: string;
  clientName: string;
  serviceCategory: ServiceCategory;
  returnName: string; // e.g., GSTR-3B, ITR-1
  financialYear: string; // e.g., 2026-27
  assessmentYear?: string; // e.g., 2027-28
  filingPeriod: string; // e.g., June 2026, Q1 2026
  dueDate: string; // YYYY-MM-DD
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  assignedStaffId: string;
  assignedStaffName: string;
  status: TaskStatus;
  documentsRequired: string[]; // e.g. ["Sales Data", "Bank Statement"]
  documentsPending: string[];
  internalNotes?: string;
  
  // Payment Tracking
  professionalFees: number;
  amountReceived: number;
  outstandingAmount: number; // Calc: professionalFees - amountReceived
  paymentStatus: PaymentStatus;
  lastPaymentDate?: string;
  
  // Filing / Completion Details
  filingDate?: string;
  acknowledgementNumber?: string;
  completionDate?: string;
  
  // Recurrence
  recurrence: RecurrenceType;
  recurrenceCycle?: RecurrenceType;
  
  isDeleted?: boolean;
  createdAt: string;

  // Enhanced fields
  payments?: TaskPayment[];
  documentDetails?: Record<string, TaskDocumentDetail>;
  acknowledgementPdf?: string;
  acknowledgementPdfName?: string;
  acknowledgementDate?: string;
  notesHistory?: TaskNoteHistoryItem[];
  communication_history?: Array<{ timestamp: string; method: string; sentBy: string }>;
  lastSent?: string;
}

export type ReminderIntervalType =
  | '15 days before'
  | '7 days before'
  | '3 days before'
  | '1 day before'
  | 'On the due date'
  | 'Daily after becoming overdue'
  | 'Documents Pending';

export interface ReminderSetting {
  id: string;
  interval: ReminderIntervalType;
  enabled: boolean;
}

export interface ReminderItem {
  id: string;
  taskId: string;
  taskName: string;
  clientId: string;
  clientName: string;
  serviceCategory: ServiceCategory;
  dueDate: string;
  intervalType: ReminderIntervalType;
  status: 'Pending' | 'Sent' | 'Snoozed';
  snoozeDate?: string; // YYYY-MM-DD
  createdAt: string;
  reminderType?: string;
}

export interface ReminderHistoryItem {
  id: string;
  taskId: string;
  taskName: string;
  clientId: string;
  clientName: string;
  whatsappNumber?: string;
  emailAddress?: string;
  sentMethod: 'WhatsApp' | 'Email' | 'Phone' | 'Other';
  sentDateTime: string;
  sentBy: string;
  remarks?: string;
}

export type TemplateType =
  | 'Compliance Due Reminder'
  | 'Documents Pending'
  | 'Payment Reminder'
  | 'Overdue Filing'
  | 'Filing Completed'
  | 'OTP Request';

export interface MessageTemplate {
  id: string;
  type: string;
  title: string;
  subject: string;
  body: string;
  
  // Enhanced fields
  templateName?: string;
  category?: string;
  communicationType?: 'WhatsApp' | 'Email' | 'Both';
  emailSubject?: string;
  messageBody?: string;
  isDefault?: boolean;
  isActive?: boolean;
  createdDate?: string;
  updatedDate?: string;
}

export interface AuditLog {
  id: string;
  action: string;
  targetId: string;
  targetName: string;
  userId: string;
  userName: string;
  timestamp: string;
  oldValue?: string;
  newValue?: string;
  role?: string;
  module?: string;
  entityType?: string;
  ipAddress?: string;
  device?: string;
  browser?: string;
  platform?: string;
  sessionId?: string;
  success?: boolean;
  failureReason?: string;
  syncedToSheets?: boolean;
}
