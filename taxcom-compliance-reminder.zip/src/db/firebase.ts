// Firebase Client Configuration
// This is production-ready. If environment variables are not populated, it handles it gracefully
// by logging a warning so the app continues running in demo mode.

import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { 
  getFirestore, 
  enableIndexedDbPersistence,
  setDoc as originalSetDoc,
  updateDoc as originalUpdateDoc,
  addDoc as originalAddDoc,
  getDoc as originalGetDoc,
  deleteDoc as originalDeleteDoc,
  onSnapshot as originalOnSnapshot,
  DocumentReference,
  CollectionReference,
  DocumentSnapshot
} from 'firebase/firestore';
import { getMessaging, getToken, onMessage } from 'firebase/messaging';

const isProd = import.meta.env.PROD;

// Primary configuration from Environment Variables
const envConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID
};

// Check if any environment variable config is set
const hasEnvConfig = !!(
  envConfig.apiKey && 
  envConfig.apiKey !== "" && 
  !envConfig.apiKey.includes('mockKey')
);

let firebaseConfig: any;

if (hasEnvConfig) {
  // 1. .env (VITE_FIREBASE_*) is always the primary configuration.
  // 4. Environment variables always take priority.
  firebaseConfig = envConfig;
  console.log('[AUTH DEBUG] Using primary Firebase configuration from environment variables.');
} else if (!isProd) {
  // 3. If fallback configuration exists, it must only be enabled during development.
  // We use the JSON/fallback configuration in development if no env config is found
  firebaseConfig = {
    apiKey: "AIzaSyBVHyFlYsUdsmD81dq80ktpY0ymW7nKWrY",
    authDomain: "taxcom-technologies-crm.firebaseapp.com",
    projectId: "taxcom-technologies-crm",
    storageBucket: "taxcom-technologies-crm.firebasestorage.app",
    messagingSenderId: "497159970678",
    appId: "1:497159970678:web:12ae38b2a19bed51bda457",
    measurementId: "G-H6NWDY6KR9"
  };
  console.log('[AUTH DEBUG] No environment variables found. Using development fallback configuration.');
} else {
  // 2. firebase-applet-config.json is NEVER allowed to override .env in production.
  // In production, we must only use env variables even if they are empty
  firebaseConfig = envConfig;
  console.log('[AUTH DEBUG] Production environment: No fallback configuration allowed.');
}

let app: any = null;
let auth: any = null;
let db: any = null;
let messaging: any = null;

const isMockKey = !firebaseConfig.apiKey || 
                  firebaseConfig.apiKey.includes('mockKey') || 
                  firebaseConfig.apiKey === "";

console.log('[AUTH DEBUG] Environment variables loaded:', {
  VITE_FIREBASE_API_KEY: import.meta.env.VITE_FIREBASE_API_KEY ? 'LOADED' : 'MISSING',
  VITE_FIREBASE_AUTH_DOMAIN: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN ? 'LOADED' : 'MISSING',
  VITE_FIREBASE_PROJECT_ID: import.meta.env.VITE_FIREBASE_PROJECT_ID ? 'LOADED' : 'MISSING',
  VITE_FIREBASE_STORAGE_BUCKET: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET ? 'LOADED' : 'MISSING',
  VITE_FIREBASE_MESSAGING_SENDER_ID: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID ? 'LOADED' : 'MISSING',
  VITE_FIREBASE_APP_ID: import.meta.env.VITE_FIREBASE_APP_ID ? 'LOADED' : 'MISSING',
  VITE_FIREBASE_MEASUREMENT_ID: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID ? 'LOADED' : 'MISSING',
  VITE_APPS_SCRIPT_WEB_APP_URL: import.meta.env.VITE_APPS_SCRIPT_WEB_APP_URL ? 'LOADED' : 'MISSING',
});

export let isFirebaseEnabled = !isMockKey;

export function setFirebaseEnabled(enabled: boolean) {
  isFirebaseEnabled = enabled;
  console.log('[AUTH DEBUG] Firebase enabled state updated:', enabled);
}

if (isFirebaseEnabled) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    auth = getAuth(app);
    db = getFirestore(app);
    
    // Enable offline persistence for Firestore
    if (typeof window !== 'undefined') {
      enableIndexedDbPersistence(db).catch((err) => {
        if (err.code === 'failed-precondition') {
          console.warn('Firestore persistence failed-precondition: multiple tabs open.');
        } else if (err.code === 'unimplemented') {
          console.warn('Firestore persistence is unimplemented in this browser.');
        } else {
          console.error('Firestore persistence error:', err);
        }
      });
    }
    console.log('[AUTH DEBUG] Firebase initialized successfully.');
    
    // Only initialize messaging in browser environments with service worker support
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      try {
        messaging = getMessaging(app);
      } catch (msgErr) {
        console.warn('Failed to initialize Firebase Messaging:', msgErr);
      }
    }
  } catch (error) {
    console.error('Failed to initialize Firebase SDK:', error);
  }
}

export { app, auth, db, messaging };

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid,
      email: auth?.currentUser?.email,
      emailVerified: auth?.currentUser?.emailVerified,
      isAnonymous: auth?.currentUser?.isAnonymous,
      tenantId: auth?.currentUser?.tenantId,
      providerInfo: auth?.currentUser?.providerData?.map((provider: any) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Push Notification FCM Helper
export async function requestFCMToken(): Promise<string | null> {
  if (!isFirebaseEnabled || !messaging) {
    console.warn('FCM not available.');
    return null;
  }

  try {
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      const token = await getToken(messaging, {
        vapidKey: import.meta.env.VITE_FIREBASE_VAPID_KEY // Add this to your environment
      });
      return token;
    } else {
      console.warn('Notification permission denied.');
      return null;
    }
  } catch (error) {
    console.error('Error retrieving FCM token:', error);
    return null;
  }
}

export function onMessageReceived(callback: (payload: any) => void) {
  if (isFirebaseEnabled && messaging) {
    return onMessage(messaging, callback);
  }
  return () => {};
}

function getPathInfo(ref: any) {
  if (!ref) return { collectionPath: 'null', documentPath: 'null', fullPath: 'null' };
  let fullPath = ref.path || 'unknown';
  if (!ref.path && ref._query?.path) {
    fullPath = ref._query.path.toString();
  }
  const parts = fullPath.split('/');
  if (parts.length % 2 === 0) {
    return {
      collectionPath: parts.slice(0, -1).join('/'),
      documentPath: fullPath,
      fullPath
    };
  } else {
    return {
      collectionPath: fullPath,
      documentPath: 'N/A',
      fullPath
    };
  }
}

function triggerDiagnosticPage(operation: string, path: string, error: any) {
  const code = error?.code || 'unknown-code';
  const message = error?.message || String(error);
  
  const event = new CustomEvent('firestore-permission-error', {
    detail: { code, message, path, operation }
  });
  window.dispatchEvent(event);
}

// 1. INSTRUMENTED GETDOC
export async function getDoc(docRef: DocumentReference<any>): Promise<DocumentSnapshot<any>> {
  const { collectionPath, documentPath, fullPath } = getPathInfo(docRef);
  console.log(`[INSTRUMENTED READ] getDoc() called on:`, fullPath);
  
  try {
    const result = await originalGetDoc(docRef);
    console.log(`[INSTRUMENTED READ SUCCESS] getDoc() result:`, {
      collectionPath,
      documentPath,
      exists: result.exists(),
      data: result.data()
    });
    return result;
  } catch (error: any) {
    const code = error?.code || 'unknown';
    const message = error?.message || String(error);
    const stack = error?.stack || new Error().stack;
    
    const isPermissionError = code === 'permission-denied' || message.includes('permission');
    if (isPermissionError) {
      console.warn("Firestore Operation Denied (Permission)", { operation: "getDoc", path: fullPath, code, message });
    } else {
      console.error("Firestore Operation Failed", {
        operation: "getDoc",
        path: fullPath,
        payload: null,
        code,
        message,
        stack
      });
      console.error("Complete Error Object:", error);
    }
    
    throw error;
  }
}

// 2. INSTRUMENTED SETDOC
export async function setDoc(docRef: DocumentReference<any>, data: any, options?: any): Promise<void> {
  const { collectionPath, documentPath, fullPath } = getPathInfo(docRef);
  console.log(`[INSTRUMENTED WRITE] setDoc() called on:`, fullPath);
  console.log(`[INSTRUMENTED WRITE] setDoc() payload:`, JSON.stringify(data, null, 2));
  
  try {
    const result = options 
      ? await originalSetDoc(docRef, data, options)
      : await originalSetDoc(docRef, data);
    console.log(`[INSTRUMENTED WRITE SUCCESS] setDoc() complete on:`, fullPath);
    return result;
  } catch (error: any) {
    const code = error?.code || 'unknown';
    const message = error?.message || String(error);
    const stack = error?.stack || new Error().stack;
    
    const isPermissionError = code === 'permission-denied' || message.includes('permission');
    if (isPermissionError) {
      console.warn("Firestore Operation Denied (Permission)", { operation: "setDoc", path: fullPath, code, message });
    } else {
      console.error("Firestore Operation Failed", {
        operation: "setDoc",
        path: fullPath,
        code,
        message,
        stack
      });
      console.error("Complete Error Object:", error);
    }
    if (isPermissionError) {
      triggerDiagnosticPage("setDoc", fullPath, error);
    }
    
    throw error;
  }
}

// 3. INSTRUMENTED UPDATEDOC
export async function updateDoc(docRef: DocumentReference<any>, data: any): Promise<void> {
  const { collectionPath, documentPath, fullPath } = getPathInfo(docRef);
  console.log(`[INSTRUMENTED WRITE] updateDoc() called on:`, fullPath);
  console.log(`[INSTRUMENTED WRITE] updateDoc() payload:`, JSON.stringify(data, null, 2));
  
  try {
    const result = await originalUpdateDoc(docRef, data);
    console.log(`[INSTRUMENTED WRITE SUCCESS] updateDoc() complete on:`, fullPath);
    return result;
  } catch (error: any) {
    const code = error?.code || 'unknown';
    const message = error?.message || String(error);
    const stack = error?.stack || new Error().stack;
    
    const isPermissionError = code === 'permission-denied' || message.includes('permission');
    if (isPermissionError) {
      console.warn("Firestore Operation Denied (Permission)", { operation: "updateDoc", path: fullPath, code, message });
    } else {
      console.error("Firestore Operation Failed", {
        operation: "updateDoc",
        path: fullPath,
        code,
        message,
        stack
      });
      console.error("Complete Error Object:", error);
    }
    if (isPermissionError) {
      triggerDiagnosticPage("updateDoc", fullPath, error);
    }
    
    throw error;
  }
}

// 4. INSTRUMENTED ADDDOC
export async function addDoc(colRef: CollectionReference<any>, data: any): Promise<DocumentReference<any>> {
  const { collectionPath, documentPath, fullPath } = getPathInfo(colRef);
  console.log(`[INSTRUMENTED WRITE] addDoc() called on collection:`, fullPath);
  console.log(`[INSTRUMENTED WRITE] addDoc() payload:`, JSON.stringify(data, null, 2));
  
  try {
    const result = await originalAddDoc(colRef, data);
    console.log(`[INSTRUMENTED WRITE SUCCESS] addDoc() complete. New document ID:`, result.id);
    return result;
  } catch (error: any) {
    const code = error?.code || 'unknown';
    const message = error?.message || String(error);
    const stack = error?.stack || new Error().stack;
    
    const isPermissionError = code === 'permission-denied' || message.includes('permission');
    if (isPermissionError) {
      console.warn("Firestore Operation Denied (Permission)", { operation: "addDoc", path: fullPath, code, message });
    } else {
      console.error("Firestore Operation Failed", {
        operation: "addDoc",
        path: fullPath,
        code,
        message,
        stack
      });
      console.error("Complete Error Object:", error);
    }
    if (isPermissionError) {
      triggerDiagnosticPage("addDoc", fullPath, error);
    }
    
    throw error;
  }
}

// 5. INSTRUMENTED ONSNAPSHOT
export function onSnapshot(
  ref: any,
  ...args: any[]
): () => void {
  const { collectionPath, documentPath, fullPath } = getPathInfo(ref);
  console.log(`[INSTRUMENTED LISTEN] onSnapshot() registered on:`, fullPath);
  
  let onNext: any = null;
  let onError: any = null;
  
  if (args.length === 2) {
    onNext = args[0];
    onError = args[1];
  } else if (args.length === 3) {
    onNext = args[1];
    onError = args[2];
  } else if (args.length === 1 && typeof args[0] === 'function') {
    onNext = args[0];
  }
  
  const wrappedOnNext = (snapshot: any) => {
    console.log(`[INSTRUMENTED LISTEN SUCCESS] onSnapshot() received update on:`, fullPath, {
      empty: snapshot.empty,
      size: snapshot.size || (snapshot.exists && snapshot.exists() ? 1 : 0)
    });
    if (onNext) onNext(snapshot);
  };
  
  const wrappedOnError = (error: any) => {
    const code = error?.code || 'unknown';
    const message = error?.message || String(error);
    const stack = error?.stack || new Error().stack;
    
    const isPermissionError = code === 'permission-denied' || message.includes('permission');
    if (isPermissionError) {
      console.warn("Firestore Operation Denied (Permission)", { operation: "onSnapshot", path: fullPath, code, message });
    } else {
      console.error("Firestore Operation Failed", {
        operation: "onSnapshot",
        path: fullPath,
        payload: null,
        code,
        message,
        stack
      });
      console.error("Complete Error Object:", error);
    }
    
    if (onError) {
      onError(error);
    }
  };
  
  if (args.length === 2) {
    return originalOnSnapshot(ref, wrappedOnNext, wrappedOnError);
  } else if (args.length === 3) {
    return originalOnSnapshot(ref, args[0], wrappedOnNext, wrappedOnError);
  } else {
    return originalOnSnapshot(ref, wrappedOnNext, wrappedOnError);
  }
}

// 6. INSTRUMENTED DELETEDOC
export async function deleteDoc(docRef: DocumentReference<any>): Promise<void> {
  const { collectionPath, documentPath, fullPath } = getPathInfo(docRef);
  console.log(`[INSTRUMENTED WRITE] deleteDoc() called on:`, fullPath);
  
  try {
    const result = await originalDeleteDoc(docRef);
    console.log(`[INSTRUMENTED WRITE SUCCESS] deleteDoc() complete on:`, fullPath);
    return result;
  } catch (error: any) {
    const code = error?.code || 'unknown';
    const message = error?.message || String(error);
    const stack = error?.stack || new Error().stack;
    
    const isPermissionError = code === 'permission-denied' || message.includes('permission');
    if (isPermissionError) {
      console.warn("Firestore Operation Denied (Permission)", { operation: "deleteDoc", path: fullPath, code, message });
    } else {
      console.error("Firestore Operation Failed", {
        operation: "deleteDoc",
        path: fullPath,
        code,
        message,
        stack
      });
      console.error("Complete Error Object:", error);
    }
    if (isPermissionError) {
      triggerDiagnosticPage("deleteDoc", fullPath, error);
    }
    
    throw error;
  }
}

// For backwards compatibility in AuthContext/storage
export { setDoc as instrumentedSetDoc, updateDoc as instrumentedUpdateDoc, addDoc as instrumentedAddDoc };
