import { syncClientToSheets } from "../services/GoogleSheetsService";
import {
  Client,
  ComplianceTask,
  Staff,
  ReminderItem,
  ReminderHistoryItem,
  MessageTemplate,
  AuditLog,
  UserRole,
  ReminderIntervalType,
  ReminderSetting,
  RecurrenceType,
  TaskStatus,
  ServiceCategory
} from '../types';
import {
  SAMPLE_CLIENTS,
  SAMPLE_TASKS,
  SAMPLE_REMINDERS,
  SAMPLE_REMINDER_HISTORY,
  SAMPLE_TEMPLATES,
  SAMPLE_AUDIT_LOGS
} from '../data/sampleData';
import { db, isFirebaseEnabled, setFirebaseEnabled, auth, instrumentedSetDoc, getDoc, onSnapshot, deleteDoc } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { 
  collection, 
  doc, 
  getDocs, 
  query, 
  where,
  writeBatch
} from 'firebase/firestore';

// Storage Keys
const KEYS = {
  CLIENTS: 'taxcom_clients',
  TASKS: 'taxcom_tasks',
  STAFF: 'taxcom_staff',
  REMINDERS: 'taxcom_reminders',
  REMINDER_HISTORY: 'taxcom_reminder_history',
  TEMPLATES: 'taxcom_templates',
  AUDIT_LOGS: 'taxcom_audit_logs',
  SETTINGS_REMINDER: 'taxcom_reminder_settings',
  CURRENT_USER: 'taxcom_current_user',
};

// Default Active Reminder Intervals
const DEFAULT_REMINDER_SETTINGS: ReminderSetting[] = [
  { id: '1', interval: '15 days before', enabled: true },
  { id: '2', interval: '7 days before', enabled: true },
  { id: '3', interval: '3 days before', enabled: true },
  { id: '4', interval: '1 day before', enabled: true },
  { id: '5', interval: 'On the due date', enabled: true },
  { id: '6', interval: 'Daily after becoming overdue', enabled: true },
];

// Global in-memory cache to completely replace localStorage
const inMemoryCache: Record<string, any> = {};

// Helper to load/save JSON from local storage
function load<T>(key: string, defaultValue: T): T {
  if (!(key in inMemoryCache)) {
    inMemoryCache[key] = defaultValue;
  }
  return inMemoryCache[key] as T;
}

function save<T>(key: string, value: T, silent: boolean = false) {
  inMemoryCache[key] = value;
  if (!silent) {
    // Emit event so active screens refresh automatically
    window.dispatchEvent(new Event('database-sync'));
  }
}

// Current User State Helper
export interface CurrentUserState {
  id: string;
  name: string;
  role: UserRole;
  email: string;
  phone?: string;
  designation?: string;
  avatar?: string;
  active?: boolean;
  createdAt?: string;
  [key: string]: any;
}

export const getLoggedInUser = (): CurrentUserState | null => {
  return inMemoryCache[KEYS.CURRENT_USER] || null;
};

export const setLoggedInUser = (user: CurrentUserState | null) => {
  if (user) {
    save(KEYS.CURRENT_USER, user);
  } else {
    delete inMemoryCache[KEYS.CURRENT_USER];
  }
  window.dispatchEvent(new Event('database-sync'));
};

// Database Initialization
export function initDB() {
  load<Client[]>(KEYS.CLIENTS, SAMPLE_CLIENTS);
  load<ComplianceTask[]>(KEYS.TASKS, SAMPLE_TASKS);
  load<Staff[]>(KEYS.STAFF, []);
  load<ReminderItem[]>(KEYS.REMINDERS, SAMPLE_REMINDERS);
  load<ReminderHistoryItem[]>(KEYS.REMINDER_HISTORY, SAMPLE_REMINDER_HISTORY);
  load<MessageTemplate[]>(KEYS.TEMPLATES, SAMPLE_TEMPLATES);
  load<AuditLog[]>(KEYS.AUDIT_LOGS, SAMPLE_AUDIT_LOGS);
  load<ReminderSetting[]>(KEYS.SETTINGS_REMINDER, DEFAULT_REMINDER_SETTINGS);
}

// Ensure database has local defaults initially
initDB();

// REAL-TIME FIRESTORE SYNCHRONIZATION ENGINE
let activeSubscriptions: (() => void)[] = [];

export function stopFirestoreSync() {
  activeSubscriptions.forEach(unsub => unsub());
  activeSubscriptions = [];
}

export async function startFirestoreSync(onSyncComplete?: () => void) {
  if (!isFirebaseEnabled || !db) {
    console.log('Firebase not enabled. Sync bypassed, running in cached LocalStorage mode.');
    if (onSyncComplete) onSyncComplete();
    return;
  }

  try {
    console.log('Initializing Real-time Cloud Firestore Synchronizer...');

    // Helper to setup a real-time Firestore sync listener
    const syncCollection = (
      collectionName: string, 
      storageKey: string, 
      sampleData: any[],
      onSnap?: (items: any[]) => any[]
    ) => {
      const colRef = collection(db, collectionName);
      let unsub: (() => void) | null = null;
      
      const onNext = async (snapshot: any) => {
        if (snapshot.empty) {
          // Seed the collection if empty
          console.log(`Cloud Firestore collection "${collectionName}" is empty. Seeding defaults...`);
          try {
            const batch = writeBatch(db);
            sampleData.forEach(item => {
              const docRef = doc(db, collectionName, item.id);
              batch.set(docRef, item);
            });
            await batch.commit();
          } catch (err) {
            console.error(`Error seeding "${collectionName}":`, err);
          }
        } else {
          let items: any[] = [];
          snapshot.forEach((doc: any) => {
            items.push(doc.data());
          });
          if (onSnap) {
            items = onSnap(items);
          }
          if (storageKey === KEYS.AUDIT_LOGS) {
            const localLogs = load<AuditLog[]>(KEYS.AUDIT_LOGS, []);
            const firestoreIds = new Set(items.map(item => item.id));
            const localOnlyLogs = localLogs.filter(log => !firestoreIds.has(log.id));
            items = [...localOnlyLogs, ...items];
          }
          save(storageKey, items);
        }
      };

      const onError = (error: any) => {
        const isPermissionError = error?.code === 'permission-denied' || (error?.message && error.message.includes('permission'));
        if (isPermissionError) {
          console.warn(`[FIRESTORE] Subscription error for "${collectionName}" due to permission denial. Unsubscribing this listener only. Firebase remains enabled.`);
          if (unsub) {
            unsub();
          } else {
            // Synchronous error handler execution before unsub is assigned: defer unsubscribe to the next event loop tick
            setTimeout(() => {
              if (unsub) unsub();
            }, 0);
          }
        } else {
          console.error(`Firestore real-time subscription error for "${collectionName}":`, error);
        }
      };

      unsub = onSnapshot(colRef, onNext, onError);
      activeSubscriptions.push(unsub);
    };

    // Initialize subscriptions
    syncCollection('clients', KEYS.CLIENTS, SAMPLE_CLIENTS);
    syncCollection('tasks', KEYS.TASKS, SAMPLE_TASKS);
    syncCollection('staff', KEYS.STAFF, []);
    syncCollection('reminders', KEYS.REMINDERS, SAMPLE_REMINDERS);
    syncCollection('reminder_history', KEYS.REMINDER_HISTORY, SAMPLE_REMINDER_HISTORY);
    syncCollection('templates', KEYS.TEMPLATES, SAMPLE_TEMPLATES);
    syncCollection('audit_logs', KEYS.AUDIT_LOGS, SAMPLE_AUDIT_LOGS);
    syncCollection('reminder_settings', KEYS.SETTINGS_REMINDER, DEFAULT_REMINDER_SETTINGS);

    if (onSyncComplete) {
      // Small timeout to let initial snapshots stream in
      setTimeout(onSyncComplete, 1500);
    }
  } catch (err) {
    console.error('Error starting Firestore sync:', err);
    if (onSyncComplete) onSyncComplete();
  }
}

// Helper to recursively strip undefined fields from objects before saving to Firestore
function removeUndefined(obj: any): any {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }
  if (Array.isArray(obj)) {
    return obj.map(removeUndefined);
  }
  const result: any = {};
  for (const key of Object.keys(obj)) {
    const val = obj[key];
    if (val !== undefined) {
      result[key] = removeUndefined(val);
    }
  }
  return result;
}

const WRITE_QUEUE_KEY = 'taxcom_firestore_write_queue';

interface QueuedWrite {
  collectionName: string;
  docId: string;
  data: any;
  timestamp: number;
}

function getWriteQueue(): QueuedWrite[] {
  try {
    const raw = localStorage.getItem(WRITE_QUEUE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

function saveWriteQueue(queue: QueuedWrite[]) {
  try {
    localStorage.setItem(WRITE_QUEUE_KEY, JSON.stringify(queue));
  } catch (e) {
    console.error('Failed to save firestore write queue:', e);
  }
}

function enqueueWrite(collectionName: string, docId: string, data: any) {
  const queue = getWriteQueue();
  // Ensure no duplicate queued records for the exact same ID
  if (queue.some(item => item.collectionName === collectionName && item.docId === docId)) {
    console.log(`[QUEUE] Write for ${collectionName}/${docId} is already queued. Skipping duplicate.`);
    return;
  }
  queue.push({
    collectionName,
    docId,
    data,
    timestamp: Date.now()
  });
  saveWriteQueue(queue);
  console.log(`[QUEUE] Enqueued write for ${collectionName}/${docId}. Current queue size: ${queue.length}`);
}

export async function flushWriteQueue() {
  if (!isFirebaseEnabled || !db || !auth?.currentUser) {
    return;
  }
  const queue = getWriteQueue();
  if (queue.length === 0) return;

  console.log(`[QUEUE] Flushing ${queue.length} queued writes to Firestore...`);
  const remaining: QueuedWrite[] = [];

  for (const item of queue) {
    try {
      const cleanData = removeUndefined(item.data);
      await instrumentedSetDoc(doc(db, item.collectionName, item.docId), cleanData);
      console.log(`[QUEUE] Flushed write successfully for ${item.collectionName}/${item.docId}`);
    } catch (err: any) {
      console.error(`[QUEUE] Failed to flush write for ${item.collectionName}/${item.docId}:`, err);
      const isPermissionErr = err?.code === 'permission-denied' || (err?.message && err.message.includes('permission'));
      if (isPermissionErr) {
        console.warn(`[QUEUE] Write for ${item.collectionName}/${item.docId} failed with permission denial. Discarding from queue.`);
      } else {
        remaining.push(item);
      }
    }
  }

  saveWriteQueue(remaining);
}

// Automatically subscribe to auth state changes to flush the queue
if (isFirebaseEnabled && auth) {
  onAuthStateChanged(auth, (user) => {
    if (user) {
      console.log(`[FIRESTORE] Auth state detected: user logged in (${user.email}). Flushing queue.`);
      // Defer flush slightly to let firestore initialization complete
      setTimeout(() => {
        flushWriteQueue();
      }, 500);
    }
  });
}

// Background write helper to save document to Firestore
async function saveToCloud(collectionName: string, docId: string, data: any) {
  if (isFirebaseEnabled && db) {
    if (!auth?.currentUser) {
      console.log(`[FIRESTORE] Auth session not active. Queueing write for ${collectionName}/${docId}.`);
      enqueueWrite(collectionName, docId, data);
      return;
    }
    try {
      const cleanData = removeUndefined(data);
      await instrumentedSetDoc(doc(db, collectionName, docId), cleanData);
    } catch (err: any) {
      const isPermissionErr = err?.code === 'permission-denied' || (err?.message && err.message.includes('permission'));
      if (isPermissionErr) {
        console.warn(`[FIRESTORE] Permission denied for write [${collectionName}/${docId}]. Discarding to prevent infinite retry loop.`);
      } else {
        console.error(`Failed to write to Cloud Firestore [${collectionName}/${docId}]:`, err);
      }
    }
  }
}

// Background delete helper
export async function deleteFromCloud(collectionName: string, docId: string) {
  if (isFirebaseEnabled && db) {
    try {
      await deleteDoc(doc(db, collectionName, docId));
    } catch (err) {
      console.error(`Failed to delete from Cloud Firestore [${collectionName}/${docId}]:`, err);
      throw err;
    }
  }
}

// AUDIT LOGGER HELPER
export async function addAuditLog(
  action: string,
  targetId: string,
  targetName: string,
  oldValue?: string,
  newValue?: string
): Promise<void> {
  const logs = load<AuditLog[]>(KEYS.AUDIT_LOGS, []);
  const currentUser = getLoggedInUser();
  const newLog: AuditLog = {
    id: 'lg-' + Math.random().toString(36).substr(2, 9),
    action,
    targetId,
    targetName,
    userId: currentUser?.id || 'System',
    userName: currentUser?.name || 'System',
    timestamp: new Date().toISOString(),
    oldValue: oldValue || '',
    newValue: newValue || '',
    role: currentUser?.role || 'System',
    browser: typeof window !== 'undefined' ? navigator.userAgent.substring(0, 100) : 'Unknown',
    platform: typeof window !== 'undefined' ? navigator.platform : 'Unknown',
    sessionId: typeof sessionStorage !== 'undefined' ? sessionStorage.getItem('taxcom_session') || '' : '',
    success: true
  };
  save(KEYS.AUDIT_LOGS, [newLog, ...logs]);
  await saveToCloud('audit_logs', newLog.id, newLog);
}

// === CLIENTS CRUD ===
export const getClients = (): Client[] => {
  const clients = load<any[]>(KEYS.CLIENTS, []).filter(c => !c.isDeleted);
  const staffList = load<any[]>(KEYS.STAFF, []) || [];
  
  // Auto-migrate legacy customFields and portalCredentials
  return clients.map(c => {
    let migrated = false;
    
    // Migrate customFields
    if (c.customFields && Array.isArray(c.customFields)) {
      c.customFields = c.customFields.map((cf: any) => {
        if ('label' in cf || 'value' in cf) {
          migrated = true;
          return {
            fieldName: cf.label || cf.fieldName || '',
            fieldValue: cf.value || cf.fieldValue || ''
          };
        }
        return cf;
      });
    }

    if (c.assignedStaffId) {
      const staff = staffList.find(s => s.id === c.assignedStaffId);
      c.assignedStaffName = staff ? staff.name : 'Unassigned';
    } else {
      c.assignedStaffName = 'Unassigned';
    }

    return c as Client;
  });
};

export const getClientById = (id: string): Client | undefined => {
  return getClients().find(c => c.id === id);
};

export const createClient = (client: Omit<Client, 'id' | 'createdAt'>): Client => {
  const clients = load<Client[]>(KEYS.CLIENTS, []);
  const newClient: Client = {
    ...client,
    id: 'cl-' + Math.random().toString(36).substr(2, 9),
    createdAt: new Date().toISOString(),
  };
  save(KEYS.CLIENTS, [...clients, newClient]);
  saveToCloud('clients', newClient.id, newClient);
  addAuditLog('Client Created', newClient.id, newClient.name, undefined, `Created client ${newClient.clientId} - ${newClient.name}`);
  syncClientToSheets('CREATE', newClient);
  return newClient;
};

export const updateClient = (id: string, updatedFields: Partial<Client>): Client => {
  const clients = load<Client[]>(KEYS.CLIENTS, []);
  const index = clients.findIndex(c => c.id === id);
  if (index === -1) throw new Error('Client not found');
  
  const oldClient = clients[index];
  const updatedClient = { ...oldClient, ...updatedFields, updatedAt: new Date().toISOString() };
  clients[index] = updatedClient;
  save(KEYS.CLIENTS, clients);
  saveToCloud('clients', id, updatedClient);
  syncClientToSheets('UPDATE', updatedClient);
  
  addAuditLog(
    'Client Edited',
    id,
    updatedClient.name,
    `Status: ${oldClient.status}, Staff: ${oldClient.assignedStaffId}`,
    `Status: ${updatedClient.status}, Staff: ${updatedClient.assignedStaffId}`
  );
  
  // Cascade update clientName in other collections if name changed
  if (updatedFields.name && oldClient.name !== updatedFields.name) {
    const newName = updatedFields.name;
    
    // Update Tasks
    const tasks = load<ComplianceTask[]>(KEYS.TASKS, []);
    let tasksUpdated = false;
    tasks.forEach(t => {
      if (t.clientId === id && t.clientName !== newName) {
        t.clientName = newName;
        tasksUpdated = true;
      }
    });
    if (tasksUpdated) {
      save(KEYS.TASKS, tasks);
    }
    
    // Update Reminders
    const reminders = load<ReminderItem[]>(KEYS.REMINDERS, []);
    let remindersUpdated = false;
    reminders.forEach(r => {
      if (r.clientId === id && r.clientName !== newName) {
        r.clientName = newName;
        remindersUpdated = true;
      }
    });
    if (remindersUpdated) {
      save(KEYS.REMINDERS, reminders);
    }
    
    // Update Reminder History
    const history = load<ReminderHistoryItem[]>(KEYS.REMINDER_HISTORY, []);
    let historyUpdated = false;
    history.forEach(h => {
      if (h.clientId === id && h.clientName !== newName) {
        h.clientName = newName;
        historyUpdated = true;
      }
    });
    if (historyUpdated) {
      save(KEYS.REMINDER_HISTORY, history);
    }
    
    // Trigger global event for reactivity
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('taxcom_data_updated'));
    }
  }

  return updatedClient;
};

export const deleteClient = (id: string) => {
  const clients = load<Client[]>(KEYS.CLIENTS, []);
  const index = clients.findIndex(c => c.id === id);
  if (index !== -1) {
    const client = clients[index];
    client.isDeleted = true;
    save(KEYS.CLIENTS, clients);
    saveToCloud('clients', id, client);
    addAuditLog('Client Deleted', id, client.name, 'Active', 'Soft Deleted');
    syncClientToSheets('DELETE', client);
  }
};

export const permanentlyDeleteClient = (id: string) => {
  const clients = load<Client[]>(KEYS.CLIENTS, []);
  const index = clients.findIndex(c => c.id === id);
  if (index !== -1) {
    const client = clients[index];

    // Enforce database referential integrity across all modules
    const tasks = load<ComplianceTask[]>(KEYS.TASKS, []);
    const reminders = load<ReminderItem[]>(KEYS.REMINDERS, []);
    const history = load<ReminderHistoryItem[]>(KEYS.REMINDER_HISTORY, []);
    const auditLogs = load<AuditLog[]>(KEYS.AUDIT_LOGS, []);

    const matches = (item: any) => {
      if (!item) return false;
      return item.clientId === client.id || item.clientId === client.clientId;
    };

    const clientTasks = tasks.filter(matches);
    const clientReminders = reminders.filter(matches);
    const clientHistory = history.filter(matches);

    const hasTasks = clientTasks.length > 0;
    const hasReminders = clientReminders.length > 0 || clientHistory.length > 0;
    
    const hasDocs = clientTasks.some(t => 
      (t.documentsRequired && t.documentsRequired.length > 0) || 
      (t.documentsPending && t.documentsPending.length > 0) ||
      (t.documentDetails && Object.keys(t.documentDetails).length > 0)
    );

    const hasPayments = clientTasks.some(t => 
      t.amountReceived > 0 || 
      t.professionalFees > 0 || 
      (t.payments && t.payments.length > 0)
    );

    const hasFilingHistory = clientTasks.some(t => 
      t.status === 'Filed' || 
      t.status === 'Completed' || 
      t.filingDate || 
      t.acknowledgementNumber
    );

    const hasNotes = (client.notes && client.notes.trim()) || clientTasks.some(t => 
      t.internalNotes || 
      (t.notesHistory && t.notesHistory.length > 0)
    );

    const clientTaskIds = new Set(clientTasks.map(t => t.id));
    const hasAuditLogs = auditLogs.some(log => 
      log.targetId === client.id || 
      log.targetId === client.clientId || 
      log.targetName === client.name ||
      clientTaskIds.has(log.targetId)
    );

    if (hasTasks || hasReminders || hasDocs || hasPayments || hasFilingHistory || hasNotes || hasAuditLogs) {
      throw new Error("This client cannot be deleted because compliance records exist. Please deactivate or archive the client instead.");
    }

    const updatedClients = clients.filter(c => c.id !== id);
    save(KEYS.CLIENTS, updatedClients);
    deleteFromCloud('clients', id);
    addAuditLog('Client Permanently Deleted', id, client.name, 'Active', 'Permanently Deleted');
    syncClientToSheets('DELETE', client);
  }
};

// === COMPLIANCE TASKS CRUD ===
export const getTasks = (): ComplianceTask[] => {
  return load<ComplianceTask[]>(KEYS.TASKS, []).filter(t => !t.isDeleted);
};

export const getTaskById = (id: string): ComplianceTask | undefined => {
  return getTasks().find(t => t.id === id);
};

export const createTask = async (task: Omit<ComplianceTask, 'id' | 'createdAt' | 'outstandingAmount'>): Promise<ComplianceTask> => {
  const tasks = load<ComplianceTask[]>(KEYS.TASKS, []);
  const outstandingAmount = task.professionalFees - task.amountReceived;
  const newTask: ComplianceTask = {
    ...task,
    id: 'tk-' + Math.random().toString(36).substr(2, 9),
    outstandingAmount,
    createdAt: new Date().toISOString(),
  };
  save(KEYS.TASKS, [...tasks, newTask]);
  saveToCloud('tasks', newTask.id, newTask);
  await addAuditLog('Task Created', newTask.id, newTask.returnName, undefined, `Created task for ${newTask.clientName} - ${newTask.serviceCategory}`);
  evaluateAndSyncReminders();
  return newTask;
};

// Helper to compute next period and next due date
export function getNextRecurrence(task: ComplianceTask): { dueDate: string; period: string } {
  const currentDueDate = new Date(task.dueDate);
  let nextDueDate = new Date(task.dueDate);
  let nextPeriod = task.filingPeriod;

  const matchMonth = task.filingPeriod.match(/(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{4})/i);
  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  const recurrenceVal = task.recurrence || task.recurrenceCycle;

  switch (recurrenceVal) {
    case 'Monthly':
      nextDueDate.setMonth(currentDueDate.getMonth() + 1);
      if (matchMonth) {
        const currentMonthIdx = months.findIndex(m => m.toLowerCase() === matchMonth[1].toLowerCase());
        let currentYear = parseInt(matchMonth[2]);
        let nextMonthIdx = (currentMonthIdx + 1) % 12;
        if (nextMonthIdx === 0) currentYear += 1;
        nextPeriod = `${months[nextMonthIdx]} ${currentYear}`;
      } else {
        nextPeriod = `Next Month (After ${task.filingPeriod})`;
      }
      break;
    case 'Quarterly':
      nextDueDate.setMonth(currentDueDate.getMonth() + 3);
      if (task.filingPeriod.includes('Q1')) nextPeriod = task.filingPeriod.replace('Q1', 'Q2');
      else if (task.filingPeriod.includes('Q2')) nextPeriod = task.filingPeriod.replace('Q2', 'Q3');
      else if (task.filingPeriod.includes('Q3')) nextPeriod = task.filingPeriod.replace('Q3', 'Q4');
      else if (task.filingPeriod.includes('Q4')) {
        const yearMatch = task.filingPeriod.match(/\d{4}/);
        if (yearMatch) {
          const nextYear = parseInt(yearMatch[0]) + 1;
          nextPeriod = task.filingPeriod.replace('Q4', 'Q1').replace(yearMatch[0], nextYear.toString());
        } else {
          nextPeriod = `Q1 (Next FY)`;
        }
      } else {
        nextPeriod = `Next Quarter (After ${task.filingPeriod})`;
      }
      break;
    case 'Half-Yearly':
      nextDueDate.setMonth(currentDueDate.getMonth() + 6);
      nextPeriod = `Next Half-Year (After ${task.filingPeriod})`;
      break;
    case 'Annual':
      nextDueDate.setFullYear(currentDueDate.getFullYear() + 1);
      const yearMatches = task.filingPeriod.match(/\d{4}/g);
      if (yearMatches && yearMatches.length > 0) {
        let updatedPeriod = task.filingPeriod;
        yearMatches.forEach(y => {
          const nextY = (parseInt(y) + 1).toString();
          updatedPeriod = updatedPeriod.replace(y, nextY);
        });
        nextPeriod = updatedPeriod;
      } else {
        nextPeriod = `Next FY (After ${task.filingPeriod})`;
      }
      break;
    default:
      break;
  }

  const yyyy = nextDueDate.getFullYear();
  const mm = String(nextDueDate.getMonth() + 1).padStart(2, '0');
  const dd = String(nextDueDate.getDate()).padStart(2, '0');
  return {
    dueDate: `${yyyy}-${mm}-${dd}`,
    period: nextPeriod,
  };
}

export const updateTask = async (id: string, updatedFields: Partial<ComplianceTask>): Promise<ComplianceTask> => {
  const tasks = load<ComplianceTask[]>(KEYS.TASKS, []);
  const index = tasks.findIndex(t => t.id === id);
  if (index === -1) throw new Error('Task not found');
  
  const oldTask = tasks[index];
  
  const updatedFees = updatedFields.professionalFees !== undefined ? updatedFields.professionalFees : oldTask.professionalFees;
  const updatedReceived = updatedFields.amountReceived !== undefined ? updatedFields.amountReceived : oldTask.amountReceived;
  const outstandingAmount = updatedFees - updatedReceived;

  const changes: string[] = [];
  if (updatedFields.status && updatedFields.status !== oldTask.status) {
    changes.push(`Status changed from "${oldTask.status}" to "${updatedFields.status}"`);
  }
  if (updatedFields.dueDate && updatedFields.dueDate !== oldTask.dueDate) {
    changes.push(`Due date changed from ${oldTask.dueDate} to ${updatedFields.dueDate}`);
  }
  if (updatedFields.assignedStaffId && updatedFields.assignedStaffId !== oldTask.assignedStaffId) {
    changes.push(`Assigned staff changed to "${updatedFields.assignedStaffName}"`);
  }
  if (updatedFields.amountReceived !== undefined || updatedFields.professionalFees !== undefined) {
    changes.push(`Payment updated (Outstanding: ₹${outstandingAmount})`);
  }

  const updatedTask = {
    ...oldTask,
    ...updatedFields,
    outstandingAmount,
  };

  tasks[index] = updatedTask;
  save(KEYS.TASKS, tasks);
  saveToCloud('tasks', id, updatedTask);

  const wasNotCompleted = oldTask.status !== 'Completed';
  const isNowCompleted = updatedTask.status === 'Completed';
  const recurrenceCycle = updatedTask.recurrence || updatedTask.recurrenceCycle;
  const isRecurring = recurrenceCycle && recurrenceCycle !== 'One-Time';

  if (wasNotCompleted && isNowCompleted && isRecurring) {
    try {
      const { dueDate: nextDueDate, period: nextPeriod } = getNextRecurrence(updatedTask);
      
      const nextTaskExists = tasks.some(
        t => !t.isDeleted &&
        t.clientId === updatedTask.clientId &&
        t.returnName === updatedTask.returnName &&
        t.filingPeriod === nextPeriod
      );

      if (!nextTaskExists) {
        const nextTask: ComplianceTask = {
          ...updatedTask,
          id: 'tk-' + Math.random().toString(36).substr(2, 9),
          dueDate: nextDueDate,
          filingPeriod: nextPeriod,
          status: 'Not Started',
          documentsPending: [...updatedTask.documentsRequired],
          amountReceived: 0,
          outstandingAmount: updatedTask.professionalFees,
          paymentStatus: 'Pending',
          lastPaymentDate: undefined,
          filingDate: undefined,
          acknowledgementNumber: undefined,
          completionDate: undefined,
          payments: [],
          documentDetails: {},
          acknowledgementPdf: undefined,
          acknowledgementPdfName: undefined,
          acknowledgementDate: undefined,
          notesHistory: [],
          createdAt: new Date().toISOString(),
        };
        tasks.push(nextTask);
        save(KEYS.TASKS, tasks);
        saveToCloud('tasks', nextTask.id, nextTask);
        changes.push(`[RECURRING] Auto-generated next task for ${nextPeriod} due on ${nextDueDate}`);
      }
    } catch (e) {
      console.error('Error generating recurring task', e);
    }
  }

  if (changes.length > 0) {
    await addAuditLog('Task Updated', id, updatedTask.returnName, undefined, changes.join('; '));
  }

  evaluateAndSyncReminders();
  return updatedTask;
};

export const deleteTask = async (id: string) => {
  const tasks = load<ComplianceTask[]>(KEYS.TASKS, []);
  const index = tasks.findIndex(t => t.id === id);
  if (index !== -1) {
    const task = tasks[index];
    
    // 1. Delete actual task document
    await deleteFromCloud('tasks', id);
    
    // 2. Cascade delete reminders (they are also handled by evaluateAndSyncReminders, but doing it explicitly guarantees no orphans)
    const reminders = load<ReminderItem[]>(KEYS.REMINDERS, []);
    const orphanedReminders = reminders.filter(r => r.taskId === id);
    for (const rem of orphanedReminders) {
      await deleteFromCloud('reminders', rem.id);
    }
    const filteredReminders = reminders.filter(r => r.taskId !== id);
    save(KEYS.REMINDERS, filteredReminders, true);
    
    // 3. Cascade delete reminder_history
    const history = load<ReminderHistoryItem[]>(KEYS.REMINDER_HISTORY, []);
    const orphanedHistory = history.filter(h => h.taskId === id);
    for (const hist of orphanedHistory) {
      await deleteFromCloud('reminder_history', hist.id);
    }
    save(KEYS.REMINDER_HISTORY, history.filter(h => h.taskId !== id), true);
    
    // 4. Cascade delete audit logs referencing this task
    const logs = load<AuditLog[]>(KEYS.AUDIT_LOGS, []);
    const orphanedLogs = logs.filter(l => l.targetId === id);
    for (const log of orphanedLogs) {
      await deleteFromCloud('audit_logs', log.id);
    }
    save(KEYS.AUDIT_LOGS, logs.filter(l => l.targetId !== id), true);
    
    // Update local task state
    tasks.splice(index, 1);
    save(KEYS.TASKS, tasks);
    
    await addAuditLog('Task Deleted', id, task.returnName, 'Active', 'Permanently Deleted');
    
    evaluateAndSyncReminders();
  }
};

// === REMINDERS ===
export const evaluateAndSyncReminders = () => {
  const tasks = getTasks();
  const settings = getReminderSettings().filter(s => s.enabled);
  const oldReminders = load<ReminderItem[]>(KEYS.REMINDERS, []);
  
  // Map old reminders by ID to check for existing statuses (e.g. Snoozed, Sent) and snoozeDates
  const statusMap = new Map<string, { status: 'Pending' | 'Sent' | 'Snoozed'; snoozeDate?: string; createdAt?: string }>();
  oldReminders.forEach(rem => {
    statusMap.set(rem.id, {
      status: rem.status,
      snoozeDate: rem.snoozeDate,
      createdAt: rem.createdAt
    });
  });

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const newReminders: ReminderItem[] = [];

  tasks.forEach(task => {
    if (task.isDeleted) return;

    // We no longer remove active reminders when completed, so they can be filtered and a "Filing Completed" message can be sent.
    // if (task.status === 'Completed' || task.status === 'Filed') {
    //   return;
    // }

    const dueDateObj = new Date(task.dueDate);
    dueDateObj.setHours(0, 0, 0, 0);

    const diffTime = dueDateObj.getTime() - today.getTime();
    const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

    // 4. If Due Date is within reminder window or overdue -> Show Due Date Reminder only.
    if (diffDays <= 7) {
      let intervalType: ReminderIntervalType = 'On the due date';
      if (diffDays < 0) {
        intervalType = 'Daily after becoming overdue';
      } else if (diffDays === 0) {
        intervalType = 'On the due date';
      } else if (diffDays === 1) {
        intervalType = '1 day before';
      } else if (diffDays > 1 && diffDays <= 3) {
        intervalType = '3 days before';
      } else if (diffDays > 3 && diffDays <= 7) {
        intervalType = '7 days before';
      } else if (diffDays > 7 && diffDays <= 15) {
        intervalType = '15 days before';
      }

      // Check if this interval is enabled in settings
      const isSettingEnabled = settings.some(s => s.interval === intervalType);
      if (!isSettingEnabled) return;

      const reminderType = 'Compliance Due Reminder';
      const id = task.id + '-' + reminderType + '-' + task.dueDate;

      const preserved = statusMap.get(id);

      const rem: ReminderItem = {
        id,
        taskId: task.id,
        taskName: task.returnName,
        clientId: task.clientId,
        clientName: task.clientName,
        serviceCategory: task.serviceCategory,
        dueDate: task.dueDate,
        intervalType,
        status: preserved?.status || 'Pending',
        snoozeDate: preserved?.snoozeDate,
        createdAt: preserved?.createdAt || new Date().toISOString(),
        reminderType,
      };

      newReminders.push(rem);
    }
    // 2. Else if Required Documents Pending > 0 -> Show Document Pending Reminder.
    // 3. Else if Pending Documents = 0 -> Remove Document Reminder.
    else if (task.documentsPending && task.documentsPending.length > 0) {
      const reminderType = 'Documents Pending';
      const id = task.id + '-' + reminderType + '-' + task.dueDate;

      const preserved = statusMap.get(id);

      const rem: ReminderItem = {
        id,
        taskId: task.id,
        taskName: task.returnName,
        clientId: task.clientId,
        clientName: task.clientName,
        serviceCategory: task.serviceCategory,
        dueDate: task.dueDate,
        intervalType: 'Documents Pending',
        status: preserved?.status || 'Pending',
        snoozeDate: preserved?.snoozeDate,
        createdAt: preserved?.createdAt || new Date().toISOString(),
        reminderType,
      };

      newReminders.push(rem);
    }
  });

  // Identify which old reminders are no longer active/valid
  const newIds = new Set(newReminders.map(r => r.id));
  const removedReminders = oldReminders.filter(rem => !newIds.has(rem.id));

  // Remove the invalid reminders from Firestore/the cloud
  removedReminders.forEach(rem => {
    deleteFromCloud('reminders', rem.id);
  });

  // Save the new reminders list to local storage silently
  save(KEYS.REMINDERS, newReminders, true);

  // Sync the new reminders with Firestore
  newReminders.forEach(rem => {
    saveToCloud('reminders', rem.id, rem);
  });
};

export const getReminders = (): ReminderItem[] => {
  evaluateAndSyncReminders();
  const reminders = load<ReminderItem[]>(KEYS.REMINDERS, []);
  const todayStr = new Date().toISOString().split('T')[0];
  
  return reminders.filter(rem => {
    if (rem.status === 'Snoozed' && rem.snoozeDate && rem.snoozeDate > todayStr) {
      return false;
    }
    if (rem.status === 'Sent') {
      return false;
    }
    return true;
  });
};

export const updateReminderStatus = (id: string, status: 'Pending' | 'Sent' | 'Snoozed', snoozeDate?: string) => {
  const reminders = load<ReminderItem[]>(KEYS.REMINDERS, []);
  const index = reminders.findIndex(r => r.id === id);
  if (index !== -1) {
    reminders[index].status = status;
    if (status === 'Snoozed' && snoozeDate) {
      reminders[index].snoozeDate = snoozeDate;
    }
    save(KEYS.REMINDERS, reminders);
    saveToCloud('reminders', id, reminders[index]);
  }
};

// === REMINDER HISTORY CRUD ===
export const getReminderHistory = (): ReminderHistoryItem[] => {
  return load<ReminderHistoryItem[]>(KEYS.REMINDER_HISTORY, []);
};

export const createReminderHistory = (history: Omit<ReminderHistoryItem, 'id' | 'sentDateTime'>): ReminderHistoryItem => {
  const historyList = load<ReminderHistoryItem[]>(KEYS.REMINDER_HISTORY, []);
  const newHistory: ReminderHistoryItem = {
    ...history,
    id: 'rh-' + Math.random().toString(36).substr(2, 9),
    sentDateTime: new Date().toISOString(),
  };
  save(KEYS.REMINDER_HISTORY, [newHistory, ...historyList]);
  saveToCloud('reminder_history', newHistory.id, newHistory);

  addAuditLog(
    'Reminder Marked as Sent',
    newHistory.taskId,
    newHistory.taskName,
    undefined,
    `Sent ${newHistory.sentMethod} to ${newHistory.clientName} by ${newHistory.sentBy}`
  );

  return newHistory;
};

// === STAFF CRUD ===
const getSyncedStaffList = (): Staff[] => {
  const staffList = load<Staff[]>(KEYS.STAFF, []);
  
  // Dynamic sync: Ensure the logged-in current user's profile from AuthContext/setLoggedInUser
  // is perfectly mirrored in the staff list so their edits are always saved with their real Firebase UID!
  const loggedInUser = getLoggedInUser();
  if (loggedInUser) {
    const index = staffList.findIndex(s => s.id === loggedInUser.id || s.email?.toLowerCase() === loggedInUser.email?.toLowerCase());
    if (index !== -1) {
      // Update existing item in the local list with the latest current user data
      staffList[index] = {
        ...staffList[index],
        ...loggedInUser,
        id: loggedInUser.id, // Ensure the real Firebase UID is used!
      };
    } else {
      // Add current user to the local list with their real Firebase UID
      staffList.push({
        id: loggedInUser.id,
        name: loggedInUser.name,
        role: loggedInUser.role,
        email: loggedInUser.email,
        phone: loggedInUser.phone,
        designation: loggedInUser.designation,
        avatar: loggedInUser.avatar,
        active: loggedInUser.active ?? true,
        createdAt: loggedInUser.createdAt || new Date().toISOString()
      });
    }
    save(KEYS.STAFF, staffList, true); // Save silently to prevent infinite event loop
  }

  return staffList;
};

export const getStaff = (): Staff[] => {
  return getSyncedStaffList().filter(s => s.active !== false);
};

export const getAllStaff = (): Staff[] => {
  return getSyncedStaffList();
};

export const deleteStaff = (id: string): void => {
  const staffList = load<Staff[]>(KEYS.STAFF, []);
  const index = staffList.findIndex(s => s.id === id);
  if (index === -1) throw new Error('Staff not found');
  
  const staffName = staffList[index].name;
  const filtered = staffList.filter(s => s.id !== id);
  save(KEYS.STAFF, filtered);
  deleteFromCloud('staff', id);
  addAuditLog('Staff Member Deleted', id, staffName, undefined, `Permanently deleted staff member ${staffName}`);
};

export const createStaff = (staff: Omit<Staff, 'id' | 'createdAt'>): Staff => {
  const staffList = load<Staff[]>(KEYS.STAFF, []);
  const newStaff: Staff = {
    active: true,
    ...staff,
    id: 'st-' + Math.random().toString(36).substr(2, 9),
    createdAt: new Date().toISOString(),
  };
  save(KEYS.STAFF, [...staffList, newStaff]);
  saveToCloud('staff', newStaff.id, newStaff);
  addAuditLog('Staff Assignment Changed', newStaff.id, newStaff.name, undefined, `Added staff ${newStaff.name} with role ${newStaff.role}`);
  return newStaff;
};

export const updateStaff = (id: string, updatedFields: Partial<Staff>): Staff => {
  const staffList = load<Staff[]>(KEYS.STAFF, []);
  const index = staffList.findIndex(s => s.id === id);
  if (index === -1) throw new Error('Staff not found');
  
  const oldStaff = staffList[index];
  const updated = { ...oldStaff, ...updatedFields };

  console.log(`[INSTRUMENT] updateStaff called`);
  console.log(`1. Document ID being updated: ${id}`);
  console.log(`2. Firestore path: staff/${id}`);
  console.log(`3. Payload:`, updatedFields);
  console.log(`4. Previous value:`, oldStaff);
  console.log(`5. New value:`, updated);

  staffList[index] = updated;
  save(KEYS.STAFF, staffList);
  saveToCloud('staff', id, updated);
  
  // Update current user cache if this staff member is the currently logged in user
  const loggedInUser = getLoggedInUser();
  if (loggedInUser && (loggedInUser.id === id || loggedInUser.email?.toLowerCase() === updated.email?.toLowerCase())) {
    const updatedUser: CurrentUserState = {
      ...loggedInUser,
      ...updated,
    };
    setLoggedInUser(updatedUser);
  }
  
  addAuditLog('Staff Assignment Changed', id, updated.name, `Role: ${oldStaff.role}`, `Role: ${updated.role}, Active: ${updated.active}`);
  return updated;
};

// === MESSAGE TEMPLATES CRUD ===
export const getTemplates = (): MessageTemplate[] => {
  let list = load<MessageTemplate[]>(KEYS.TEMPLATES, []);
  if (!list || list.length === 0) {
    list = JSON.parse(JSON.stringify(SAMPLE_TEMPLATES));
  }
  let changed = false;
  
  const hasCustomMessage = list.some(t => (t.templateName === 'Custom Message') || (t.type === 'Custom Message'));
  if (!hasCustomMessage) {
    const customMsgTemplate: MessageTemplate = {
      id: 'tp-custom-msg',
      type: 'Custom Message',
      title: 'Custom Message',
      subject: 'Custom Notice from {{companyName}}',
      body: 'Dear {{clientName}},\n\n{{customMessage}}\n\nRegards,\n\nTeam {{companyName}}',
      templateName: 'Custom Message',
      category: 'General',
      communicationType: 'Both',
      emailSubject: 'Custom Notification from {{companyName}}',
      messageBody: 'Dear {{clientName}},\n\n{{customMessage}}\n\nRegards,\n\nTeam {{companyName}}',
      isDefault: false,
      isActive: true,
      createdDate: new Date().toISOString(),
      updatedDate: new Date().toISOString()
    };
    list.push(customMsgTemplate);
    changed = true;
  }
  
  // Ensure existing Custom Message templates have isDefault = false
  list.forEach(t => {
    if ((t.templateName === 'Custom Message' || t.type === 'Custom Message') && t.isDefault !== false) {
      t.isDefault = false;
      changed = true;
    }
  });

  const normalized = list.map(t => {
    let tChanged = false;
    
    if (!t.templateName) {
      t.templateName = t.type || t.title || 'Untitled';
      tChanged = true;
    }
    if (!t.category) {
      t.category = 'General';
      tChanged = true;
    }
    if (!t.communicationType) {
      t.communicationType = 'Both';
      tChanged = true;
    }
    if (!t.emailSubject) {
      t.emailSubject = t.subject || '';
      tChanged = true;
    }
    if (!t.messageBody) {
      t.messageBody = t.body || '';
      tChanged = true;
    }
    
    // Auto-update System Default templates with new signature
    if (t.isDefault) {
       const oldSig1 = /{{signature}}/g;
       const oldSig2 = /{{signature}}/g;
       const newSig = '{{signature}}';
       
       if (t.body && (oldSig1.test(t.body) || oldSig2.test(t.body))) {
         t.body = t.body.replace(oldSig1, newSig).replace(oldSig2, newSig);
         tChanged = true;
       }
       if (t.messageBody && (oldSig1.test(t.messageBody) || oldSig2.test(t.messageBody))) {
         t.messageBody = t.messageBody.replace(oldSig1, newSig).replace(oldSig2, newSig);
         tChanged = true;
       }
    }

    if (tChanged) {
      changed = true;
    }
    return t;
  });

  if (changed) {
    save(KEYS.TEMPLATES, normalized, true);
  }

  return normalized;
};

export const createTemplate = (template: Omit<MessageTemplate, 'id'>): MessageTemplate => {
  const templates = getTemplates();
  const newTemplate: MessageTemplate = {
    ...template,
    id: 'tp-user-' + Math.random().toString(36).substr(2, 9),
    type: template.templateName || 'Custom Template',
    title: template.templateName || 'Custom Template',
    subject: template.emailSubject || '',
    body: template.messageBody || '',
    createdDate: new Date().toISOString(),
    updatedDate: new Date().toISOString(),
  };
  
  save(KEYS.TEMPLATES, [...templates, newTemplate]);
  saveToCloud('templates', newTemplate.id, newTemplate);
  addAuditLog('Template Created', newTemplate.id, newTemplate.templateName || 'Untitled', undefined, `Created template "${newTemplate.templateName}"`);
  return newTemplate;
};

export const deleteTemplate = (id: string) => {
  const templates = getTemplates();
  const index = templates.findIndex(t => t.id === id);
  if (index !== -1) {
    const templateName = templates[index].templateName || 'Untitled';
    templates.splice(index, 1);
    save(KEYS.TEMPLATES, templates);
    deleteFromCloud('templates', id);
    addAuditLog('Template Deleted', id, templateName, 'Active', 'Deleted');
  }
};

export const updateTemplate = (id: string, updatedFields: Partial<MessageTemplate>): MessageTemplate => {
  const templates = getTemplates();
  const index = templates.findIndex(t => t.id === id);
  if (index === -1) throw new Error('Template not found');
  
  const oldTemplate = templates[index];
  const updated = {
    ...oldTemplate,
    ...updatedFields,
    updatedDate: new Date().toISOString(),
  };

  if (updated.templateName) {
    updated.type = updated.templateName;
    updated.title = updated.templateName;
  }
  if (updated.emailSubject) {
    updated.subject = updated.emailSubject;
  }
  if (updated.messageBody) {
    updated.body = updated.messageBody;
  }

  templates[index] = updated;
  save(KEYS.TEMPLATES, templates);
  saveToCloud('templates', id, updated);
  addAuditLog('Template Updated', id, updated.templateName || 'Untitled', undefined, `Updated template fields`);
  return updated;
};

// === REMINDER INTERVAL SETTINGS ===
export const getReminderSettings = (): ReminderSetting[] => {
  return load<ReminderSetting[]>(KEYS.SETTINGS_REMINDER, DEFAULT_REMINDER_SETTINGS);
};

export const updateReminderSettings = (settings: ReminderSetting[]) => {
  save(KEYS.SETTINGS_REMINDER, settings);
  if (isFirebaseEnabled && db) {
    settings.forEach(setting => {
      saveToCloud('reminder_settings', setting.id, setting);
    });
  }
};

// === AUDIT LOGS ===
export const getAuditLogs = (): AuditLog[] => {
  return load<AuditLog[]>(KEYS.AUDIT_LOGS, []);
};

// === SIMULATION ENGINE: DAILY SCHEDULED CLOUD FUNCTION RUN ===
export function simulateScheduledFunction(): { generatedCount: number; duplicateCount: number; details: string[] } {
  const oldReminders = load<ReminderItem[]>(KEYS.REMINDERS, []);
  const oldPendingIds = new Set(oldReminders.filter(r => r.status === 'Pending').map(r => r.id));

  // Run the state-driven evaluator
  evaluateAndSyncReminders();

  const currentReminders = load<ReminderItem[]>(KEYS.REMINDERS, []);
  const currentPending = currentReminders.filter(r => r.status === 'Pending');
  
  // Find which ones are newly generated
  const newlyGenerated = currentPending.filter(r => !oldPendingIds.has(r.id));
  const generatedCount = newlyGenerated.length;
  
  const details = newlyGenerated.map(r => `${r.clientName} – ${r.taskName} (${r.intervalType})`);

  if (generatedCount > 0) {
    addAuditLog(
      'System Reminder Auto-Run',
      'system',
      'Scheduled 8:00 AM Cron',
      undefined,
      `Generated ${generatedCount} reminders.`
    );
  }

  return {
    generatedCount,
    duplicateCount: 0,
    details,
  };
}

export const processDailyAuditArchive = async (manual = false) => {
  try {
    const statusRes = await fetch('/api/archive/status');
    const status = await statusRes.json();
    if (!status.configured) return;
  } catch (e) {
    return;
  }

  if (isFirebaseEnabled && db) {
    const lockRef = doc(db, 'system_config', 'audit_archive_lock');
    try {
      const lockDoc = await getDoc(lockRef);
      const now = Date.now();
      const ONE_DAY_MS = 24 * 60 * 60 * 1000;
      
      if (lockDoc.exists()) {
        const data = lockDoc.data();
        const lastRun = data.lastRun || 0;
        const isLocked = data.locked || false;
        const lockTime = data.lockTime || 0;
        
        // If it ran successfully in the last 24h, skip
        if (!manual && now - lastRun < ONE_DAY_MS) return;
        
        // If someone is currently running it (locked less than 10 mins ago), skip
        if (!manual && isLocked && now - lockTime < 10 * 60 * 1000) return;
      }
      
      // Acquire lock
      await instrumentedSetDoc(lockRef, { 
        locked: true, 
        lockTime: now, 
        lastRun: lockDoc.exists() ? lockDoc.data().lastRun : 0 
      }, { merge: true });
    } catch (e) {
      console.warn("Failed to check or acquire distributed lock", e);
      return;
    }
  }

  const logs = getAuditLogs();
  const cutoffDays = manual ? 20 : 30;
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - cutoffDays);
  const cutoffMs = cutoffDate.getTime();

  const toArchive = logs.filter(log => new Date(log.timestamp).getTime() < cutoffMs);
  
  if (toArchive.length === 0) {
    // Release lock if nothing to archive
    if (isFirebaseEnabled && db) {
      const lockRef = doc(db, 'system_config', 'audit_archive_lock');
      await instrumentedSetDoc(lockRef, { locked: false, lastRun: Date.now() }, { merge: true });
    }
    return;
  }

  let archivedIds: string[] = [];
  let failed = 0;
  
  const startTime = Date.now();
  
  // Archiving serially to avoid rate limits
  for (const log of toArchive) {
    try {
      if (log.syncedToSheets) {
        archivedIds.push(log.id);
        continue;
      }

      const payload = {
        timestamp: log.timestamp,
        action: log.action,
        user: log.userName || 'System',
        targetName: log.targetName || 'Unknown',
        oldValue: log.oldValue || '',
        newValue: log.newValue || '',
        logId: log.id,
        userId: log.userId,
        targetId: log.targetId
      };

      const response = await fetch('/api/archive', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      const result = await response.json();
      if (result.success) {
        archivedIds.push(log.id);
      } else {
        failed++;
      }
    } catch (e) {
      console.error('Failed to archive audit log', log.id, e);
      failed++;
    }
  }

  const processingTimeMs = Date.now() - startTime;

  if (archivedIds.length > 0 || failed > 0) {
    const remainingLogs = logs.filter(log => !archivedIds.includes(log.id));
    save(KEYS.AUDIT_LOGS, remainingLogs);
    
    let deletedCount = 0;
    for (const id of archivedIds) {
      try {
        await deleteFromCloud('audit_logs', id);
        deletedCount++;
      } catch (e) {
        console.error('Failed to delete archived log from cloud', id, e);
      }
    }
    
    addAuditLog(
      manual ? 'Manual Archive Triggered' : 'System Auto-Archive', 
      'system', 
      'Audit Retention Policy', 
      undefined, 
      `Total scanned: ${toArchive.length} | Successfully archived: ${archivedIds.length} | Failed requests: ${failed} | Deleted records: ${deletedCount} | Processing time: ${processingTimeMs}ms`
    );
  }

  // Release lock and update lastRun time
  if (isFirebaseEnabled && db) {
    const lockRef = doc(db, 'system_config', 'audit_archive_lock');
    await instrumentedSetDoc(lockRef, { locked: false, lastRun: Date.now() }, { merge: true });
  }
};

export const seedAuditLogs = () => {
  const logs = getAuditLogs();
  const baseLog = {
    action: 'Test Data',
    targetId: 't-123',
    targetName: 'Seeded Target',
    userId: 'u-123',
    userName: 'User',
    oldValue: '',
    newValue: '',
    role: 'Admin',
    browser: 'Chrome',
    platform: 'Windows',
    sessionId: 's-123',
    success: true,
    syncedToSheets: false
  };

  const days = [10, 20, 25, 29, 30, 31];
  const newLogs = days.map(d => {
    const date = new Date();
    date.setDate(date.getDate() - d);
    return {
      ...baseLog,
      id: 'lg-seed-' + d + '-' + Math.random().toString(36).substr(2, 5),
      timestamp: date.toISOString()
    };
  });
  
  save(KEYS.AUDIT_LOGS, [...newLogs, ...logs]);
};


export type SignatureStyle = 'Team {{companyName}}' | '{{staffName}} + {{companyName}}' | 'Custom';
export interface SignatureSettings {
  style: SignatureStyle;
  customText: string;
}

export const getSignatureSettings = (): SignatureSettings => {
  return load<SignatureSettings>('taxcom_signature_settings', { style: 'Team {{companyName}}', customText: '' });
};

export const setSignatureSettings = (settings: SignatureSettings): void => {
  save('taxcom_signature_settings', settings);
};
