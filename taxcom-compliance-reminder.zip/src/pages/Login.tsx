import React, { useState } from 'react';
import { useAuth } from '../components/AuthContext';
import { Shield, Mail, Lock, Sparkles, ArrowRight, Info, AlertCircle, User, CheckCircle2, ShieldCheck } from 'lucide-react';
import { isFirebaseEnabled } from '../db/firebase';
import { useNavigate } from 'react-router-dom';
import TaxcomLogo from '../components/TaxcomLogo';

type AuthMode = 'signin' | 'forgot';

export default function Login() {
  
  const { login, resetPassword, error, isLoading, isAuthenticated } = useAuth();
  
  const navigate = useNavigate();
  React.useEffect(() => {
    if (isAuthenticated) {
      console.log('[AUTH DEBUG] Dashboard navigation triggered (isAuthenticated is true in Login component).');
      navigate('/');
    }
  }, [isAuthenticated, navigate]);
  const [mode, setMode] = useState<AuthMode>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
    const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isSendingReset, setIsSendingReset] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg(null);
    if (!email) return;

    if (mode === 'signin') {
      if (!password) return;
      console.log('[AUTH DEBUG] Login button clicked with email:', email);
      try {
        await login(email, password);
        console.log('[AUTH DEBUG] Dashboard navigation triggered (login function completed).');
        navigate('/');
      } catch (err: any) {
        console.error('[AUTH DEBUG] Login handle submit failed:', err.message, err.stack || err);
        // Error is captured and set in AuthContext
      }
    } else if (mode === 'forgot') {
      setIsSendingReset(true);
      setResetSuccess(false);
      try {
        await resetPassword(email);
        setResetSuccess(true);
      } catch (err) {
        // Error is captured and set in AuthContext
      } finally {
        setIsSendingReset(false);
      }
    }
  };

  const handleModeChange = (newMode: AuthMode) => {
    setMode(newMode);
    setSuccessMsg(null);
    setResetSuccess(false);
  };

  return (
    <div className="min-h-[100dvh] w-full bg-slate-50 flex items-center justify-center p-4 md:p-8 overflow-y-auto font-sans">
      <div className="w-full max-w-5xl bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden flex flex-col lg:flex-row min-h-[550px] animate-in fade-in duration-300">
        
        {/* Left Side: Brand Accent Panel */}
        <div className="w-full lg:w-1/2 bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 p-6 md:p-8 text-white flex flex-col justify-between relative overflow-hidden shrink-0">
          {/* Subtle grid background */}
          <div className="absolute inset-0 bg-[radial-gradient(#F5405E_1px,transparent_1px)] [background-size:16px_16px] opacity-10"></div>
          
          <div className="relative z-10 flex items-center justify-start">
            <TaxcomLogo size="md" theme="dark" />
          </div>

          <div className="relative z-10 my-8 lg:my-12 space-y-4">
            <h2 className="text-2xl font-black tracking-tight leading-snug">
              Secure Corporate <span className="text-[#F5405E]">Compliance</span> Workspace.
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              Streamline client relationships, automate compliance alerts, and ensure maximum data security with our advanced CRM workspace.
            </p>
          </div>

          <div className="relative z-10 border-t border-slate-800 pt-6 flex items-center justify-between text-[10px] text-slate-500 font-semibold uppercase tracking-wider">
            <span>Taxcom Technologies</span>
            <span>v1.0.5 - Production</span>
          </div>
        </div>

        {/* Right Side: Secure Auth Forms */}
        <div className="w-full lg:w-1/2 p-6 lg:p-12 flex flex-col justify-center space-y-6">
          <div className="space-y-1.5">
            <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-rose-50 text-[#F5405E] border border-rose-100">
              <Shield className="w-3 h-3 mr-1" />
              Secure Portal
            </span>
            <h3 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              {mode === 'signin' && 'Sign In to Console'}
              {mode === 'forgot' && (
                <>
                  <ShieldCheck className="w-5 h-5 text-[#F5405E] shrink-0" />
                  <span className="font-extrabold text-slate-950">Reset Security Password</span>
                </>
              )}
            </h3>
            <p className="text-xs text-slate-500">
              {mode === 'signin' && 'Provide corporate credentials to authenticate and activate real-time team streams.'}
              {mode === 'forgot' && 'Input your authorized corporate email to receive security key decryption instructions.'}
            </p>
          </div>

          {error && (
            <div className="p-3 bg-rose-50/70 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-start gap-2.5 animate-in shake duration-250">
              <AlertCircle className="w-4 h-4 shrink-0 text-[#F5405E] mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-start gap-2.5 animate-in fade-in duration-200">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
              <span>{successMsg}</span>
            </div>
          )}

          {mode === 'forgot' && resetSuccess ? (
            <div className="space-y-6 animate-in fade-in zoom-in-95 duration-300">
              <div className="p-5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-start gap-3.5 shadow-3xs">
                <div className="p-2 bg-emerald-100 text-emerald-700 rounded-xl shrink-0">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-emerald-950">Reset Request Dispatched</h4>
                  <p className="text-xs text-emerald-800 leading-normal font-semibold">
                    If an account exists for this email, you will receive password reset instructions shortly.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleModeChange('signin')}
                className="w-full py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all shadow-md active:scale-[0.98] cursor-pointer flex items-center justify-center gap-1.5"
              >
                Back to Login
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">

              <div className="space-y-1">
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@taxcom.co.in"
                    className="w-full pl-11 pr-4 py-3 text-xs font-semibold bg-slate-50 border border-slate-200 hover:border-slate-300 focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#F5405E] focus:border-[#F5405E] rounded-xl transition-all shadow-3xs"
                  />
                </div>
              </div>

              {mode !== 'forgot' && (
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400">
                      Security Password
                    </label>
                    {mode === 'signin' && (
                      <button
                        type="button"
                        onClick={() => handleModeChange('forgot')}
                        className="text-[10px] font-bold text-[#F5405E] hover:underline"
                      >
                        Forgot Password?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-11 pr-4 py-3 text-xs font-semibold bg-slate-50 border border-slate-200 hover:border-slate-300 focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#F5405E] focus:border-[#F5405E] rounded-xl transition-all shadow-3xs"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading || isSendingReset || (mode === 'forgot' && !email.trim())}
                className="w-full py-3.5 px-5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#F5405E] rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSendingReset ? (
                  <>
                    <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    <span>Sending...</span>
                  </>
                ) : (
                  <>
                    {mode === 'signin' && 'Authorize Access'}
                    {mode === 'forgot' && 'Send Security Email'}
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}

          {/* Message about admin creation */}
          <div className="text-center pt-2 text-xs font-semibold text-slate-500 space-y-2">
            {mode === 'signin' && (
              <p className="leading-relaxed px-4 text-[11px] max-w-sm mx-auto">
                Your account is created by your Administrator. If this is your first login, click 'Forgot Password?' to set your password.
              </p>
            )}
            {mode === 'forgot' && (
              <p>
                Already have an authorized profile?{' '}
                <button
                  onClick={() => handleModeChange('signin')}
                  className="text-[#F5405E] hover:underline font-bold"
                >
                  Sign In
                </button>
              </p>
            )}
          </div>

          {/* Secure Environment Notice */}
          <div className="border-t border-slate-100 pt-4 space-y-2">
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 flex items-center">
              <Info className="w-3.5 h-3.5 mr-1.5 text-[#F5405E]" />
              Production Workspace Policy
            </h4>
            <p className="text-[10px] text-slate-500 leading-normal">
              Your data is protected with enterprise-grade security. All authentication and data operations are fully encrypted and monitored for maximum safety.
            </p>
          </div>

        </div>

      </div>
    </div>
  );
}
