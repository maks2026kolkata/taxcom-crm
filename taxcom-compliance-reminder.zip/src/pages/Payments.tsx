import React, { useState } from 'react';
import {
  CreditCard,
  IndianRupee,
  Search,
  CheckCircle,
  AlertTriangle,
  Clock,
  Filter,
  Eye,
  Plus,
  Trash2,
  CalendarDays,
  FileSpreadsheet,
  Download
} from 'lucide-react';
import { getTasks,
  getClientById, updateTask, getClients } from '../db/storage';
import { ComplianceTask } from '../types';
import { useToast } from '../components/Toast';
import { useAuth } from '../components/AuthContext';
import * as XLSX from 'xlsx';

export default function Payments() {
  const { showToast } = useToast();
  const { currentUser } = useAuth();
  const [tasks, setTasks] = useState<ComplianceTask[]>(() => getTasks());
  const clientsList = getClients();

  React.useEffect(() => {
    const handleSync = () => {
      setTasks(getTasks());
    };
    window.addEventListener('database-sync', handleSync);
    return () => window.removeEventListener('database-sync', handleSync);
  }, []);

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [filterPaymentStatus, setFilterPaymentStatus] = useState<string>('All');
  const [filterClient, setFilterClient] = useState<string>('All');

  // Modal payment capture
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<ComplianceTask | null>(null);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentDate, setPaymentDate] = useState<string>('2026-07-17');

  const refreshList = () => {
    setTasks(getTasks());
  };

  const handleOpenPaymentModal = (task: ComplianceTask) => {
    setSelectedTask(task);
    setPaymentAmount(task.outstandingAmount);
    setPaymentDate(new Date('2026-07-17').toISOString().split('T')[0]);
    setIsPaymentModalOpen(true);
  };

  const handleRecordPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask) return;

    if (paymentAmount <= 0) {
      showToast('Payment amount must be greater than zero.', 'error');
      return;
    }

    const newReceived = Number(selectedTask.amountReceived) + Number(paymentAmount);
    let newStatus: 'Paid' | 'Partial' | 'Pending' = 'Pending';

    if (newReceived >= selectedTask.professionalFees) {
      newStatus = 'Paid';
    } else if (newReceived > 0) {
      newStatus = 'Partial';
    }

    updateTask(selectedTask.id, {
      amountReceived: newReceived,
      paymentStatus: newStatus,
      lastPaymentDate: paymentDate,
    });

    showToast(
      `Successfully recorded payment of ₹${paymentAmount.toLocaleString('en-IN')} for ${getClientById(selectedTask.clientId)?.name || selectedTask.clientName}.`,
      'success'
    );

    setIsPaymentModalOpen(false);
    refreshList();
  };

  // Filter computations
  const filteredTasks = tasks.filter((t) => {
    if (t.isDeleted) return false;

    // Role based restriction
    if (currentUser?.role === 'Staff' && t.assignedStaffId !== currentUser?.id) {
      return false;
    }
    
    const query = searchQuery.toLowerCase();
    const matchSearch =
      (getClientById(t.clientId)?.name || t.clientName).toLowerCase().includes(query) ||
      t.returnName.toLowerCase().includes(query) ||
      t.serviceCategory.toLowerCase().includes(query);

    const matchPayment = filterPaymentStatus === 'All' || t.paymentStatus === filterPaymentStatus;
    const matchClient = filterClient === 'All' || t.clientId === filterClient;

    return matchSearch && matchPayment && matchClient;
  });

  // KPI calculations
  const totalFees = tasks.reduce((sum, t) => sum + t.professionalFees, 0);
  const totalReceived = tasks.reduce((sum, t) => sum + t.amountReceived, 0);
  const totalOutstanding = tasks.reduce((sum, t) => sum + t.outstandingAmount, 0);
  const collectionRate = totalFees > 0 ? Math.round((totalReceived / totalFees) * 100) : 0;

  // EXPORT TO EXCEL
  const handleExportExcel = () => {
    try {
      const dataToExport = filteredTasks.map(t => ({
        'Client Name': getClientById(t.clientId)?.name || t.clientName,
        'Service Category': t.serviceCategory,
        'Filing Return': t.returnName,
        'Filing Period': t.filingPeriod,
        'Due Date': t.dueDate,
        'Professional Fees (₹)': t.professionalFees,
        'Amount Received (₹)': t.amountReceived,
        'Outstanding Balance (₹)': t.outstandingAmount,
        'Payment Status': t.paymentStatus,
        'Last Payment Date': t.lastPaymentDate || 'N/A'
      }));

      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Payment Ledgers');
      XLSX.writeFile(workbook, `taxcom_payments_${new Date().toISOString().split('T')[0]}.xlsx`);
      showToast('Payment ledgers exported as Excel workbook successfully!', 'success');
    } catch (err: any) {
      showToast(`Export failed: ${err.message}`, 'error');
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center">
            <CreditCard className="w-6 h-6 mr-2.5 text-[#F5405E]" />
            Professional Fees & Payments Ledger
          </h1>
          <p className="text-xs text-slate-500">
            Monitor client billing, record payments received, and manage collections audit records.
          </p>
        </div>

        <button
          onClick={handleExportExcel}
          className="inline-flex items-center justify-center h-10 px-4 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 shadow-2xs cursor-pointer transition-colors"
        >
          <Download className="w-4 h-4 mr-1.5 text-[#F5405E] shrink-0" />
          Export Excel Ledger
        </button>
      </div>

      {/* KPI statistics cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex items-center space-x-4">
          <div className="p-3 bg-blue-50 text-blue-500 rounded-lg">
            <IndianRupee className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-xs font-semibold uppercase tracking-wider text-slate-400">Total Billed Fees</span>
            <span className="text-xl font-bold text-slate-900">₹{totalFees.toLocaleString('en-IN')}</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex items-center space-x-4">
          <div className="p-3 bg-emerald-50 text-emerald-500 rounded-lg">
            <CheckCircle className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-xs font-semibold uppercase tracking-wider text-slate-400">Total Collected</span>
            <span className="text-xl font-bold text-emerald-600">₹{totalReceived.toLocaleString('en-IN')}</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex items-center space-x-4">
          <div className="p-3 bg-rose-50 text-rose-500 rounded-lg">
            <AlertTriangle className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <span className="block text-xs font-semibold uppercase tracking-wider text-slate-400">Total Outstanding</span>
            <span className="text-xl font-bold text-rose-600">₹{totalOutstanding.toLocaleString('en-IN')}</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex items-center space-x-4">
          <div className="p-3 bg-violet-50 text-violet-500 rounded-lg">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-xs font-semibold uppercase tracking-wider text-slate-400">Collection Rate</span>
            <span className="text-xl font-bold text-violet-600">{collectionRate}%</span>
          </div>
        </div>
      </div>

      {/* Control Filter Panel */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by Client Name or Return Form..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-4 h-10 w-full text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-rose-500 bg-slate-50/30"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={filterPaymentStatus}
            onChange={(e) => setFilterPaymentStatus(e.target.value)}
            className="text-xs border border-slate-300 rounded-lg px-3 h-10 bg-white font-semibold text-slate-700 focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
          >
            <option value="All">All Payment Statuses</option>
            <option value="Paid">Paid</option>
            <option value="Partial">Partial</option>
            <option value="Pending">Pending</option>
          </select>

          <select
            value={filterClient}
            onChange={(e) => setFilterClient(e.target.value)}
            className="text-xs border border-slate-300 rounded-lg px-3 h-10 bg-white font-semibold text-slate-700 focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
          >
            <option value="All">All Client master</option>
            {clientsList.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main ledger table list */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        {filteredTasks.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <p className="text-sm font-semibold">No payment entries match your active filter sets.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 text-xs font-bold uppercase tracking-wider">
                  <th className="py-3 px-4">Client Name</th>
                  <th className="py-3 px-4">Filing Details</th>
                  <th className="py-3 px-4">Professional Fee</th>
                  <th className="py-3 px-4">Amount Collected</th>
                  <th className="py-3 px-4">Outstanding Due</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Last Paid On</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTasks.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-50/50">
                    <td className="py-4 px-4 font-bold text-slate-900">{getClientById(t.clientId)?.name || t.clientName}</td>
                    <td className="py-4 px-4 text-xs">
                      <span className="font-semibold block">{t.returnName}</span>
                      <span className="text-slate-400 block">{t.filingPeriod} | Due: {t.dueDate}</span>
                    </td>
                    <td className="py-4 px-4 font-semibold text-slate-700">₹{t.professionalFees}</td>
                    <td className="py-4 px-4 font-semibold text-emerald-600">₹{t.amountReceived}</td>
                    <td className="py-4 px-4 font-bold text-rose-600 bg-rose-50/40">₹{t.outstandingAmount}</td>
                    <td className="py-4 px-4">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        t.paymentStatus === 'Paid'
                          ? 'bg-emerald-100 text-emerald-800'
                          : t.paymentStatus === 'Partial'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}>
                        {t.paymentStatus}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-xs text-slate-500">
                      {t.lastPaymentDate ? (
                        <span className="inline-flex items-center">
                          <CalendarDays className="w-3.5 h-3.5 mr-1 text-slate-400" />
                          {t.lastPaymentDate}
                        </span>
                      ) : (
                        <span className="italic text-slate-300">No payment logs</span>
                      )}
                    </td>
                    <td className="py-4 px-4 text-right">
                      {t.outstandingAmount > 0 ? (
                        <button
                          onClick={() => handleOpenPaymentModal(t)}
                          className="inline-flex items-center px-3 py-1.5 text-xs font-bold text-[#F5405E] hover:text-white hover:bg-[#F5405E] border border-rose-200 hover:border-rose-600 rounded-lg shadow-2xs transition-all"
                        >
                          Record Payment
                        </button>
                      ) : (
                        <span className="text-xs text-emerald-600 font-bold">✓ Fully Cleared</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* RECORD PAYMENT MODAL DIALOG */}
      {isPaymentModalOpen && selectedTask && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl border border-slate-100 max-w-sm w-full p-6 space-y-4 animate-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">Record Client Payment</h3>
              <button onClick={() => setIsPaymentModalOpen(false)} className="text-slate-400 hover:text-slate-600 font-bold text-xs">✕</button>
            </div>

            <form onSubmit={handleRecordPaymentSubmit} className="space-y-4 text-xs">
              <div>
                <span className="block text-[10px] uppercase font-bold text-slate-400">Client Ledger</span>
                <strong className="block text-slate-900 text-sm mt-0.5">{getClientById(selectedTask.clientId)?.name || selectedTask.clientName}</strong>
                <span className="text-slate-500">{selectedTask.returnName} | Period: {selectedTask.filingPeriod}</span>
              </div>

              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded border border-slate-100">
                <div>
                  <span className="block text-[10px] uppercase font-semibold text-slate-400">Billed Fees</span>
                  <span className="font-bold text-slate-700 text-sm">₹{selectedTask.professionalFees}</span>
                </div>
                <div>
                  <span className="block text-[10px] uppercase font-semibold text-slate-400">Total Collected</span>
                  <span className="font-bold text-emerald-600 text-sm">₹{selectedTask.amountReceived}</span>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Payment Amount Received (₹) *</label>
                <input
                  type="number"
                  required
                  min={1}
                  max={selectedTask.outstandingAmount}
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(Number(e.target.value))}
                  className="block w-full border border-slate-300 rounded-lg p-2.5 bg-white font-bold text-rose-600 text-md"
                />
                <span className="block text-[9px] text-slate-400 mt-1">Outstanding is ₹{selectedTask.outstandingAmount}</span>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Receipt Date *</label>
                <input
                  type="date"
                  required
                  value={paymentDate}
                  onChange={(e) => setPaymentDate(e.target.value)}
                  className="block w-full border border-slate-300 rounded-lg p-2.5 bg-white font-bold"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsPaymentModalOpen(false)}
                  className="px-3.5 py-1.5 text-xs text-slate-500 hover:text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 text-xs font-bold text-white bg-[#F5405E] hover:bg-rose-600 rounded-lg shadow-xs"
                >
                  Confirm Payment Receipt
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
