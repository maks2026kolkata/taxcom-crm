import React, { useState, useEffect, useMemo } from 'react';
import {
  AlertTriangle,
  Clock,
  Calendar,
  CheckCircle2,
  Users,
  FileWarning,
  DollarSign,
  UserCheck,
  Play,
  RotateCcw,
  Sparkles,
  ArrowRight,
  User,
  Bell
, Trash2 } from 'lucide-react';
import {
  getTasks,
  getClients,
  getClientById,
  getReminders,
  getStaff,
  deleteStaff,
  addAuditLog,
  getAuditLogs,
  deleteFromCloud
} from '../db/storage';
import { useToast } from '../components/Toast';
import { useAuth } from '../components/AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import { db, isFirebaseEnabled, instrumentedSetDoc, onSnapshot, deleteDoc } from '../db/firebase';
import { collection, doc } from 'firebase/firestore';

// Incomplete status types
const INCOMPLETE_STATUSES = [
  'Not Started',
  'Documents Pending',
  'Client Confirmation Pending',
  'In Progress',
  'Ready to File',
  'On Hold'
];

export default function Dashboard() {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { currentUser, firebaseUser } = useAuth();

  const resolvedName = useMemo(() => {
    return currentUser?.name || 'User';
  }, [currentUser]);

  const [tasks, setTasks] = useState(() => getTasks());
  const [clients, setClients] = useState(() => getClients());
  const [reminders, setReminders] = useState(() => getReminders());
  const [staff, setStaff] = useState(() => getStaff());
  const [auditLogs, setAuditLogs] = useState(() => getAuditLogs());
  const [pendingUsers, setPendingUsers] = useState<any[]>([]);
  const [userToReject, setUserToReject] = useState<any>(null);

  useEffect(() => {
    let unsubs: (() => void)[] = [];
    
    // Always use database-sync for core entities since storage.ts handles Firestore subscriptions and emits it
    const handleSync = () => {
      setTasks(getTasks());
      setClients(getClients());
      setReminders(getReminders());
      setStaff(getStaff());
      const logs = getAuditLogs();
      logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      setAuditLogs(logs);
      
      if (!isFirebaseEnabled || !db) {
         setPendingUsers(JSON.parse(localStorage.getItem('pending_users') || '[]'));
      }
    };
    handleSync(); // Initial load
    window.addEventListener('database-sync', handleSync);
    unsubs.push(() => window.removeEventListener('database-sync', handleSync));

    if (isFirebaseEnabled && db) {
      // Real-time Firestore Listeners for entities not in storage.ts
      import('firebase/firestore').then(({ collection }) => {
        const unsubPending = onSnapshot(collection(db, 'pending_users'), (snapshot) => {
          const list: any[] = [];
          snapshot.forEach(doc => {
            list.push({ id: doc.id, ...doc.data() });
          });
          setPendingUsers(list);
        }, (error) => {
          console.warn(`[FIRESTORE] Subscription error for "pending_users":`, error);
        });
        unsubs.push(unsubPending);
      });
    }
    
    return () => {
      unsubs.forEach(unsub => unsub());
    };
  }, []);


  const confirmRejectUser = async () => {
    if (userToReject) {
      try {
        deleteStaff(userToReject.id);
        
        if (isFirebaseEnabled && db) {
          await deleteFromCloud('staff', userToReject.id);
        } else {
          setPendingUsers(getStaff().filter(s => s.id !== userToReject.id));
          window.dispatchEvent(new Event('database-sync'));
        }
        showToast(`Rejected and removed registration for ${userToReject.name}`, 'info');
      } catch (err) {
        console.error('Error rejecting user:', err);
        showToast('Failed to reject registration. Try again.', 'error');
      } finally {
        setUserToReject(null);
      }
    }
  };

  const handleApproveUser = async (userId: string) => {
    const userToApprove = pendingUsers.find((u: any) => u.id === userId);
    if (userToApprove) {
      try {
        if (isFirebaseEnabled && db) {
          // 1. Promote to staff collection
          await instrumentedSetDoc(doc(db, 'staff', userId), {
            id: userId,
            name: userToApprove.name,
            email: userToApprove.email,
            role: 'Staff',
            active: true,
            createdAt: new Date().toISOString()
          });

          // 2. Delete from pending_users
          await deleteDoc(doc(db, 'pending_users', userId));
        } else {
          const pending = JSON.parse(localStorage.getItem('pending_users') || '[]');
          const approved = JSON.parse(localStorage.getItem('approved_users') || '[]');
          
          const uApprove = pending.find((u: any) => u.id === userId) || userToApprove;
          const updatedPending = pending.filter((u: any) => u.id !== userId);
          const approvedUser = {
            ...uApprove,
            status: 'approved',
            approvedAt: new Date().toISOString()
          };
          approved.push(approvedUser);
          
          localStorage.setItem('pending_users', JSON.stringify(updatedPending));
          localStorage.setItem('approved_users', JSON.stringify(approved));
          
          // Also insert into Staff
          const staffList = JSON.parse(localStorage.getItem('taxcom_staff') || '[]');
          staffList.push({
            id: userId,
            name: userToApprove.name,
            email: userToApprove.email,
            role: 'Staff',
            active: true,
            createdAt: new Date().toISOString()
          });
          localStorage.setItem('taxcom_staff', JSON.stringify(staffList));

          setPendingUsers(updatedPending);
          window.dispatchEvent(new Event('database-sync'));
        }

        showToast(`Successfully approved ${userToApprove.name} (${userToApprove.email})`, 'success');

        addAuditLog(
          'User Approved',
          currentUser?.id || 'unknown',
          currentUser?.name || 'Admin',
          undefined,
          `Approved staff registration for ${userToApprove.name} (${userToApprove.email})`
        );
      } catch (err) {
        console.error('Error approving user:', err);
        showToast('Failed to approve user. Try again.', 'error');
      }
    }
  };

  // Real-time local date calculation
  const now = new Date();
  const todayStr = new Date(now.getTime() - (now.getTimezoneOffset() * 60000)).toISOString().split('T')[0];
  const todayObj = new Date(todayStr);

  // Helper date generators
  const addDays = (date: Date, days: number) => {
    const d = new Date(date);
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0];
  };

  const threeDaysStr = addDays(todayObj, 3);
  const sevenDaysStr = addDays(todayObj, 7);
  const thirtyDaysStr = addDays(todayObj, 30);

  // METRICS CALCULATIONS
  const currentMonthPrefix = now.toISOString().substring(0, 7);

  const activeClients = useMemo(() => clients.filter(c => c.status === 'Active'), [clients]);
  const activeClientsCount = activeClients.length;
  console.log("Active Clients:", activeClients);

  const tasksDueToday = useMemo(() => tasks.filter(t => t.dueDate === todayStr && !t.isDeleted && t.status !== 'Completed' && t.status !== 'Filed'), [tasks, todayStr]);
  console.log("Due Today Tasks:", tasksDueToday);

  const upcoming3Days = useMemo(() => tasks.filter(t => t.dueDate > todayStr && t.dueDate <= threeDaysStr && !t.isDeleted && t.status !== 'Completed' && t.status !== 'Filed'), [tasks, todayStr, threeDaysStr]);
  console.log("Upcoming 3 Days Tasks:", upcoming3Days);

  const upcoming7Days = useMemo(() => tasks.filter(t => t.dueDate > todayStr && t.dueDate <= sevenDaysStr && !t.isDeleted && t.status !== 'Completed' && t.status !== 'Filed'), [tasks, todayStr, sevenDaysStr]);
  
  const upcoming30Days = useMemo(() => tasks.filter(t => t.dueDate > todayStr && t.dueDate <= thirtyDaysStr && !t.isDeleted && t.status !== 'Completed' && t.status !== 'Filed'), [tasks, todayStr, thirtyDaysStr]);
  
  const overdueTasks = useMemo(() => tasks.filter(t => t.dueDate < todayStr && !t.isDeleted && t.status !== 'Completed' && t.status !== 'Filed'), [tasks, todayStr]);
  console.log("Overdue Tasks List:", overdueTasks);

  const docsPendingTasks = useMemo(() => tasks.filter(t => t.status === 'Documents Pending' && !t.isDeleted), [tasks]);
  
  const paymentsDueTasks = useMemo(() => tasks.filter(t => !t.isDeleted && t.paymentStatus !== 'Paid' && (t.outstandingAmount || 0) > 0), [tasks]);
  const paymentOutstandingSum = useMemo(() => paymentsDueTasks.reduce((sum, t) => sum + (t.outstandingAmount || 0), 0), [paymentsDueTasks]);
  console.log("Payments Due Tasks:", paymentsDueTasks, "Sum:", paymentOutstandingSum);

  const completedThisMonthTasks = useMemo(() => tasks.filter(t => 
    !t.isDeleted && 
    (t.status === 'Completed' || t.status === 'Filed') &&
    t.completionDate && 
    t.completionDate.startsWith(currentMonthPrefix)
  ), [tasks, currentMonthPrefix]);
  const completedThisMonth = completedThisMonthTasks.length;
  console.log("Completed This Month Tasks:", completedThisMonthTasks);

  const dueThisMonthTasks = useMemo(() => tasks.filter(t => 
    !t.isDeleted && 
    t.dueDate && 
    t.dueDate.startsWith(currentMonthPrefix)
  ), [tasks, currentMonthPrefix]);
  const dueThisMonth = dueThisMonthTasks.length;
  console.log("Due This Month Tasks:", dueThisMonthTasks);

  const filingSuccessRate = dueThisMonth > 0 ? Math.round((completedThisMonth / dueThisMonth) * 100) : 0;

  // Staff-wise Pending Tasks
  const staffPending: Record<string, { name: string; count: number; role: string }> = useMemo(() => {
    const pending: Record<string, { name: string; count: number; role: string }> = {};
    // Initialize with all active staff
    staff.forEach(s => {
      if (s.active) {
        pending[s.id] = { name: s.name, count: 0, role: s.role };
      }
    });
    tasks.forEach(t => {
      if (!t.isDeleted && INCOMPLETE_STATUSES.includes(t.status) && t.assignedStaffId) {
        if (pending[t.assignedStaffId]) {
          pending[t.assignedStaffId].count += 1;
        } else {
          // Fallback for unlisted staff
          pending[t.assignedStaffId] = { name: t.assignedStaffName || 'Unassigned', count: 1, role: 'Staff' };
        }
      }
    });
    return pending;
  }, [tasks, staff]);

  // Recent reminders (Limit to 5)
  const recentReminders = useMemo(() => [...reminders]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5), [reminders]);

  // Recent activity (Limit to 5)
  const recentActivity = useMemo(() => [...auditLogs]
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 5), [auditLogs]);

  // Upcoming critical deadlines (Limit to 5)
  const criticalDeadlines = useMemo(() => [...tasks]
    .filter(t => !t.isDeleted && INCOMPLETE_STATUSES.includes(t.status))
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    .slice(0, 5), [tasks]);

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* REJECT USER MODAL */}
      {userToReject && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-sm overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
            <div className="p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-rose-100 mx-auto flex items-center justify-center mb-4">
                <Trash2 className="w-6 h-6 text-rose-600" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Reject Registration</h3>
              <p className="text-sm text-slate-500">
                Are you sure you want to reject and delete registration for <strong>"{userToReject.name}"</strong>?
              </p>
            </div>
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-center gap-3">
              <button
                onClick={() => setUserToReject(null)}
                className="px-4 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-all"
              >
                Cancel
              </button>
              <button
                onClick={confirmRejectUser}
                className="px-4 py-2 text-sm font-bold text-white bg-rose-500 hover:bg-rose-600 rounded-lg transition-all shadow-sm"
              >
                Reject
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header and Branding Title */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl break-words">
            Welcome back, {resolvedName}
          </h1>
          <p className="mt-1.5 text-sm text-slate-500 font-medium">
            Taxcom Technologies CRM
          </p>
        </div>
      </div>

      {/* Admin Pending Approvals Section */}
      {currentUser?.role === 'Admin' && pendingUsers.length > 0 && (
        <div className="p-6 bg-amber-50/50 border border-amber-200 rounded-xl shadow-xs space-y-4 animate-in slide-in-from-top-4 duration-300">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-amber-900 flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-amber-600 shrink-0" />
              Pending Approvals ({pendingUsers.length})
            </h2>
            <span className="text-xs bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-semibold uppercase tracking-wider">
              Admin Exclusive
            </span>
          </div>
          <p className="text-xs text-amber-700 leading-normal font-medium">
            The following prospective staff profiles have created and are awaiting access authorization. Approved users will immediately be granted platform access.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {pendingUsers.map((pUser: any) => (
              <div key={pUser.id} className="bg-white p-4 rounded-xl border border-amber-200/60 shadow-3xs flex flex-col justify-between space-y-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-amber-100 text-amber-700 font-bold text-xs flex items-center justify-center uppercase shrink-0">
                      {pUser.name ? pUser.name.charAt(0) : 'U'}
                    </div>
                    <div className="overflow-hidden">
                      <h4 className="text-xs font-bold text-slate-900 truncate leading-none mb-0.5">{pUser.name}</h4>
                      <p className="text-[10px] text-slate-500 truncate leading-none">{pUser.email}</p>
                    </div>
                  </div>
                  <div className="text-[9px] text-slate-400 font-semibold uppercase tracking-wider pt-1">
                    Created: {new Date(pUser.createdAt).toLocaleDateString()}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleApproveUser(pUser.id)}
                    className="w-full py-1.5 px-3 bg-slate-900 hover:bg-slate-800 active:scale-[0.98] text-white rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Approve
                  </button>
                  <button
                    onClick={async () => {
                      if (true) {
                        try {
                          if (isFirebaseEnabled && db) {
                            await deleteDoc(doc(db, 'pending_users', pUser.id));
                          } else {
                            const pending = JSON.parse(localStorage.getItem('pending_users') || '[]');
                            const updated = pending.filter((u: any) => u.id !== pUser.id);
                            localStorage.setItem('pending_users', JSON.stringify(updated));
                            setPendingUsers(getStaff().filter(s => s.id !== userToReject.id));
                            window.dispatchEvent(new Event('database-sync'));
                          }
                          showToast(`Rejected and removed registration for ${pUser.name}`, 'info');
                        } catch (err) {
                          console.error('Error rejecting user:', err);
                          showToast('Failed to reject registration. Try again.', 'error');
                        }
                      }
                    }}
                    className="py-1.5 px-2.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg text-xs font-bold transition-all cursor-pointer"
                    title="Reject Registration"
                  >
                    Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* KPI Bento Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        
        {/* Overdue Tasks Card */}
        <div 
          onClick={() => navigate('/tasks')}
          className="bg-white border border-slate-200 rounded-xl p-4.5 shadow-xs border-l-4 border-l-red-500 flex items-start justify-between relative group hover:border-red-300 hover:scale-[1.02] hover:shadow-md cursor-pointer transition-all duration-200 active:scale-[0.98]"
        >
          <div className="space-y-1">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-tight">Overdue Tasks</span>
            <div className="text-3xl font-black text-slate-900 leading-none mt-1">{overdueTasks.length}</div>
            <p className="text-[10px] text-red-600 font-bold mt-1">Requires Immediate Action</p>
          </div>
          <div className="p-2.5 rounded-lg bg-rose-50 text-red-500">
            <AlertTriangle className="w-4.5 h-4.5" />
          </div>
        </div>

        {/* Tasks Due Today Card */}
        <div 
          onClick={() => navigate('/tasks')}
          className="bg-white border border-slate-200 rounded-xl p-4.5 shadow-xs border-l-4 border-l-amber-500 flex items-start justify-between relative group hover:border-amber-300 hover:scale-[1.02] hover:shadow-md cursor-pointer transition-all duration-200 active:scale-[0.98]"
        >
          <div className="space-y-1">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-tight">Due Today</span>
            <div className="text-3xl font-black text-slate-900 leading-none mt-1">{tasksDueToday.length}</div>
            <p className="text-[10px] text-amber-600 font-bold mt-1">Urgent follow-ups</p>
          </div>
          <div className="p-2.5 rounded-lg bg-amber-50 text-amber-600">
            <Clock className="w-4.5 h-4.5" />
          </div>
        </div>

        {/* Upcoming 3 Days Card */}
        <div 
          onClick={() => navigate('/tasks')}
          className="bg-white border border-slate-200 rounded-xl p-4.5 shadow-xs border-l-4 border-l-[#F5405E] flex items-start justify-between relative group hover:border-rose-300 hover:scale-[1.02] hover:shadow-md cursor-pointer transition-all duration-200 active:scale-[0.98]"
        >
          <div className="space-y-1">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-tight">Due in 3 Days</span>
            <div className="text-3xl font-black text-slate-900 leading-none mt-1">{upcoming3Days.length}</div>
            <p className="text-[10px] text-[#F5405E] font-bold mt-1">Upcoming deadlines</p>
          </div>
          <div className="p-2.5 rounded-lg bg-rose-50/50 text-[#F5405E]">
            <Calendar className="w-4.5 h-4.5" />
          </div>
        </div>

        {/* Payment Outstanding Card */}
        <div 
          onClick={() => navigate('/payments')}
          className="bg-white border border-slate-200 rounded-xl p-4.5 shadow-xs border-l-4 border-l-green-600 flex items-start justify-between relative group hover:border-green-300 hover:scale-[1.02] hover:shadow-md cursor-pointer transition-all duration-200 active:scale-[0.98]"
        >
          <div className="space-y-1">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-tight">Payments Due</span>
            <div className="text-2xl font-black text-slate-900 leading-none mt-1.5">₹{paymentOutstandingSum.toLocaleString('en-IN')}</div>
            <p className="text-[10px] text-green-600 font-bold mt-1">Total outstanding</p>
          </div>
          <div className="p-2.5 rounded-lg bg-emerald-50 text-green-600">
            <DollarSign className="w-4.5 h-4.5" />
          </div>
        </div>

        {/* Upcoming 7 Days Card */}
        <div 
          onClick={() => navigate('/tasks')}
          className="bg-white border border-slate-200 rounded-xl p-4.5 shadow-xs border-l-4 border-l-indigo-400 flex flex-col justify-between hover:border-indigo-200 hover:scale-[1.02] hover:shadow-md cursor-pointer transition-all duration-200 active:scale-[0.98]"
        >
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-tight">Next 7 Days</span>
            <div className="text-2xl font-black text-slate-800 mt-1">{upcoming7Days.length}</div>
          </div>
          <div className="text-[10px] text-slate-400 mt-2 font-medium">Weekly forward outlook</div>
        </div>

        {/* Upcoming 30 Days Card */}
        <div 
          onClick={() => navigate('/tasks')}
          className="bg-white border border-slate-200 rounded-xl p-4.5 shadow-xs border-l-4 border-l-violet-400 flex flex-col justify-between hover:border-violet-200 hover:scale-[1.02] hover:shadow-md cursor-pointer transition-all duration-200 active:scale-[0.98]"
        >
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-tight">Next 30 Days</span>
            <div className="text-2xl font-black text-slate-800 mt-1">{upcoming30Days.length}</div>
          </div>
          <div className="text-[10px] text-slate-400 mt-2 font-medium">Monthly forward outlook</div>
        </div>

        {/* Documents Pending Card */}
        <div 
          onClick={() => navigate('/documents')}
          className="bg-white border border-slate-200 rounded-xl p-4.5 shadow-xs border-l-4 border-l-amber-500 flex flex-col justify-between hover:border-amber-300 hover:scale-[1.02] hover:shadow-md cursor-pointer transition-all duration-200 active:scale-[0.98]"
        >
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-tight">Docs Pending</span>
            <div className="text-2xl font-black text-slate-800 mt-1">{docsPendingTasks.length}</div>
          </div>
          <div className="text-[10px] text-slate-400 mt-2 font-medium">Follow-ups required</div>
        </div>

        {/* Active Clients Card */}
        <div 
          onClick={() => navigate('/clients')}
          className="bg-white border border-slate-200 rounded-xl p-4.5 shadow-xs border-l-4 border-l-teal-500 flex flex-col justify-between hover:border-teal-300 hover:scale-[1.02] hover:shadow-md cursor-pointer transition-all duration-200 active:scale-[0.98]"
        >
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-tight">Active Clients</span>
            <div className="text-2xl font-black text-slate-800 mt-1">{activeClientsCount}</div>
          </div>
          <div className="text-[10px] text-slate-400 mt-2 font-medium">Total active clients</div>
        </div>

        {/* Completed This Month Card */}
        <div 
          onClick={() => navigate('/tasks')}
          className="bg-white border border-slate-200 rounded-xl p-4.5 shadow-xs border-l-4 border-l-emerald-500 flex flex-col justify-between hover:border-emerald-300 hover:scale-[1.02] hover:shadow-md cursor-pointer transition-all duration-200 active:scale-[0.98]"
        >
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-tight">Filed/Completed</span>
            <div className="text-2xl font-black text-emerald-600 mt-1">{completedThisMonth}</div>
          </div>
          <div className="text-[10px] text-emerald-600 mt-2 font-medium">Returns filed this month</div>
        </div>

        {/* Progress Bar overall */}
        <div className="bg-white border border-slate-200 rounded-xl p-4.5 shadow-xs border-l-4 border-l-sky-500 flex flex-col justify-between col-span-2">
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-tight">Filing Success Rate</span>
            <div className="flex items-baseline mt-1">
              <span className="text-2xl font-black text-slate-800">
                {filingSuccessRate}
                %
              </span>
              <span className="text-xs text-slate-400 ml-2 font-semibold">
                ({completedThisMonth} of {dueThisMonth} tasks due this month)
              </span>
            </div>
            {/* simple bar */}
            <div className="w-full bg-slate-100 rounded-full h-1.5 mt-3">
              <div
                className="bg-emerald-500 h-1.5 rounded-full"
                style={{ width: `${filingSuccessRate}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>


      {/* Main Grid Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Upcoming Critical Deadlines */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-lg text-slate-900 flex items-center">
              <Clock className="w-5 h-5 text-rose-500 mr-2" />
              Upcoming Deadlines (Next Incomplete)
            </h3>
            <Link to="/tasks" className="text-xs font-semibold text-[#F5405E] hover:underline flex items-center">
              View All Tasks
              <ArrowRight className="w-3 h-3 ml-1" />
            </Link>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            {criticalDeadlines.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-sm">
                No active incomplete tasks found!
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-100 text-slate-500 text-xs font-semibold uppercase tracking-wider">
                      <th className="py-3 px-4">Client Name</th>
                      <th className="py-3 px-4">Compliance / Period</th>
                      <th className="py-3 px-4">Due Date</th>
                      <th className="py-3 px-4">Priority</th>
                      <th className="py-3 px-4">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {criticalDeadlines.map((task) => {
                      const isOverdue = task.dueDate < todayStr;
                      return (
                        <tr key={task.id} className="hover:bg-slate-50/50">
                          <td className="py-3 px-4">
                            <span className="font-semibold text-slate-900 block truncate max-w-[150px]">{getClientById(task.clientId)?.name || task.clientName}</span>
                          </td>
                          <td className="py-3 px-4">
                            <span className="text-xs font-semibold text-rose-600 block">{task.serviceCategory}</span>
                            <span className="text-xs text-slate-400">{task.returnName} • {task.filingPeriod}</span>
                          </td>
                          <td className="py-3 px-4">
                            <span className={`inline-flex items-center text-xs font-semibold ${isOverdue ? 'text-rose-600' : 'text-slate-700'}`}>
                              {task.dueDate}
                              {isOverdue && <span className="ml-1 text-[9px] bg-rose-100 text-rose-600 px-1 rounded">Overdue</span>}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                                task.priority === 'Urgent'
                                  ? 'bg-rose-100 text-rose-700'
                                  : task.priority === 'High'
                                  ? 'bg-amber-100 text-amber-700'
                                  : task.priority === 'Medium'
                                  ? 'bg-blue-100 text-blue-700'
                                  : 'bg-slate-100 text-slate-700'
                              }`}
                            >
                              {task.priority}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            <span className="text-xs text-slate-600">{task.status}</span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Recent Generated Reminders & Staff Load */}
        <div className="space-y-6">
          
          {/* Active generated reminders */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg text-slate-900 flex items-center">
                <Bell className="w-5 h-5 text-rose-500 mr-2" />
                Active Alerts
              </h3>
              <Link to="/reminders" className="text-xs font-semibold text-[#F5405E] hover:underline flex items-center">
                Review Alerts
              </Link>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3 shadow-xs">
              {recentReminders.length === 0 ? (
                <div className="text-center py-6 text-slate-400 text-sm">
                  No active generated reminders yet. Use the simulation button above to populate some!
                </div>
              ) : (
                recentReminders.map((rem) => (
                  <div key={rem.id} className="p-3 bg-slate-50 border border-slate-100 rounded-lg flex items-start justify-between space-x-2">
                    <div className="space-y-1">
                      <span className="text-[11px] font-bold text-slate-500 uppercase tracking-widest block">{rem.intervalType}</span>
                      <strong className="text-xs text-slate-800 block truncate max-w-[180px]">{getClientById(rem.clientId)?.name || rem.clientName}</strong>
                      <span className="text-[11px] text-slate-500 block truncate max-w-[180px]">{rem.taskName} – due {rem.dueDate}</span>
                    </div>
                    <Link
                      to={`/reminders?id=${rem.id}`}
                      className="px-2 py-1 text-[10px] font-bold text-[#F5405E] border border-[#F5405E]/20 hover:bg-[#F5405E]/5 rounded text-center shrink-0"
                    >
                      Share
                    </Link>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Staff Workload (Business Summary) */}
          <div className="space-y-3">
            <h3 className="font-bold text-lg text-slate-900 flex items-center">
              <UserCheck className="w-5 h-5 text-rose-500 mr-2" />
              Business Summary
            </h3>
            <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-4 shadow-xs">
              <div className="grid grid-cols-2 gap-4 border-b border-slate-100 pb-4">
                <div>
                   <span className="text-[10px] text-slate-500 uppercase font-bold tracking-tight block">Total Clients</span>
                   <span className="text-xl font-black text-slate-900">{clients.length}</span>
                </div>
                <div>
                   <span className="text-[10px] text-slate-500 uppercase font-bold tracking-tight block">Active Staff</span>
                   <span className="text-xl font-black text-slate-900">{staff.filter(s => s.active).length}</span>
                </div>
              </div>
              <h4 className="text-[11px] font-bold text-slate-600 uppercase">Staff Workload</h4>
              {Object.keys(staffPending).length === 0 ? (
                <div className="text-center py-4 text-slate-400 text-sm">
                  No staff members listed.
                </div>
              ) : (
                Object.values(staffPending)
                  .sort((a, b) => b.count - a.count)
                  .map((val, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2.5">
                        <div className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold text-xs uppercase">
                          {val.name.charAt(0)}
                        </div>
                        <div>
                          <span className="text-xs font-semibold text-slate-900 block">{val.name}</span>
                          <span className="text-[9px] bg-slate-100 text-slate-500 px-1 rounded">{val.role}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${val.count > 4 ? 'bg-rose-100 text-rose-600' : 'bg-slate-100 text-slate-600'}`}>
                          {val.count} pending
                        </span>
                      </div>
                    </div>
                  ))
              )}
            </div>
          </div>
          
          {/* Recent Activity */}
          <div className="space-y-3">
            <h3 className="font-bold text-lg text-slate-900 flex items-center">
              <Clock className="w-5 h-5 text-indigo-500 mr-2" />
              Recent Activity
            </h3>
            <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3 shadow-xs">
              {recentActivity.length === 0 ? (
                <div className="text-center py-6 text-slate-400 text-sm">
                  No recent activity found.
                </div>
              ) : (
                recentActivity.map((log) => (
                  <div key={log.id} className="p-3 bg-slate-50 border border-slate-100 rounded-lg flex flex-col space-y-1">
                    <div className="flex justify-between items-start">
                      <strong className="text-xs text-slate-800">{log.action}</strong>
                      <span className="text-[10px] text-slate-400">{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <span className="text-[11px] text-slate-500">{log.details || `Performed by ${log.userName}`}</span>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
