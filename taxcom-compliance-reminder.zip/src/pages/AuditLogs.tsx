import React, { useState, useMemo, useEffect } from 'react';
import { Shield, Search, Filter, FileSpreadsheet, Activity, ChevronLeft, ChevronRight, AlertTriangle, Archive, Info, Clock, CheckCircle2, Send, XCircle } from 'lucide-react';
import * as XLSX from 'xlsx';
import { getAuditLogs, processDailyAuditArchive, addAuditLog } from '../db/storage';
import { AuditLog } from '../types';
import { useAuth } from '../components/AuthContext';
import { useToast } from '../components/Toast';

export default function AuditLogs() {
  const { currentUser } = useAuth();
  const { showToast } = useToast();
  
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAction, setFilterAction] = useState('All');
  const [filterStatus, setFilterStatus] = useState('Active');
  const [currentPage, setCurrentPage] = useState(1);
  const [isArchiving, setIsArchiving] = useState(false);
  const [archivedLogs, setArchivedLogs] = useState<AuditLog[]>([]);
  const [isFetchingArchived, setIsFetchingArchived] = useState(false);
  
  const [isSendingTest, setIsSendingTest] = useState(false);
  const [testResponse, setTestResponse] = useState<any>(null);
  const [testError, setTestError] = useState<string | null>(null);

  const itemsPerPage = 20;

  useEffect(() => {
    if (filterStatus === 'Archived' || filterStatus === 'All') {
      setIsFetchingArchived(true);
      fetch('/api/archive/logs')
        .then(res => res.json())
        .then(data => {
           if (Array.isArray(data)) {
              setArchivedLogs(data);
           }
        })
        .catch(console.error)
        .finally(() => setIsFetchingArchived(false));
    }
  }, [filterStatus]);

  useEffect(() => {
    // Check role before rendering
    if (currentUser && currentUser.role !== 'Admin' && currentUser.role !== 'Manager') {
      showToast('You do not have clearance to view system audit logs.', 'error');
    }
    setLogs(getAuditLogs());
    
    const handleSync = () => setLogs(getAuditLogs());
    window.addEventListener('database-sync', handleSync);
    return () => window.removeEventListener('database-sync', handleSync);
  }, [currentUser, showToast]);

  const enrichedLogs = useMemo(() => {
    const now = Date.now();
    return logs.map(log => {
      const ageMs = now - new Date(log.timestamp).getTime();
      const daysOld = Math.floor(ageMs / (1000 * 60 * 60 * 24));
      let status: 'Active' | 'Approaching Archive' | 'Scheduled' = 'Active';
      if (daysOld >= 30) status = 'Scheduled';
      else if (daysOld >= 20) status = 'Approaching Archive';
      return { ...log, ageMs, daysOld, archiveStatus: status };
    });
  }, [logs]);

  const logsApproaching = enrichedLogs.filter(l => l.archiveStatus === 'Approaching Archive');
  const logsScheduled = enrichedLogs.filter(l => l.archiveStatus === 'Scheduled');
  const minDaysOld = logsApproaching.length > 0 ? Math.max(...logsApproaching.map(l => l.daysOld)) : 0;
  
  let reminderLevel = 'None';
  let reminderColor = 'bg-slate-50 border-slate-200 text-slate-700';
  let reminderIcon = <Info className="w-5 h-5 text-slate-500" />;
  let daysRemaining = 0;

  if (logsScheduled.length > 0) {
    reminderLevel = 'Auto-archive Scheduled';
    reminderColor = 'bg-rose-50 border-rose-200 text-rose-800';
    reminderIcon = <AlertTriangle className="w-5 h-5 text-rose-600" />;
  } else if (minDaysOld === 29) {
    reminderLevel = 'Final Warning';
    reminderColor = 'bg-rose-50 border-rose-200 text-rose-800';
    reminderIcon = <AlertTriangle className="w-5 h-5 text-rose-600" />;
    daysRemaining = 1;
  } else if (minDaysOld >= 25) {
    reminderLevel = 'Warning';
    reminderColor = 'bg-amber-50 border-amber-200 text-amber-800';
    reminderIcon = <AlertTriangle className="w-5 h-5 text-amber-600" />;
    daysRemaining = 30 - minDaysOld;
  } else if (minDaysOld >= 20) {
    reminderLevel = 'Information';
    reminderColor = 'bg-blue-50 border-blue-200 text-blue-800';
    reminderIcon = <Info className="w-5 h-5 text-blue-600" />;
    daysRemaining = 30 - minDaysOld;
  }

  const handleManualArchive = async () => {
    if (logsScheduled.length === 0 && logsApproaching.length === 0) {
       showToast('No logs are pending archive at this moment.', 'info');
       return;
    }
    setIsArchiving(true);
    try {
      await processDailyAuditArchive(true); // true for manual
      showToast('Manual archive triggered successfully.', 'success');
      setLogs(getAuditLogs());
    } catch (e) {
      showToast('Failed to trigger manual archive.', 'error');
    } finally {
      setIsArchiving(false);
    }
  };

  const handleTestArchive = async () => {
    setIsSendingTest(true);
    setTestError(null);
    setTestResponse(null);
    const startTime = Date.now();
    const testLog = {
      timestamp: new Date().toISOString(),
      action: 'Archive Connection Test',
      user: currentUser?.name || 'System Admin',
      targetName: 'Google Sheets Endpoint',
      oldValue: '',
      newValue: '',
      logId: 'test-' + Date.now(),
      userId: currentUser?.id || 'User',
      targetId: 'endpoint-test'
    };

    try {
      const res = await fetch('/api/archive', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(testLog)
      });
      const endTime = Date.now();
      const responseTime = endTime - startTime;
      
      const data = await res.json();
      setTestResponse({ ...data, responseTime });
      
      addAuditLog('Archive Connection Test', 'system', 'Google Sheets Endpoint', undefined, data.success ? `Test succeeded in ${responseTime}ms` : `Test failed: ${data.message}`);
    } catch (err: any) {
      const endTime = Date.now();
      console.error('Test archive failed:', err);
      setTestError(err.message || 'Failed to connect to the Apps Script endpoint');
      addAuditLog('Archive Connection Test', 'system', 'Google Sheets Endpoint', undefined, `Test failed in ${endTime - startTime}ms: ${err.message}`);
    } finally {
      setIsSendingTest(false);
      setLogs(getAuditLogs());
    }
  };

  const filteredLogs = useMemo(() => {
    let result = [...enrichedLogs];

    if (filterStatus === 'Archived') {
      result = [...archivedLogs];
    } else if (filterStatus === 'All') {
      result = [...result, ...archivedLogs];
    } else if (filterStatus === 'Active') {
      result = result.filter(log => log.daysOld < 30);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(log => 
        (log.userName || '').toLowerCase().includes(q) ||
        (log.action || '').toLowerCase().includes(q) ||
        (log.targetName || '').toLowerCase().includes(q)
      );
    }

    if (filterAction !== 'All') {
      result = result.filter(log => log.action.includes(filterAction));
    }

    return result.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [enrichedLogs, archivedLogs, searchQuery, filterAction, filterStatus]);

  const paginatedLogs = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredLogs.slice(start, start + itemsPerPage);
  }, [filteredLogs, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredLogs.length / itemsPerPage);

  const exportExcel = () => {
    if (currentUser?.role !== 'Admin') {
      showToast('Only Administrators can export security audit trails.', 'error');
      return;
    }
    try {
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(filteredLogs.map(l => ({
        'Timestamp': new Date(l.timestamp).toLocaleString(),
        'Action': l.action,
        'User': l.userName,
        'Target Name': l.targetName,
        'Old Value': l.oldValue,
        'New Value': l.newValue,
        'Log ID': l.id,
        'User ID': l.userId,
        'Target ID': l.targetId
      })));
      XLSX.utils.book_append_sheet(wb, ws, 'Audit_Trail');
      XLSX.writeFile(wb, `Audit_Trail_${new Date().toISOString().split('T')[0]}.xlsx`);
      showToast('Audit trail exported successfully.', 'success');
    } catch (e) {
      showToast('Export failed.', 'error');
    }
  };

  if (currentUser?.role !== 'Admin' && currentUser?.role !== 'Manager') {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh]">
        <Shield className="w-12 h-12 text-slate-300 mb-4" />
        <h2 className="text-lg font-bold text-slate-700">Access Restricted</h2>
        <p className="text-sm text-slate-500">Only Admin and Manager roles can access the Audit Trail.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-full">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Shield className="w-7 h-7 text-[#F5405E]" />
            Enterprise Audit Trail
          </h1>
          <p className="text-xs font-semibold text-slate-500 mt-1 uppercase tracking-wider">Immutable Security & Activity Logs</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-2">
          {currentUser?.role === 'Admin' && (
            <button
              onClick={exportExcel}
              className="relative flex items-center gap-2 px-4 py-2 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-900 transition-colors"
            >
              <FileSpreadsheet className="w-4 h-4" />
              Export Trail
              {(logsScheduled.length > 0 || logsApproaching.length > 0) && (
                <span className="absolute -top-1.5 -right-1.5 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white shadow-sm ring-2 ring-white">
                  {logsScheduled.length + logsApproaching.length}
                </span>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Archive Reminder Card */}
      {(logsApproaching.length > 0 || logsScheduled.length > 0 || isArchiving) && (
        <div className={`p-4 rounded-xl border ${reminderColor} shadow-sm flex flex-col md:flex-row gap-4 items-center justify-between`}>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white rounded-lg shadow-xs">
              {reminderIcon}
            </div>
            <div>
              <h3 className="font-bold text-sm">{reminderLevel}</h3>
              <p className="text-xs opacity-90 mt-0.5">
                {logsScheduled.length > 0 
                  ? `${logsScheduled.length} logs are scheduled for immediate auto-archive.`
                  : `${logsApproaching.length} logs are approaching archive. ${daysRemaining} day${daysRemaining !== 1 ? 's' : ''} remaining until next auto-archive.`}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex gap-4 px-4 border-r border-current/10">
              <div className="flex flex-col items-center">
                <span className="text-lg font-black">{logsApproaching.length}</span>
                <span className="text-[10px] uppercase font-bold tracking-wider opacity-70">Approaching</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-lg font-black">{logsScheduled.length}</span>
                <span className="text-[10px] uppercase font-bold tracking-wider opacity-70">Scheduled</span>
              </div>
            </div>
            {currentUser?.role === 'Admin' && (
              <button 
                onClick={handleManualArchive}
                disabled={isArchiving || (logsApproaching.length === 0 && logsScheduled.length === 0)}
                className="flex items-center gap-2 px-4 py-2 bg-white/50 hover:bg-white text-current rounded-lg text-xs font-bold transition-colors disabled:opacity-50"
              >
                {isArchiving ? (
                  <Activity className="w-4 h-4 animate-spin" />
                ) : (
                  <Archive className="w-4 h-4" />
                )}
                {isArchiving ? 'Archiving...' : 'Archive Now'}
              </button>
            )}
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto flex-1">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by user, action, target..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-4 h-10 border border-slate-300 rounded-lg text-sm bg-white focus:outline-none focus:border-[#F5405E] focus:ring-1 focus:ring-[#F5405E]"
            />
          </div>
          
          <div className="relative w-full sm:w-48 shrink-0">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <select
              value={filterStatus}
              onChange={(e) => {
                setFilterStatus(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-4 h-10 border border-slate-300 rounded-lg text-sm bg-white focus:outline-none focus:border-[#F5405E] focus:ring-1 focus:ring-[#F5405E] appearance-none cursor-pointer"
            >
              <option value="Active">Active (Firestore)</option>
              <option value="Archived">Archived (Google Sheets)</option>
              <option value="All">All (Active + Archived via Google Sheets lookup)</option>
            </select>
          </div>
          
          <div className="relative w-full sm:w-48 shrink-0">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <select
              value={filterAction}
              onChange={(e) => {
                setFilterAction(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-4 h-10 border border-slate-300 rounded-lg text-sm bg-white focus:outline-none focus:border-[#F5405E] focus:ring-1 focus:ring-[#F5405E] appearance-none cursor-pointer"
            >
              <option value="All">All Actions</option>
              <option value="Login">Logins</option>
              <option value="Logout">Logouts</option>
              <option value="Created">Creations</option>
              <option value="Updated">Updates</option>
              <option value="Deleted">Deletions</option>
            </select>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs font-bold text-slate-500 bg-slate-100 px-3 h-10 flex items-center rounded-lg whitespace-nowrap">
            {filteredLogs.length} {filterStatus === 'Active' ? 'Active ' : ''}Records Found
          </div>
        </div>
      </div>
      
      <div className="bg-slate-800 text-white p-4 rounded-xl flex items-center justify-between shadow-sm">
        <div>
          <h3 className="font-bold">Showing {filterStatus === 'Active' ? 'Active Audit Logs (Last 30 Days)' : filterStatus === 'Archived' ? 'Archived Audit Logs (Google Sheets)' : 'All Audit Logs'}</h3>
          <p className="text-sm opacity-80 mt-0.5">Older records have been archived securely to Google Sheets.</p>
        </div>
        {isFetchingArchived && (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-white/10 rounded-lg text-sm">
            <Clock className="w-4 h-4 animate-spin" /> Fetching from Sheets...
          </div>
        )}
      </div>

      {currentUser?.role === 'Admin' && (
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Archive Status & Diagnostics</h3>
              <p className="text-xs text-slate-500 mt-1">Admin-only tools to verify connection to Google Apps Script endpoint.</p>
            </div>
            <button
              onClick={handleTestArchive}
              disabled={isSendingTest}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-lg transition-colors disabled:opacity-50"
            >
              {isSendingTest ? <Clock className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              {isSendingTest ? 'Sending...' : 'Send Test Audit Record'}
            </button>
          </div>
          {(testResponse || testError) && (
            <div className="p-4">
              <div className={`p-4 rounded-lg border ${testError || (testResponse && !testResponse.success) ? 'bg-rose-50 border-rose-100' : 'bg-emerald-50 border-emerald-100'}`}>
                <div className="flex items-start gap-3">
                  {testError || (testResponse && !testResponse.success) ? (
                    <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  ) : (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1 min-w-0">
                    <h4 className={`text-sm font-bold ${testError || (testResponse && !testResponse.success) ? 'text-rose-900' : 'text-emerald-900'}`}>
                      {testError ? 'Request Failed' : testResponse?.success ? 'Success! Row inserted.' : 'Request Completed with Errors'}
                    </h4>
                    {testError ? (
                      <p className="text-sm text-rose-700 mt-1">{testError}</p>
                    ) : (
                      <div className="mt-2 text-sm space-y-2">
                        <p className={`font-medium ${testResponse?.success ? 'text-emerald-700' : 'text-rose-700'}`}>
                          {testResponse?.message || (testResponse?.success ? 'HTTP Response OK.' : 'Request completed but reported failure.')}
                        </p>
                        {testResponse?.responseTime && (
                          <div className="flex items-center gap-2 text-slate-700">
                            <span className="font-bold">Response Time:</span>
                            <span className="font-mono bg-white/60 px-1.5 py-0.5 rounded border border-slate-200">{testResponse.responseTime}ms</span>
                          </div>
                        )}
                        {testResponse?.statusCode && (
                          <div className="flex items-center gap-2 text-slate-700">
                            <span className="font-bold">HTTP Status Code:</span>
                            <span className="font-mono bg-white/60 px-1.5 py-0.5 rounded border border-slate-200">{testResponse.statusCode}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Table container with overflow handled */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="py-3 px-4 text-xs font-black text-slate-500 uppercase tracking-wider whitespace-nowrap">Timestamp</th>
                <th className="py-3 px-4 text-xs font-black text-slate-500 uppercase tracking-wider">User</th>
                <th className="py-3 px-4 text-xs font-black text-slate-500 uppercase tracking-wider">Action</th>
                <th className="py-3 px-4 text-xs font-black text-slate-500 uppercase tracking-wider">Target</th>
                <th className="py-3 px-4 text-xs font-black text-slate-500 uppercase tracking-wider">Details</th>
              </tr>
            </thead>
            <tbody>
              {filterStatus === 'Archived' && paginatedLogs.length === 0 && !isFetchingArchived ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-500">
                    <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-500 mb-2" />
                    <p className="text-sm font-semibold">Archived logs have been securely moved to Google Sheets.</p>
                    <p className="text-xs mt-1">If no records appear, they might not be fetched correctly from the current Apps Script endpoint.</p>
                  </td>
                </tr>
              ) : paginatedLogs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-500">
                    <Activity className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                    <p className="text-sm font-semibold">No audit records found matching your filters.</p>
                  </td>
                </tr>
              ) : (
                paginatedLogs.map((log) => (
                  <tr key={log.id} className="border-b border-slate-100 hover:bg-slate-50/50 transition-colors">
                    <td className="py-3 px-4 text-xs font-mono text-slate-500 whitespace-nowrap flex items-center gap-2">
                      {log.archiveStatus === 'Scheduled' && (
                        <div title="Scheduled for Archive" className="w-2 h-2 rounded-full bg-rose-500 flex-shrink-0 animate-pulse" />
                      )}
                      {log.archiveStatus === 'Approaching Archive' && (
                        <div title="Approaching Archive" className="w-2 h-2 rounded-full bg-amber-500 flex-shrink-0" />
                      )}
                      {new Date(log.timestamp).toLocaleString(undefined, { 
                        year: 'numeric', month: 'short', day: 'numeric', 
                        hour: '2-digit', minute: '2-digit', second: '2-digit' 
                      })}
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm font-bold text-slate-800 break-words">{log.userName}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider whitespace-nowrap ${
                        log.action.includes('Login') || log.action.includes('Logout') ? 'bg-indigo-50 text-indigo-600' :
                        log.action.includes('Deleted') ? 'bg-rose-50 text-rose-600' :
                        log.action.includes('Created') ? 'bg-emerald-50 text-emerald-600' :
                        'bg-blue-50 text-blue-600'
                      }`}>
                        {log.action}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm font-semibold text-slate-700 break-words line-clamp-2">{log.targetName}</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-col gap-1 max-w-xs xl:max-w-md">
                        {log.oldValue && (
                          <div className="text-[10px] text-slate-500 bg-slate-100 p-1 rounded font-mono truncate" title={log.oldValue}>
                            <span className="text-rose-500 font-bold mr-1">-</span>
                            {log.oldValue}
                          </div>
                        )}
                        {log.newValue && (
                          <div className="text-[10px] text-slate-500 bg-emerald-50 p-1 rounded font-mono truncate" title={log.newValue}>
                            <span className="text-emerald-500 font-bold mr-1">+</span>
                            {log.newValue}
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        
        {/* Pagination */}
        {totalPages > 1 && (
          <div className="px-4 py-3 border-t border-slate-200 flex items-center justify-between bg-white">
            <span className="text-xs font-semibold text-slate-500">
              Showing {((currentPage - 1) * itemsPerPage) + 1} to {Math.min(currentPage * itemsPerPage, filteredLogs.length)} of {filteredLogs.length}
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1.5 rounded hover:bg-slate-100 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ChevronLeft className="w-4 h-4 text-slate-600" />
              </button>
              <span className="text-xs font-bold text-slate-700 px-2">{currentPage} / {totalPages}</span>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-1.5 rounded hover:bg-slate-100 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ChevronRight className="w-4 h-4 text-slate-600" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
