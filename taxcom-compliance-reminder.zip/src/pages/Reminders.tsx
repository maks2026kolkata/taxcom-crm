import React, { useState, useEffect } from 'react';
import { EmailModal } from '../components/EmailModal';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Bell,
  Share2,
  PhoneCall,
  Mail,
  Copy,
  CheckCircle,
  Clock,
  ExternalLink,
  ChevronRight,
  User,
  CheckSquare,
  DollarSign,
  FileText,
  Sliders,
  Send,
  X,
  RotateCw,
  Filter
} from 'lucide-react';
import {
  getReminders,
  getTemplates,
  getSignatureSettings,
  getTaskById,
  getClientById,
  updateReminderStatus,
  createReminderHistory,
  addAuditLog,
  getClients,
  updateTask,
  getTasks,
  simulateScheduledFunction
} from '../db/storage';
import { ReminderItem, MessageTemplate, Client, ComplianceTask } from '../types';
import { useToast } from '../components/Toast';
import { useAuth } from '../components/AuthContext';

export default function Reminders() {
  const { showToast } = useToast();
  const location = useLocation();
  const navigate = useNavigate();
  const { currentUser } = useAuth();

  const [syncKey, setSyncKey] = useState(0);

  // Active generated reminders
  const [reminders, setReminders] = useState<ReminderItem[]>([]);
  const [selectedReminder, setSelectedReminder] = useState<ReminderItem | null>(null);
  const [selectedAlertIds, setSelectedAlertIds] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTaskStatus, setFilterTaskStatus] = useState('All Statuses');

  // Global tasks state for reactive reminder synchronization
  const [tasks, setTasks] = useState<ComplianceTask[]>(() => getTasks());

  const tasksFingerprint = JSON.stringify(
    tasks.map(t => ({
      id: t.id,
      status: t.status,
      dueDate: t.dueDate,
      clientId: t.clientId,
      clientName: t.clientName,
      serviceCategory: t.serviceCategory,
      returnName: t.returnName,
      professionalFees: t.professionalFees,
      amountReceived: t.amountReceived,
      outstandingAmount: t.outstandingAmount,
      isDeleted: t.isDeleted,
    }))
  );

  // Message customization states
  const [templates, setTemplates] = useState<MessageTemplate[]>(() => getTemplates());
  const [selectedTemplate, setSelectedTemplate] = useState<MessageTemplate | null>(() => {
    const list = getTemplates();
    return list.find(t => t.type === 'Compliance Due Reminder') || list[0] || null;
  });
  const [includeDocs, setIncludeDocs] = useState(true);
  const [includeFees, setIncludeFees] = useState(true);
  const [customMessage, setCustomMessage] = useState('');
  
  // Dialog Actions Modals
  const [isSnoozeOpen, setIsSnoozeOpen] = useState(false);
  const [customSnoozeDate, setCustomSnoozeDate] = useState('');
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);

  const [isMarkSentOpen, setIsMarkSentOpen] = useState(false);
  const [sentMethod, setSentMethod] = useState<'WhatsApp' | 'Email' | 'Phone' | 'Other'>('WhatsApp');
  const [sentRemarks, setSentRemarks] = useState('');

  const [isConfirmResolveOpen, setIsConfirmResolveOpen] = useState(false);

  // Load reminders
  const loadData = () => {
    const list = getReminders();
    setReminders(list);

    // If query string has ?id=rem-xxx, auto select it
    const params = new URLSearchParams(location.search);
    const idParam = params.get('id');
    if (idParam) {
      const match = list.find(r => r.id === idParam);
      if (match) setSelectedReminder(match);
    } else if (list.length > 0 && !selectedReminder) {
      setSelectedReminder(list[0]);
    }
  };

  // Run simulator & load reminders automatically whenever tasks change or component mounts

  useEffect(() => {
    const handleDataUpdate = () => {
      setReminders(getReminders());
      setTasks(getTasks());
    };
    window.addEventListener('taxcom_data_updated', handleDataUpdate);
    return () => window.removeEventListener('taxcom_data_updated', handleDataUpdate);
  }, []);

  useEffect(() => {
    simulateScheduledFunction();
    loadData();
  }, [tasksFingerprint]);

  useEffect(() => {
    loadData();
  }, [location.search]);

  useEffect(() => {
    const handleSync = () => {
      setTasks(getTasks());
      const updatedTemplates = getTemplates();
      setTemplates(updatedTemplates);
      setSelectedTemplate(prev => {
        if (!prev) return updatedTemplates.find(t => t.type === 'Compliance Due Reminder') || updatedTemplates[0] || null;
        return updatedTemplates.find(t => t.id === prev.id) || updatedTemplates.find(t => t.type === prev.type) || updatedTemplates[0] || null;
      });
      loadData();
      setSyncKey(prev => prev + 1);
    };
    window.addEventListener('database-sync', handleSync);
    return () => window.removeEventListener('database-sync', handleSync);
  }, []);

  const logCommunicationForReminder = (rem: ReminderItem, method: string) => {
    const task = getTaskById(rem.taskId);
    if (!task) return;

    const now = new Date().toISOString();
    
    const newRecord = {
      timestamp: now,
      method: method,
      sentBy: currentUser?.name || 'System'
    };

    const currentHistory = task.communication_history || [];
    const updatedHistory = [...currentHistory, newRecord];

    updateTask(rem.taskId, {
      communication_history: updatedHistory,
      lastSent: now
    });

    addAuditLog(
      'Communication Sent',
      task.id,
      task.returnName,
      undefined,
      `Recorded communication timestamp for ${method} sent to ${getClientById(rem.clientId)?.name || rem.clientName}`
    );

    // Create history record as well
    const client = getClientById(rem.clientId);
    createReminderHistory({
      taskId: rem.taskId,
      taskName: rem.taskName,
      clientId: rem.clientId,
      clientName: rem.clientName,
      whatsappNumber: client?.whatsappNumber || client?.mobileNumber,
      emailAddress: client?.emailAddress,
      sentMethod: method.includes('WhatsApp') ? 'WhatsApp' : 'Other',
      sentBy: currentUser?.name || 'System',
      remarks: `Sent via ${method}`,
    });

    window.dispatchEvent(new Event('database-sync'));
  };

  const logCommunication = (method: string) => {
    if (!selectedReminder) return;
    logCommunicationForReminder(selectedReminder, method);
  };

  const compileMessageForReminder = (rem: ReminderItem) => {
    const task = getTaskById(rem.taskId);
    const client = getClientById(rem.clientId);
    // Find requested template
    const template = selectedTemplate || templates[0];
    if (!template) return '';
    
    // Compile variables
    let body = template.body;
    const clientName = client?.name || rem.clientName;
    const returnName = rem.taskName;
    const period = task?.filingPeriod || 'Current Period';
    const dueDate = rem.dueDate;
    const companyName = 'Taxcom Technologies LLP';
    const staffName = task?.assignedStaffName || currentUser?.name || 'Staff';

    // Document tracker replacement
    let docsStr = 'None';
    if (task && task.documentsPending && task.documentsPending.length > 0) {
      docsStr = task.documentsPending.join(', ');
    }

    const outstanding = task?.outstandingAmount || 0;
    const fees = task?.professionalFees || 0;
    const recd = task?.amountReceived || 0;

    // Standard Replacements
    const sigSettings = getSignatureSettings();
    let signature = '';
    if (sigSettings.style === 'Custom') {
      signature = sigSettings.customText;
    } else if (sigSettings.style === '{{staffName}} + {{companyName}}') {
      signature = '{{staffName}}, {{companyName}}';
    } else {
      signature = 'Team {{companyName}}';
    }
    
    body = body.replace(/\{\{signature\}\}/g, signature);
    
    body = body
      .replace(/\{\{clientName\}\}/g, clientName)
      .replace(/{{returnName}}/g, returnName)
      .replace(/{{period}}/g, period)
      .replace(/{{dueDate}}/g, dueDate)
      .replace(/{{companyName}}/g, companyName)
      .replace(/{{staffName}}/g, staffName)
      .replace(/{{pendingDocuments}}/g, docsStr)
      .replace(/{{outstandingAmount}}/g, outstanding.toString())
      .replace(/{{professionalFees}}/g, fees.toString())
      .replace(/{{amountReceived}}/g, recd.toString());

    // Contextual checkboxes additions
    if (template.type === 'Compliance Due Reminder') {
      if (includeDocs && task && task.documentsPending && task.documentsPending.length > 0) {
        body += `\n\nPending Documents: ${task.documentsPending.join(', ')}`;
      }
      if (includeFees && task && task.outstandingAmount > 0) {
        body += `\n\nOutstanding Professional Fees: ₹${task.outstandingAmount}`;
      }
    }

    return body;
  };

  const handleBulkWhatsAppDispatch = () => {
    if (selectedAlertIds.length === 0) {
      showToast('No alerts selected. Please check at least one alert to dispatch.', 'warning');
      return;
    }

    showToast(`Dispatching ${selectedAlertIds.length} reminders via WhatsApp. Please allow pop-ups if prompted.`, 'success');

    selectedAlertIds.forEach((id, index) => {
      const rem = reminders.find(r => r.id === id);
      if (rem) {
        const client = getClientById(rem.clientId);
        const number = client?.whatsappNumber || client?.mobileNumber || '';
        const cleanNumber = number.replace(/[^0-9+]/g, '');
        const message = compileMessageForReminder(rem);
        const waUrl = `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;

        // Open in new tab with a slight timeout to prevent pop-up blocker
        setTimeout(() => {
          window.open(waUrl, '_blank');

          // Log communication and history automatically
          logCommunicationForReminder(rem, 'WhatsApp (Bulk)');
        }, index * 800); // 800ms delay between tabs
      }
    });

    // Clear selection after dispatch
    setSelectedAlertIds([]);
  };

  // Handle reminder select change
  const handleSelectReminder = (rem: ReminderItem) => {
    setSelectedReminder(rem);
    // Auto preset template based on interval/status
    if (rem.intervalType === 'Daily after becoming overdue') {
      const matched = templates.find(t => t.type === 'Overdue Filing') || templates.find(t => t.type.toLowerCase().includes('overdue')) || templates[0];
      if (matched) setSelectedTemplate(matched);
    } else {
      const matched = templates.find(t => t.type === 'Compliance Due Reminder') || templates[0];
      if (matched) setSelectedTemplate(matched);
    }
  };

  // Re-run state compiled message whenever template or checkboxes change
  useEffect(() => {
    if (!selectedReminder) return;

    const task = getTaskById(selectedReminder.taskId);
    const client = getClientById(selectedReminder.clientId);

    // Find requested template
    const template = selectedTemplate || templates[0];
    if (!template) return;
    
    // Compile variables
    let body = template.body;
    const clientName = client?.name || selectedReminder.clientName;
    const returnName = selectedReminder.taskName;
    const period = task?.filingPeriod || 'Current Period';
    const dueDate = selectedReminder.dueDate;
    const companyName = 'Taxcom Technologies LLP';
    const staffName = task?.assignedStaffName || currentUser.name;

    // Document tracker replacement
    let docsStr = 'None';
    if (task && task.documentsPending && task.documentsPending.length > 0) {
      docsStr = task.documentsPending.join(', ');
    }

    const outstanding = task?.outstandingAmount || 0;
    const fees = task?.professionalFees || 0;
    const recd = task?.amountReceived || 0;

    // Standard Replacements
    const sigSettings = getSignatureSettings();
    let signature = '';
    if (sigSettings.style === 'Custom') {
      signature = sigSettings.customText;
    } else if (sigSettings.style === '{{staffName}} + {{companyName}}') {
      signature = '{{staffName}}, {{companyName}}';
    } else {
      signature = 'Team {{companyName}}';
    }
    
    body = body.replace(/\{\{signature\}\}/g, signature);
    
    body = body
      .replace(/\{\{clientName\}\}/g, clientName)
      .replace(/{{returnName}}/g, returnName)
      .replace(/{{period}}/g, period)
      .replace(/{{dueDate}}/g, dueDate)
      .replace(/{{companyName}}/g, companyName)
      .replace(/{{staffName}}/g, staffName)
      .replace(/{{pendingDocuments}}/g, docsStr)
      .replace(/{{outstandingAmount}}/g, outstanding.toString())
      .replace(/{{professionalFees}}/g, fees.toString())
      .replace(/{{amountReceived}}/g, recd.toString());

    // Contextual checkboxes additions
    if (template.type === 'Compliance Due Reminder') {
      if (includeDocs && task && task.documentsPending && task.documentsPending.length > 0) {
        body += `\n\nPending Documents: ${task.documentsPending.join(', ')}`;
      }
      if (includeFees && task && task.outstandingAmount > 0) {
        body += `\n\nOutstanding Professional Fees: ₹${task.outstandingAmount}`;
      }
    }

    setCustomMessage(body);
  }, [selectedReminder, selectedTemplate, includeDocs, includeFees, templates]);

  // WHATSAPP URL GENERATOR
  const getWhatsAppLink = () => {
    if (!selectedReminder) return '#';
    const client = getClientById(selectedReminder.clientId);
    const number = client?.whatsappNumber || client?.mobileNumber || '';
    
    // Clean phone number (strip spaces, symbols, ensure prefix)
    const cleanNumber = number.replace(/[^0-9+]/g, '');
    
    // wa.me/number?text=uriEncoded
    return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(customMessage)}`;
  };

  // EMAIL MAILTO LINK
  
  const getEmailSubject = () => {
    if (!selectedReminder) return '';
    const template = selectedTemplate || templates[0];
    if (!template) return '';
    
    return (template.emailSubject || template.subject || '')
      .replace(/{{returnName}}/g, selectedReminder.taskName)
      .replace(/{{dueDate}}/g, selectedReminder.dueDate)
      .replace(/{{period}}/g, selectedReminder.intervalType);
  };
  
  const getEmailLink = () => {
    if (!selectedReminder) return '#';
    const client = getClientById(selectedReminder.clientId);
    const email = client?.emailAddress || '';
    
    const template = selectedTemplate || templates[0];
    if (!template) return '#';
    
    let subject = template.subject
      .replace(/{{returnName}}/g, selectedReminder.taskName)
      .replace(/{{dueDate}}/g, selectedReminder.dueDate)
      .replace(/{{period}}/g, selectedReminder.intervalType);

    return `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(customMessage)}`;
  };

  // COPY MESSAGE TO CLIPBOARD
  const handleCopyMessage = () => {
    navigator.clipboard.writeText(customMessage);
    showToast('Reminder message copied successfully.', 'success');
  };

  // SNOOZE ACTION
  const handleSnooze = (days: number | 'custom') => {
    if (!selectedReminder) return;

    let snoozeUntilStr = '';
    const d = new Date();

    if (days === 'custom') {
      if (!customSnoozeDate) {
        showToast('Please select a custom snooze date.', 'warning');
        return;
      }
      snoozeUntilStr = customSnoozeDate;
    } else {
      d.setDate(d.getDate() + days);
      snoozeUntilStr = d.toISOString().split('T')[0];
    }

    updateReminderStatus(selectedReminder.id, 'Snoozed', snoozeUntilStr);
    showToast(`Reminder snoozed successfully until ${snoozeUntilStr}`, 'success');
    
    setIsSnoozeOpen(false);
    setSelectedReminder(null);
    loadData();
  };

  // MARK AS SENT CONFIRMATION
  const handleMarkAsSentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReminder) return;

    const client = getClientById(selectedReminder.clientId);

    // Save historical log
    createReminderHistory({
      taskId: selectedReminder.taskId,
      taskName: selectedReminder.taskName,
      clientId: selectedReminder.clientId,
      clientName: selectedReminder.clientName,
      whatsappNumber: client?.whatsappNumber || client?.mobileNumber,
      emailAddress: client?.emailAddress,
      sentMethod: sentMethod,
      sentBy: currentUser.name,
      remarks: sentRemarks || `Sent successfully via ${sentMethod}`,
    });

    // Mark as sent in active alerts (Pending -> Sent)
    updateReminderStatus(selectedReminder.id, 'Sent');
    
    // Log communication timestamp to the task as well
    logCommunication(`Logged as Sent via ${sentMethod}`);

    showToast('Reminder successfully logged as sent!', 'success');

    setIsMarkSentOpen(false);
    setSentRemarks('');
    setSelectedReminder(null);
    loadData();
  };

  const handleResolveConfirm = () => {
    if (!selectedReminder) return;

    const task = getTaskById(selectedReminder.taskId);
    if (task) {
      const todayStr = new Date().toISOString().split('T')[0];
      const updatedDetails = { ...(task.documentDetails || {}) };
      
      // Update each required document as received
      task.documentsRequired.forEach(doc => {
        updatedDetails[doc] = {
          docName: doc,
          fileName: updatedDetails[doc]?.fileName || `${doc.toLowerCase().replace(/\s+/g, '_')}.pdf`,
          receivedDate: updatedDetails[doc]?.receivedDate || todayStr,
          receivedBy: updatedDetails[doc]?.receivedBy || currentUser?.name || 'Staff',
          remarks: updatedDetails[doc]?.remarks || 'Marked as received and resolved via Reminder Dispatch Center'
        };
      });

      // Update task documents status in the database
      updateTask(task.id, {
        documentsPending: [],
        documentDetails: updatedDetails,
        status: task.status === 'Documents Pending' ? 'In Progress' : task.status
      });

      // Log communication and history
      addAuditLog(
        'Task Modified',
        task.id,
        task.returnName,
        undefined,
        `Marked all required documents as received and resolved documents pending reminder for ${getClientById(selectedReminder.clientId)?.name || selectedReminder.clientName}`
      );

      // Create reminder history
      createReminderHistory({
        taskId: selectedReminder.taskId,
        taskName: selectedReminder.taskName,
        clientId: selectedReminder.clientId,
        clientName: selectedReminder.clientName,
        sentMethod: 'Other',
        sentBy: currentUser?.name || 'Staff',
        remarks: 'Resolved reminder and marked all pending documents as received',
      });

      // Update reminder status in active list
      updateReminderStatus(selectedReminder.id, 'Sent');

      showToast('Reminder resolved successfully! Pending documents marked as received.', 'success');

      // Sync and trigger state recalculations
      window.dispatchEvent(new Event('database-sync'));
    }

    setIsConfirmResolveOpen(false);
    setSelectedReminder(null);
  };

  // Filter active alerts based on search query and task status
  const filteredReminders = reminders.filter((rem) => {
    const matchesSearch = (getClientById(rem.clientId)?.name || rem.clientName).toLowerCase().includes(searchQuery.toLowerCase()) || rem.taskName.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (filterTaskStatus !== 'All Statuses') {
      const relatedTask = tasks.find(t => t.id === rem.taskId);
      if (!relatedTask || relatedTask.status !== filterTaskStatus) {
        return false;
      }
    }
    
    return matchesSearch;
  });

  const dossierClient = selectedReminder ? getClientById(selectedReminder.clientId) : undefined;

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Title Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center">
          <Bell className="w-6 h-6 mr-2.5 text-[#F5405E] animate-pulse" />
          Reminder Dispatch Center
        </h1>
        <p className="text-xs text-slate-500">
          Action system-generated compliance alerts by sharing prepared templates with clients via WhatsApp and Mail.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        
        {/* Left Side: Generated alerts list */}
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm flex flex-col max-h-[680px]">
          <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Active generated alerts ({reminders.length})
            </span>
            <button
              onClick={loadData}
              title="Refresh generated alerts"
              className="p-1 hover:bg-slate-200 text-slate-500 rounded transition-colors"
            >
              <RotateCw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Search Bar */}
          <div className="p-3 bg-slate-50/30 border-b border-slate-100 space-y-3">
            <div className="relative">
              <input
                type="text"
                placeholder="Search client or task..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-xs bg-white border border-slate-200 rounded-lg pl-3 pr-2 py-2 font-medium text-slate-700 placeholder-slate-400 focus:outline-hidden focus:border-[#F5405E] transition-colors shadow-2xs"
              />
            </div>
            
            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={filterTaskStatus}
                onChange={(e) => setFilterTaskStatus(e.target.value)}
                className="flex-1 text-xs bg-white border border-slate-200 rounded-lg px-2 py-1.5 font-medium text-slate-700 focus:outline-hidden focus:border-[#F5405E] transition-colors shadow-2xs appearance-none"
              >
                <option value="All Statuses">All Statuses</option>
                <option value="Not Started">Not Started</option>
                <option value="Documents Pending">Documents Pending</option>
                <option value="Client Confirmation Pending">Client Confirmation Pending</option>
                <option value="In Progress">In Progress</option>
                <option value="Ready to File">Ready to File</option>
                <option value="Filed">Filed</option>
                <option value="Completed">Completed</option>
                <option value="On Hold">On Hold</option>
              </select>
            </div>
          </div>

          {/* Bulk Actions Bar */}
          {filteredReminders.length > 0 && (
            <div className="p-3 bg-rose-50/20 border-b border-slate-100 flex items-center justify-between gap-2">
              <label className="flex items-start gap-2 text-xs font-semibold text-slate-600 cursor-pointer select-none flex-wrap whitespace-normal break-words">
                <input
                  type="checkbox"
                  checked={filteredReminders.length > 0 && filteredReminders.every(r => selectedAlertIds.includes(r.id))}
                  onChange={(e) => {
                    if (e.target.checked) {
                      // Select all filtered reminders that are not already selected
                      const allFilteredIds = filteredReminders.map(r => r.id);
                      setSelectedAlertIds(prev => Array.from(new Set([...prev, ...allFilteredIds])));
                    } else {
                      // Deselect all filtered reminders
                      const allFilteredIds = filteredReminders.map(r => r.id);
                      setSelectedAlertIds(prev => prev.filter(id => !allFilteredIds.includes(id)));
                    }
                  }}
                  className="accent-[#F5405E] w-4 h-4 cursor-pointer shrink-0 mt-0.5"
                />
                <span>Select All ({filteredReminders.length})</span>
              </label>

              {selectedAlertIds.length > 0 && (
                <button
                  onClick={handleBulkWhatsAppDispatch}
                  className="inline-flex items-center px-2.5 py-1.5 text-[10px] font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md shadow-xs transition-colors cursor-pointer shrink-0"
                >
                  <Send className="w-3 h-3 mr-1" />
                  Send WhatsApp ({selectedAlertIds.length})
                </button>
              )}
            </div>
          )}

          <div className="divide-y divide-slate-100 overflow-y-auto flex-1">
            {reminders.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                No pending reminders at this moment. Tasks with upcoming due dates (within 7 days) will automatically appear here.
              </div>
            ) : filteredReminders.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                No active alerts match your search or filter criteria.
              </div>
            ) : (
              filteredReminders.map((rem) => {
                const isSelected = selectedReminder?.id === rem.id;
                const isChecked = selectedAlertIds.includes(rem.id);
                const task = getTaskById(rem.taskId);
                const isOverdue = rem.intervalType === 'Daily after becoming overdue';

                return (
                  <div
                    key={rem.id}
                    onClick={() => handleSelectReminder(rem)}
                    className={`p-4 cursor-pointer transition-all border-l-4 flex gap-3 items-start ${
                      isSelected
                        ? 'bg-rose-50/40 border-l-[#F5405E] border-y border-rose-100'
                        : 'border-l-transparent hover:bg-slate-50'
                    }`}
                  >
                    {/* Bulk Selection Checkbox */}
                    <div
                      onClick={(e) => {
                        e.stopPropagation(); // Avoid triggering selectedReminder change when checking the box
                      }}
                      className="pt-1 shrink-0"
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedAlertIds(prev => [...prev, rem.id]);
                          } else {
                            setSelectedAlertIds(prev => prev.filter(id => id !== rem.id));
                          }
                        }}
                        className="accent-[#F5405E] w-4 h-4 cursor-pointer"
                      />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between space-x-2">
                        <div className="min-w-0 flex-1">
                          <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                            isOverdue
                              ? 'bg-rose-100 text-rose-700 animate-pulse'
                              : 'bg-amber-100 text-amber-700'
                          }`}>
                            {rem.intervalType}
                          </span>
                          <strong className="text-xs font-extrabold text-slate-900 block mt-1.5 truncate max-w-full">
                            {getClientById(rem.clientId)?.name || rem.clientName}
                          </strong>
                          <span className="text-[11px] font-semibold text-rose-600 block">{rem.serviceCategory}</span>
                          <span className="text-xs text-slate-500 block truncate max-w-full">
                            {rem.taskName}
                          </span>
                        </div>
                        <div className="flex flex-col items-end gap-1 shrink-0 ml-2">
                          <span className="inline-flex items-center px-2 py-1 rounded text-[10px] font-bold bg-slate-100 text-slate-600">
                            {task?.status || 'Unknown'}
                          </span>
                          <ChevronRight className="w-4 h-4 text-slate-400" />
                        </div>
                      </div>
                      <div className="flex items-center justify-between mt-3 text-[10px] text-slate-400 font-semibold border-t border-slate-100/60 pt-2">
                        <span>Due: {rem.dueDate}</span>
                        <span>Docs pending: {task?.documentsPending?.length || 0}</span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Side: Message compilation and Share controls */}
        <div className="lg:col-span-2 space-y-6">
          {selectedReminder ? (
            <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-6 animate-in fade-in zoom-in-95 duration-150">
              
              {/* Target Header Info */}
              <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-3 sm:space-y-0">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Target Client Dossier</span>
                  <h3 className="font-extrabold text-slate-900 text-md">{getClientById(selectedReminder.clientId)?.name || selectedReminder.clientName}</h3>
                  
                  {dossierClient && (dossierClient.mobileNumber || dossierClient.emailAddress) && (
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 mt-1">
                      {dossierClient.mobileNumber && (
                        <span className="flex items-center gap-1 bg-slate-100/80 px-2 py-0.5 rounded text-slate-700 font-semibold">
                          <PhoneCall className="w-3 h-3 text-slate-500" />
                          <span>{dossierClient.mobileNumber}</span>
                        </span>
                      )}
                      {dossierClient.emailAddress && (
                        <span className="flex items-center gap-1 bg-slate-100/80 px-2 py-0.5 rounded text-slate-700 font-semibold">
                          <Mail className="w-3 h-3 text-slate-500" />
                          <span>{dossierClient.emailAddress}</span>
                        </span>
                      )}
                    </div>
                  )}

                  <div className="text-xs text-slate-500 flex flex-wrap items-center gap-x-2 gap-y-1 mt-1.5">
                    <span>Compliance Task: <strong className="text-slate-700">{selectedReminder.taskName}</strong></span>
                    <span className="text-slate-300">|</span>
                    <span>Due Date: <strong className="text-rose-600">{selectedReminder.dueDate}</strong></span>
                    {getTaskById(selectedReminder.taskId)?.lastSent && (
                      <>
                        <span className="text-slate-300">|</span>
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100/80 shadow-3xs">
                          <span className="h-1.5 w-1.5 rounded-full bg-indigo-500 animate-pulse"></span>
                          Last Sent: {new Date(getTaskById(selectedReminder.taskId)!.lastSent!).toLocaleString('en-IN', {
                            dateStyle: 'medium',
                            timeStyle: 'short',
                          })}
                        </span>
                      </>
                    )}
                  </div>
                </div>
                
                {/* Snooze and Mark Sent Quick Actions */}
                <div className="flex items-center gap-1.5 shrink-0 self-start sm:self-center">
                  <button
                    onClick={() => setIsSnoozeOpen(true)}
                    className="inline-flex items-center px-2.5 py-1.5 text-xs font-bold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs"
                  >
                    <Clock className="w-3.5 h-3.5 mr-1" />
                    Snooze Alert
                  </button>
                  <button
                    onClick={() => {
                      logCommunication('Log as Sent Clicked');
                      setIsMarkSentOpen(true);
                    }}
                    className="inline-flex items-center px-2.5 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm cursor-pointer"
                  >
                    <CheckCircle className="w-3.5 h-3.5 mr-1 text-emerald-400" />
                    Log as Sent
                  </button>
                  <button
                    onClick={() => {
                      setIsConfirmResolveOpen(true);
                    }}
                    className="inline-flex items-center px-2.5 py-1.5 text-xs font-bold text-white bg-[#F5405E] hover:bg-rose-600 rounded-lg shadow-sm cursor-pointer"
                  >
                    <CheckSquare className="w-3.5 h-3.5 mr-1 text-white" />
                    Mark Complete
                  </button>
                </div>
              </div>

              {/* Template selector controls */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-1">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                    Select Message Template
                  </label>
                  <select
                    value={selectedTemplate?.id || ''}
                    onChange={(e) => {
                      const found = templates.find(t => t.id === e.target.value);
                      if (found) setSelectedTemplate(found);
                    }}
                    className="block w-full text-xs border border-slate-300 rounded-lg px-2.5 py-2.5 bg-white font-semibold text-slate-800"
                  >
                    {templates.map((tmpl) => (
                      <option key={tmpl.id} value={tmpl.id}>
                        {tmpl.title}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Checkboxes additions for normal due templates */}
                {selectedTemplate?.type === 'Compliance Due Reminder' && (
                  <div className="md:col-span-2 flex flex-wrap items-start gap-4 pb-2">
                    <label className="flex items-start gap-2 text-xs font-bold text-slate-600 cursor-pointer select-none whitespace-normal break-words">
                      <input
                        type="checkbox"
                        checked={includeDocs}
                        onChange={(e) => setIncludeDocs(e.target.checked)}
                        className="accent-rose-500 w-4 h-4 shrink-0 mt-0.5"
                      />
                      <span>Include Document Checklist</span>
                    </label>
                    <label className="flex items-start gap-2 text-xs font-bold text-slate-600 cursor-pointer select-none whitespace-normal break-words">
                      <input
                        type="checkbox"
                        checked={includeFees}
                        onChange={(e) => setIncludeFees(e.target.checked)}
                        className="accent-rose-500 w-4 h-4 shrink-0 mt-0.5"
                      />
                      <span>Include Outstanding Balance</span>
                    </label>
                  </div>
                )}
              </div>

              {/* Message compilation Preview textbox */}
              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Pre-compiled Message body (Editable)
                </label>
                <textarea
                  rows={10}
                  value={customMessage}
                  onChange={(e) => setCustomMessage(e.target.value)}
                  className="w-full text-xs border border-slate-300 rounded-lg p-3.5 bg-slate-50 font-sans text-slate-800 leading-relaxed focus:outline-none focus:ring-1 focus:ring-rose-500 focus:border-rose-500"
                />
              </div>

              {/* Channels Sharing Bar */}
              <div className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                  {/* Call Client button */}
                  {dossierClient?.mobileNumber && (
                    <a
                      href={`tel:${dossierClient.mobileNumber}`}
                      className="inline-flex items-center px-4 py-2 text-xs font-extrabold text-[#F5405E] bg-rose-50 hover:bg-rose-100 border border-rose-200/80 active:scale-95 transition-all rounded-lg shadow-xs cursor-pointer"
                    >
                      <PhoneCall className="w-3.5 h-3.5 mr-1.5" />
                      Call Client
                    </a>
                  )}

                  {/* WhatsApp button */}
                  <a
                    href={getWhatsAppLink()}
                    target="_blank"
                    rel="noreferrer"
                    onClick={() => logCommunication('WhatsApp')}
                    className="inline-flex items-center px-4 py-2 text-xs font-extrabold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 transition-all rounded-lg shadow-xs cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5 mr-1.5 fill-current" />
                    Send on WhatsApp
                  </a>

                  {/* Email button */}
                  {getClientById(selectedReminder.clientId)?.emailAddress ? (
                    <button
                      onClick={() => setIsEmailModalOpen(true)}
                      className="inline-flex items-center px-4 py-2 text-xs font-extrabold text-white bg-blue-600 hover:bg-blue-700 active:scale-95 transition-all rounded-lg shadow-xs cursor-pointer"
                    >
                      <Mail className="w-3.5 h-3.5 mr-1.5" />
                      Send by Email
                    </button>
                  ) : (
                    <button
                      disabled
                      title="Client email address is not available."
                      className="inline-flex items-center px-4 py-2 text-xs font-bold text-slate-400 bg-slate-100 border border-slate-200 rounded-lg cursor-not-allowed"
                    >
                      <Mail className="w-3.5 h-3.5 mr-1.5 text-slate-300" />
                      Email Unavailable
                    </button>
                  )}

                  {/* Copy Message button */}
                  <button
                    onClick={() => {
                      handleCopyMessage();
                      logCommunication('Copy Message');
                    }}
                    className="inline-flex items-center px-3.5 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5 mr-1.5 text-slate-500" />
                    Copy Message
                  </button>
                </div>
              </div>

            </div>
          ) : (
            <div className="bg-slate-50 border border-dashed border-slate-300 rounded-xl p-16 text-center text-slate-400">
              <p className="text-sm font-semibold">No generated compliance alert is selected.</p>
              <p className="text-xs mt-1">Select an active alert from the left panel list to compile templates and launch client sharing.</p>
            </div>
          )}
        </div>
      </div>

      {/* SNOOZE ACTION MODAL */}
      {isSnoozeOpen && selectedReminder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl border border-slate-100 max-w-sm w-full p-6 space-y-4 animate-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">Snooze Alert Notification</h3>
              <button onClick={() => setIsSnoozeOpen(false)} className="text-slate-400 hover:text-slate-600 font-bold text-xs">✕</button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => handleSnooze(0)} // later today
                className="p-3 text-center bg-slate-50 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 rounded-lg font-bold text-slate-700 transition-colors"
              >
                Later Today
              </button>
              <button
                onClick={() => handleSnooze(1)} // tomorrow
                className="p-3 text-center bg-slate-50 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 rounded-lg font-bold text-slate-700 transition-colors"
              >
                Tomorrow
              </button>
              <button
                onClick={() => handleSnooze(3)} // 3 days
                className="p-3 text-center bg-slate-50 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 rounded-lg font-bold text-slate-700 transition-colors"
              >
                After 3 Days
              </button>
              <div className="p-3 bg-slate-100 border border-slate-200 rounded-lg text-center flex flex-col items-center justify-center">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Custom Date</span>
              </div>
            </div>

            <div className="pt-2">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Pick Snooze Date</label>
              <input
                type="date"
                value={customSnoozeDate}
                onChange={(e) => setCustomSnoozeDate(e.target.value)}
                className="w-full text-xs border border-slate-300 rounded-lg p-2 bg-white text-center font-bold"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setIsSnoozeOpen(false)}
                className="px-3.5 py-1.5 text-xs text-slate-500 hover:text-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={() => handleSnooze('custom')}
                disabled={!customSnoozeDate}
                className="px-4 py-1.5 text-xs font-bold text-white bg-[#F5405E] hover:bg-rose-600 rounded-lg disabled:opacity-50"
              >
                Snooze Now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* LOG AS SENT MODAL */}
      {isMarkSentOpen && selectedReminder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl border border-slate-100 max-w-md w-full p-6 space-y-4 animate-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">Audit Sent Reminder Confirmation</h3>
              <button onClick={() => setIsMarkSentOpen(false)} className="text-slate-400 hover:text-slate-600 font-bold text-xs">✕</button>
            </div>

            <form onSubmit={handleMarkAsSentSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Sent Method *</label>
                <select
                  value={sentMethod}
                  onChange={(e) => setSentMethod(e.target.value as any)}
                  className="block w-full text-xs border border-slate-300 rounded-lg px-2.5 py-2 bg-white font-bold"
                >
                  <option value="WhatsApp">WhatsApp Message</option>
                  <option value="Email">Email Message</option>
                  <option value="Phone">Direct Phone Call</option>
                  <option value="Other">Other Method</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Sent Remarks / Feedback</label>
                <textarea
                  rows={3}
                  required
                  placeholder="e.g. Sent PDF calculations; proprietor confirmed receipt and agreed to pay GST..."
                  value={sentRemarks}
                  onChange={(e) => setSentRemarks(e.target.value)}
                  className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white text-slate-700"
                />
              </div>

              <div className="text-[10px] text-slate-400 leading-relaxed bg-slate-50 p-2.5 rounded border border-slate-100">
                ⚠️ Confirming will archive this dispatch alert. It prevents duplicate alarms on the staff dashboard while persisting an audit trail log under "Reminder Sent History".
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsMarkSentOpen(false)}
                  className="px-3.5 py-1.5 text-xs text-slate-500 hover:text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs animate-pulse-subtle"
                >
                  Confirm Sent Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRM RESOLVE MODAL */}
      {isConfirmResolveOpen && selectedReminder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl border border-slate-100 max-w-sm w-full p-6 space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">Resolve Reminder</h3>
              <button onClick={() => setIsConfirmResolveOpen(false)} className="text-slate-400 hover:text-slate-600 font-bold text-xs">✕</button>
            </div>

            <div className="text-xs text-slate-600 leading-relaxed">
              Are you sure you have received the documents and want to resolve this reminder?
            </div>

            <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setIsConfirmResolveOpen(false)}
                className="px-3.5 py-1.5 text-xs text-slate-500 hover:text-slate-700 font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleResolveConfirm}
                className="px-4 py-1.5 text-xs font-bold text-white bg-[#F5405E] hover:bg-rose-600 rounded-lg shadow-sm"
              >
                Resolve & Complete
              </button>
            </div>
          </div>
        </div>
      )}

    
      {/* Email Preview Modal */}
      {selectedReminder && (
        <EmailModal
          isOpen={isEmailModalOpen}
          onClose={() => setIsEmailModalOpen(false)}
          initialTo={getClientById(selectedReminder.clientId)?.emailAddress || ''}
          initialSubject={getEmailSubject()}
          initialBody={customMessage}
        />
      )}
    </div>
  );

}