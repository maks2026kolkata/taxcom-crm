import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  Mail,
  ShieldAlert,
  Play,
  RotateCw,
  Clock,
  Sparkles,
  Smartphone,
  Globe,
  Database,
  Info,
  CheckCircle2,
  Download,
  ShieldCheck,
  FileSpreadsheet,
  AlertTriangle,
  RotateCcw,
  UserCheck,
  Calendar,
  Lock,
  HardDrive,
  Trash2,
  RefreshCw
} from 'lucide-react';
import {
  getStaff,
  getReminders,
  getTasks,
  getClients,
  getReminderHistory,
  getTemplates,
  getAuditLogs,
  addAuditLog,
  evaluateAndSyncReminders,
  flushWriteQueue,
  startFirestoreSync,
  stopFirestoreSync
} from '../db/storage';
import { useAuth } from '../components/AuthContext';
import { useToast } from '../components/Toast';
import { getSignatureSettings, setSignatureSettings, SignatureStyle, SignatureSettings } from '../db/storage';
import { isFirebaseEnabled, db } from '../db/firebase';
import { collection, getDocs, deleteDoc, doc } from 'firebase/firestore';
import { X, Check } from 'lucide-react';
import * as XLSX from 'xlsx';

export default function Settings() {
  const { showToast } = useToast();
  const { currentUser } = useAuth();
  const staffList = getStaff();



  const handleRefreshData = async () => {
    try {
      showToast('Refreshing dashboard widgets, KPIs, and Firestore data...', 'info');
      if (isFirebaseEnabled) {
        stopFirestoreSync();
        await startFirestoreSync();
      }
      showToast('Dashboard data and widgets refreshed successfully.', 'success');
      window.dispatchEvent(new Event('database-sync'));
    } catch (err: any) {
      showToast(`Failed to refresh: ${err.message || err}`, 'error');
    }
  };

  const handleRunComplianceCheck = () => {
    try {
      showToast('Executing compliance validation and refreshing reminders...', 'info');
      evaluateAndSyncReminders();
      showToast('Compliance check executed and dashboard statistics updated.', 'success');
      window.dispatchEvent(new Event('database-sync'));
    } catch (err: any) {
      showToast(`Compliance check failed: ${err.message || err}`, 'error');
    }
  };

  const handleSyncDatabaseNow = async () => {
    try {
      showToast('Initiating Firestore synchronization...', 'info');
      await flushWriteQueue();
      if (isFirebaseEnabled) {
        stopFirestoreSync();
        await startFirestoreSync();
      }
      showToast('Firestore synchronization completed successfully.', 'success');
      window.dispatchEvent(new Event('database-sync'));
    } catch (err: any) {
      showToast(`Synchronization failed: ${err.message || err}`, 'error');
    }
  };

  // FULL EXCEL DATABASE BACKUP DOWNLOAD
  const handleDownloadFullBackup = () => {
    try {
      showToast('Compiling secure Firestore tables into workbook...', 'info');
      
      const clients = getClients();
      const tasks = getTasks();
      const reminders = getReminders();
      const history = getReminderHistory();
      const staff = staffList;
      const templates = getTemplates();
      const logs = getAuditLogs();

      // Create new workbook
      const wb = XLSX.utils.book_new();

      // Convert arrays of objects to SheetJS worksheets
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(clients), 'Clients');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(tasks), 'Tasks');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(reminders), 'Reminders');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(history), 'History');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(staff), 'Staff');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(templates), 'Templates');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(logs), 'Audit Logs');

      // Write multi-sheet excel file
      const filename = `crm_full_backup_${new Date().toISOString().split('T')[0]}.xlsx`;
      XLSX.writeFile(wb, filename);

      addAuditLog(
        'Database Backup Downloaded',
        currentUser?.id || 'unknown',
        currentUser?.name || 'Unknown',
        undefined,
        `Downloaded full excel archive containing ${clients.length} clients and ${tasks.length} tasks`
      );

      showToast('Backup archive compiled & downloaded successfully.', 'success');
    } catch (err: any) {
      console.error('Backup compiling failed:', err);
      showToast(`Backup compilation failed: ${err.message || err}`, 'error');
    }
  };

  const handleExportJSON = () => {
    try {
      const data = {
        clients: getClients(),
        tasks: getTasks(),
        reminders: getReminders(),
        history: getReminderHistory(),
        staff: staffList,
        templates: getTemplates(),
        logs: getAuditLogs()
      };
      
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(data, null, 2));
      const downloadAnchorNode = document.createElement('a');
      downloadAnchorNode.setAttribute("href",     dataStr);
      downloadAnchorNode.setAttribute("download", `crm_full_backup_${new Date().toISOString().split('T')[0]}.json`);
      document.body.appendChild(downloadAnchorNode);
      downloadAnchorNode.click();
      downloadAnchorNode.remove();
      
      showToast('JSON Export downloaded successfully.', 'success');
    } catch (err: any) {
      showToast(`Export failed: ${err.message || err}`, 'error');
    }
  };

  const handleRestoreBackup = () => {
    showToast('Database restore capability requires Google Cloud Console permissions.', 'info');
  };

  

  const [isVerifying, setIsVerifying] = useState(false);
  const [integrityReport, setIntegrityReport] = useState<any>(null);
  
  const [isCleaning, setIsCleaning] = useState(false);
  const [cleanupReport, setCleanupReport] = useState<any>(null);
  const [showCleanupConfirm, setShowCleanupConfirm] = useState(false);
  const [orphanRecords, setOrphanRecords] = useState<any[]>([]);

  const [isRebuilding, setIsRebuilding] = useState(false);

  const fetchCollectionSafe = async (name: string) => {
    if (!isFirebaseEnabled || !db) return [];
    try {
      const snap = await getDocs(collection(db, name));
      return snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (e) {
      console.warn("Could not fetch " + name, e);
      return [];
    }
  };

  const handleVerifyIntegrity = async () => {
    if (!isFirebaseEnabled || !db) {
      showToast('Firestore is not connected.', 'error');
      return;
    }
    
    setIsVerifying(true);
    showToast('Scanning database...', 'info');
    
    try {
      const clients = await fetchCollectionSafe('clients');
      const tasks = await fetchCollectionSafe('tasks');
      const reminders = await fetchCollectionSafe('reminders');
      const history = await fetchCollectionSafe('reminder_history');
      const documents = await fetchCollectionSafe('documents');
      const payments = await fetchCollectionSafe('payments');
      const auditLogs = await fetchCollectionSafe('audit_logs');
      const staff = await fetchCollectionSafe('staff');

      const issues: string[] = [];
      
      // Clients
      clients.forEach((c: any) => {
        if (!c.name) issues.push(`Client ${c.id} missing name.`);
        if (c.assignedStaffId && !staff.find((s: any) => s.id === c.assignedStaffId)) {
          issues.push(`Client ${c.name} has invalid staff reference.`);
        }
      });
      
      // Tasks
      tasks.forEach((t: any) => {
        if (!t.clientId || !clients.find((c: any) => c.id === t.clientId)) {
          issues.push(`Task ${t.returnName || t.id} has invalid client reference.`);
        }
        if (t.assignedStaffId && !staff.find((s: any) => s.id === t.assignedStaffId)) {
          issues.push(`Task ${t.returnName || t.id} has invalid staff reference.`);
        }
      });
      
      // Reminders
      reminders.forEach((r: any) => {
        if (!tasks.find((t: any) => t.id === r.taskId)) {
          issues.push(`Reminder ${r.id} has invalid task reference.`);
        }
      });
      
      // History
      history.forEach((h: any) => {
        if (!tasks.find((t: any) => t.id === h.taskId)) {
          issues.push(`History ${h.id} has invalid task reference.`);
        }
      });

      const totalCollections = 8;
      const totalDocs = clients.length + tasks.length + reminders.length + history.length + documents.length + payments.length + auditLogs.length + staff.length;
      
      setIntegrityReport({
        totalCollections,
        totalDocs,
        issuesFound: issues.length,
        severity: issues.length === 0 ? 'Healthy' : issues.length > 5 ? 'High' : 'Low',
        healthyPercent: issues.length === 0 ? 100 : Math.max(0, Math.floor(((totalDocs - issues.length) / totalDocs) * 100)),
        issues
      });

      addAuditLog('Database Integrity Verified', currentUser?.id || 'unknown', currentUser?.name || 'unknown');
    } catch (err: any) {
      showToast('Integrity check failed: ' + err.message, 'error');
    } finally {
      setIsVerifying(false);
    }
  };
  
  const handleCleanOrphans = async () => {
    if (!isFirebaseEnabled || !db) {
      showToast('Firestore is not connected.', 'error');
      return;
    }
    
    setIsCleaning(true);
    showToast('Scanning for orphan records...', 'info');
    
    try {
      const clients = await fetchCollectionSafe('clients');
      const tasks = await fetchCollectionSafe('tasks');
      const reminders = await fetchCollectionSafe('reminders');
      const history = await fetchCollectionSafe('reminder_history');
      const documents = await fetchCollectionSafe('documents');
      const payments = await fetchCollectionSafe('payments');

      const orphans: any[] = [];
      
      // Orphan Tasks
      tasks.forEach((t: any) => {
        if (!t.clientId || !clients.find((c: any) => c.id === t.clientId)) {
          orphans.push({ id: t.id, type: 'Task', collection: 'tasks', reason: 'Missing client' });
        }
      });
      
      // Orphan Reminders
      reminders.forEach((r: any) => {
        if (!tasks.find((t: any) => t.id === r.taskId)) {
          orphans.push({ id: r.id, type: 'Reminder', collection: 'reminders', reason: 'Missing task' });
        }
      });
      
      // Orphan History
      history.forEach((h: any) => {
        if (!tasks.find((t: any) => t.id === h.taskId)) {
          orphans.push({ id: h.id, type: 'Reminder History', collection: 'reminder_history', reason: 'Missing task' });
        }
      });
      
      // Orphan Documents (Assume they use clientId or taskId)
      documents.forEach((d: any) => {
        if (d.clientId && !clients.find((c: any) => c.id === d.clientId)) {
          orphans.push({ id: d.id, type: 'Document', collection: 'documents', reason: 'Missing client' });
        }
        if (d.taskId && !tasks.find((t: any) => t.id === d.taskId)) {
          orphans.push({ id: d.id, type: 'Document', collection: 'documents', reason: 'Missing task' });
        }
      });
      
      // Orphan Payments
      payments.forEach((p: any) => {
        if (p.taskId && !tasks.find((t: any) => t.id === p.taskId)) {
          orphans.push({ id: p.id, type: 'Payment', collection: 'payments', reason: 'Missing task' });
        }
      });

      setOrphanRecords(orphans);
      setShowCleanupConfirm(true);
      
    } catch (err: any) {
      showToast('Cleanup scan failed: ' + err.message, 'error');
    } finally {
      setIsCleaning(false);
    }
  };

  const confirmCleanOrphans = async () => {
    if (!isFirebaseEnabled || !db) return;
    
    setIsCleaning(true);
    setShowCleanupConfirm(false);
    showToast('Cleaning orphan records...', 'info');
    
    try {
      let deletedCount = 0;
      for (const record of orphanRecords) {
        await deleteDoc(doc(db, record.collection, record.id));
        deletedCount++;
      }
      
      setCleanupReport({
        deleted: deletedCount,
        details: orphanRecords
      });
      
      addAuditLog('Database Cleanup executed by Admin', currentUser?.id || 'unknown', currentUser?.name || 'unknown', undefined, `Deleted ${deletedCount} orphan records`);
      showToast('Database cleanup completed.', 'success');
      
    } catch (err: any) {
      showToast('Cleanup failed: ' + err.message, 'error');
    } finally {
      setIsCleaning(false);
    }
  };

  const handleRebuildStats = async () => {
    setIsRebuilding(true);
    showToast('Rebuilding dashboard statistics...', 'info');
    
    try {
      if (isFirebaseEnabled) {
        stopFirestoreSync();
        await startFirestoreSync();
      }
      
      window.dispatchEvent(new Event('database-sync'));
      addAuditLog('Dashboard Statistics Rebuilt', currentUser?.id || 'unknown', currentUser?.name || 'unknown');
      
      showToast('Dashboard statistics rebuilt successfully.', 'success');
    } catch (err: any) {
      showToast('Rebuild failed: ' + err.message, 'error');
    } finally {
      setIsRebuilding(false);
    }
  };
return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in duration-300 max-w-7xl mx-auto pb-12 w-full">
      {/* Title Header */}
      <div className="px-1">
        <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center">
          <SettingsIcon className="w-6 h-6 md:w-8 md:h-8 mr-3 text-slate-700" />
          Administration Center
        </h1>
        <p className="text-sm md:text-base text-slate-500 mt-1 md:mt-2">
          Manage system maintenance, database backups, security controls, and tenant information.
        </p>
      </div>

      <div className="space-y-6 md:space-y-8">

        {/* 1. System Maintenance */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col">
          <div className="p-5 md:p-6 border-b border-slate-100 bg-slate-50/50">
            <h3 className="font-bold text-slate-900 text-base md:text-lg flex items-center">
              <Database className="w-5 h-5 mr-2 text-[#F43F5E]" />
              System Maintenance
            </h3>
            <p className="text-xs md:text-sm text-slate-500 mt-1">
              Run compliance checks and synchronize data with Cloud Firestore.
            </p>
          </div>
          <div className="p-5 md:p-6">
            {currentUser?.role === 'Admin' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
                <button
                  onClick={handleRefreshData}
                  className="w-full inline-flex items-center justify-center min-h-[44px] px-4 text-sm font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 hover:border-slate-400 shadow-xs cursor-pointer transition-all active:scale-[0.98]"
                >
                  <RotateCcw className="w-4 h-4 mr-2.5 text-slate-500" />
                  Refresh Data
                </button>
                <button
                  onClick={handleRunComplianceCheck}
                  className="w-full inline-flex items-center justify-center min-h-[44px] px-4 text-sm font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 hover:border-slate-400 shadow-xs cursor-pointer transition-all active:scale-[0.98]"
                >
                  <CheckCircle2 className="w-4 h-4 mr-2.5 text-slate-500" />
                  Run Compliance Check
                </button>
                <button
                  onClick={handleSyncDatabaseNow}
                  className="w-full inline-flex items-center justify-center min-h-[44px] px-4 text-sm font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 hover:border-slate-400 shadow-xs cursor-pointer transition-all active:scale-[0.98]"
                >
                  <Sparkles className="w-4 h-4 mr-2.5 text-slate-500" />
                  Sync Database Now
                </button>
              </div>
            ) : (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 shrink-0 text-amber-600" />
                <div>
                  <strong className="font-semibold block mb-0.5">Access Restricted</strong>
                  Your account role ({currentUser?.role || 'Staff'}) does not have administrative clearance for system maintenance.
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 2. Backup & Export */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col">
          <div className="p-5 md:p-6 border-b border-slate-100 bg-slate-50/50">
            <h3 className="font-bold text-slate-900 text-base md:text-lg flex items-center">
              <HardDrive className="w-5 h-5 mr-2 text-[#F43F5E]" />
              Backup & Export
            </h3>
            <p className="text-xs md:text-sm text-slate-500 mt-1">
              Export and archive complete database records securely.
            </p>
          </div>
          <div className="p-5 md:p-6">
            {currentUser?.role === 'Admin' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4 lg:flex lg:flex-row">
                <button
                  onClick={handleDownloadFullBackup}
                  className="w-full lg:w-auto inline-flex items-center justify-center min-h-[44px] px-6 text-sm font-semibold text-white bg-[#F43F5E] hover:bg-rose-600 rounded-xl shadow-xs cursor-pointer transition-all active:scale-[0.98]"
                >
                  <FileSpreadsheet className="w-4 h-4 mr-2.5 text-rose-50" />
                  Download Excel Backup
                </button>
                <button
                  onClick={handleExportJSON}
                  className="w-full lg:w-auto inline-flex items-center justify-center min-h-[44px] px-6 text-sm font-semibold text-[#F43F5E] bg-white border border-rose-200 rounded-xl hover:bg-rose-50 shadow-xs cursor-pointer transition-all active:scale-[0.98]"
                >
                  <Download className="w-4 h-4 mr-2.5 text-rose-400" />
                  Export JSON Data
                </button>
              </div>
            ) : (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 shrink-0 text-amber-600" />
                <div>
                  <strong className="font-semibold block mb-0.5">Access Restricted</strong>
                  Your account role ({currentUser?.role || 'Staff'}) does not have administrative clearance to compile or download database backup archives.
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 3. Database Maintenance */}
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col">
          <div className="p-5 md:p-6 border-b border-slate-100 bg-slate-50/50">
            <h3 className="font-bold text-slate-900 text-base md:text-lg flex items-center">
              <Database className="w-5 h-5 mr-2 text-[#F43F5E]" />
              Database Maintenance
            </h3>
            <p className="text-xs md:text-sm text-slate-500 mt-1">
              Professional database cleanup and optimization routines.
            </p>
          </div>
          <div className="p-5 md:p-6">
            {currentUser?.role === 'Admin' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                
                {/* Card 1 */}
                <div className="flex flex-col border border-slate-200 rounded-xl p-5 hover:border-rose-200 hover:shadow-sm transition-all bg-white group">
                  <div className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center mb-4 group-hover:bg-rose-50 group-hover:border-rose-100 transition-colors">
                    <ShieldCheck className="w-5 h-5 text-slate-500 group-hover:text-[#F43F5E]" />
                  </div>
                  <h4 className="font-bold text-slate-900 text-sm md:text-base">Verify Database Integrity</h4>
                  <p className="text-xs md:text-sm text-slate-500 mt-1 mb-5 grow leading-relaxed">
                    Scan database collections for corrupted, missing, or malformed documents.
                  </p>
                  <button
    onClick={handleVerifyIntegrity}
    disabled={isVerifying}
    className="w-full inline-flex items-center justify-center min-h-[40px] px-4 text-xs md:text-sm font-semibold text-slate-700 bg-slate-50 border border-slate-200 hover:bg-slate-100 hover:border-slate-300 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
  >
    {isVerifying ? 'Scanning...' : 'Verify Integrity'}
                    Verify Integrity
                  </button>
                </div>
                
                {/* Card 2 */}
                <div className="flex flex-col border border-slate-200 rounded-xl p-5 hover:border-rose-200 hover:shadow-sm transition-all bg-white group">
                  <div className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center mb-4 group-hover:bg-rose-50 group-hover:border-rose-100 transition-colors">
                    <Trash2 className="w-5 h-5 text-slate-500 group-hover:text-[#F43F5E]" />
                  </div>
                  <h4 className="font-bold text-slate-900 text-sm md:text-base">Clean Orphan Records</h4>
                  <p className="text-xs md:text-sm text-slate-500 mt-1 mb-5 grow leading-relaxed">
                    Remove disconnected client records, old revisions, and free up storage.
                  </p>
                  <button
    onClick={handleCleanOrphans}
    disabled={isCleaning}
    className="w-full inline-flex items-center justify-center min-h-[40px] px-4 text-xs md:text-sm font-semibold text-slate-700 bg-slate-50 border border-slate-200 hover:bg-slate-100 hover:border-slate-300 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
  >
    {isCleaning ? 'Scanning...' : 'Clean Records'}
                    Clean Records
                  </button>
                </div>
                
                {/* Card 3 */}
                <div className="flex flex-col border border-slate-200 rounded-xl p-5 hover:border-rose-200 hover:shadow-sm transition-all bg-white group">
                  <div className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center mb-4 group-hover:bg-rose-50 group-hover:border-rose-100 transition-colors">
                    <RotateCw className="w-5 h-5 text-slate-500 group-hover:text-[#F43F5E]" />
                  </div>
                  <h4 className="font-bold text-slate-900 text-sm md:text-base">Rebuild Dashboard Stats</h4>
                  <p className="text-xs md:text-sm text-slate-500 mt-1 mb-5 grow leading-relaxed">
                    Recalculate key performance indicators and aggregate compliance metrics.
                  </p>
                  <button
    onClick={handleRebuildStats}
    disabled={isRebuilding}
    className="w-full inline-flex items-center justify-center min-h-[40px] px-4 text-xs md:text-sm font-semibold text-slate-700 bg-slate-50 border border-slate-200 hover:bg-slate-100 hover:border-slate-300 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
  >
    {isRebuilding ? 'Rebuilding...' : 'Rebuild Stats'}
                    Rebuild Stats
                  </button>
                </div>

              </div>
            ) : (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 shrink-0 text-amber-600" />
                <div>
                  <strong className="font-semibold block mb-0.5">Access Restricted</strong>
                  Your account role ({currentUser?.role || 'Staff'}) does not have administrative clearance.
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 2-Column Grid for Information Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
          
          {/* 4. Security & Access */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col">
            <div className="p-5 md:p-6 border-b border-slate-100 bg-slate-50/50">
              <h3 className="font-bold text-slate-900 text-base md:text-lg flex items-center">
                <ShieldCheck className="w-5 h-5 mr-2 text-[#F43F5E]" />
                Security & Access
              </h3>
              <p className="text-xs md:text-sm text-slate-500 mt-1">
                Active session context and identity authorization.
              </p>
            </div>
            <div className="p-5 md:p-6 grow">
              <div className="space-y-4">
                <div className="flex flex-col items-start md:flex-row md:justify-between md:items-center py-2 md:py-3 border-b border-slate-100 gap-1 md:gap-4 break-words">
                  <span className="text-sm font-medium text-slate-500">Logged-in User</span>
                  <strong className="text-sm text-slate-900">{currentUser?.name || 'Guest'}</strong>
                </div>
                <div className="flex flex-col items-start md:flex-row md:justify-between md:items-center py-2 md:py-3 border-b border-slate-100 gap-1 md:gap-4 break-words">
                  <span className="text-sm font-medium text-slate-500">Email</span>
                  <span className="text-sm font-medium text-slate-700">{currentUser?.email || 'N/A'}</span>
                </div>
                <div className="flex flex-col items-start md:flex-row md:justify-between md:items-center py-2 md:py-3 border-b border-slate-100 gap-1 md:gap-4 break-words">
                  <span className="text-sm font-medium text-slate-500">Role</span>
                  <span className="inline-flex px-2.5 py-1 rounded-md text-[10px] md:text-xs font-bold uppercase tracking-wider bg-rose-50 text-[#F43F5E] border border-rose-200">
                    {currentUser?.role || 'Staff'}
                  </span>
                </div>
                <div className="flex flex-col items-start md:flex-row md:justify-between md:items-center py-2 md:py-3 border-b border-slate-100 gap-1 md:gap-4 break-words">
                  <span className="text-sm font-medium text-slate-500">Session Status</span>
                  <span className="flex items-center text-sm font-medium text-emerald-600">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 mr-2"></span>
                    Active
                  </span>
                </div>
                <div className="flex flex-col items-start md:flex-row md:justify-between md:items-center py-2 md:py-3 border-b border-slate-100 gap-1 md:gap-4 break-words">
                  <span className="text-sm font-medium text-slate-500">Last Login</span>
                  <span className="text-sm font-medium text-slate-700">Just now</span>
                </div>
                <div className="flex flex-col items-start md:flex-row md:justify-between md:items-center py-2 md:py-3 gap-1 md:gap-4 break-words">
                  <span className="text-sm font-medium text-slate-500">Active Device</span>
                  <span className="text-sm font-medium text-slate-700 flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-slate-400" />
                    Web Browser
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* 5. System Information */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col">
            <div className="p-5 md:p-6 border-b border-slate-100 bg-slate-50/50">
              <h3 className="font-bold text-slate-900 text-base md:text-lg flex items-center">
                <Info className="w-5 h-5 mr-2 text-[#F43F5E]" />
                System Information
              </h3>
              <p className="text-xs md:text-sm text-slate-500 mt-1">
                Platform specifications and active deployment status.
              </p>
            </div>
            <div className="p-5 md:p-6 grow">
              <div className="space-y-4">
                <div className="flex flex-col items-start md:flex-row md:justify-between md:items-center py-2 md:py-3 border-b border-slate-100 gap-1 md:gap-4 break-words">
                  <span className="text-sm font-medium text-slate-500">CRM Version</span>
                  <strong className="text-sm font-mono font-medium text-slate-900">v1.2.0-stable</strong>
                </div>
                <div className="flex flex-col items-start md:flex-row md:justify-between md:items-center py-2 md:py-3 border-b border-slate-100 gap-1 md:gap-4 break-words">
                  <span className="text-sm font-medium text-slate-500">Environment</span>
                  <span className="inline-flex px-2.5 py-1 rounded-md text-[10px] md:text-xs font-bold uppercase tracking-wider bg-slate-100 text-slate-700 border border-slate-200">
                    Production
                  </span>
                </div>
                <div className="flex flex-col items-start md:flex-row md:justify-between md:items-center py-2 md:py-3 border-b border-slate-100 gap-1 md:gap-4 break-words">
                  <span className="text-sm font-medium text-slate-500">Firebase Status</span>
                  <span className="flex items-center text-sm font-medium text-emerald-600">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 mr-2"></span>
                    Connected
                  </span>
                </div>
                <div className="flex flex-col items-start md:flex-row md:justify-between md:items-center py-2 md:py-3 border-b border-slate-100 gap-1 md:gap-4 break-words">
                  <span className="text-sm font-medium text-slate-500">Firestore Status</span>
                  <span className="flex items-center text-sm font-medium text-emerald-600">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 mr-2"></span>
                    Online
                  </span>
                </div>
                <div className="flex flex-col items-start md:flex-row md:justify-between md:items-center py-2 md:py-3 border-b border-slate-100 gap-1 md:gap-4 break-words">
                  <span className="text-sm font-medium text-slate-500">Last Synchronization</span>
                  <span className="text-sm font-medium text-slate-700 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    Realtime Sync Active
                  </span>
                </div>
                <div className="flex flex-col items-start md:flex-row md:justify-between md:items-center py-2 md:py-3 gap-1 md:gap-4 break-words">
                  <span className="text-sm font-medium text-slate-500">PWA Status</span>
                  <span className="flex items-center text-sm font-medium text-emerald-600">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 mr-2"></span>
                    Active
                  </span>
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>


      {/* Integrity Report Modal */}
      {integrityReport && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h2 className="text-lg font-bold text-slate-900 flex items-center">
                <ShieldCheck className="w-5 h-5 mr-2 text-emerald-500" />
                Database Integrity Report
              </h2>
              <button
                onClick={() => setIntegrityReport(null)}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1">Collections</span>
                  <strong className="text-2xl font-black text-slate-900">{integrityReport.totalCollections}</strong>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1">Documents</span>
                  <strong className="text-2xl font-black text-slate-900">{integrityReport.totalDocs}</strong>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1">Issues</span>
                  <strong className={`text-2xl font-black ${integrityReport.issuesFound > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                    {integrityReport.issuesFound}
                  </strong>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1">Health</span>
                  <strong className={`text-2xl font-black ${integrityReport.healthyPercent < 100 ? 'text-amber-500' : 'text-emerald-600'}`}>
                    {integrityReport.healthyPercent}%
                  </strong>
                </div>
              </div>

              {integrityReport.issuesFound > 0 ? (
                <div>
                  <h3 className="font-semibold text-slate-900 mb-3 text-sm">Detected Issues</h3>
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                    {integrityReport.issues.map((issue: string, idx: number) => (
                      <div key={idx} className="p-3 bg-rose-50 border border-rose-100 text-rose-800 text-sm rounded-lg flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-rose-600 mt-0.5 shrink-0" />
                        <span>{issue}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check className="w-8 h-8 text-emerald-600" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">Database is Healthy</h3>
                  <p className="text-slate-500 mt-2">No integrity issues or broken references found.</p>
                </div>
              )}
            </div>
            
            <div className="p-4 border-t border-slate-100 bg-slate-50 text-right">
              <button
                onClick={() => setIntegrityReport(null)}
                className="px-6 py-2 bg-slate-900 text-white text-sm font-semibold rounded-lg hover:bg-slate-800 transition-colors"
              >
                Close Report
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Orphan Cleanup Confirm Modal */}
      {showCleanupConfirm && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden flex flex-col">
            <div className="p-6 border-b border-slate-100 bg-rose-50">
              <h2 className="text-lg font-bold text-rose-900 flex items-center">
                <AlertTriangle className="w-5 h-5 mr-2 text-rose-600" />
                Database Cleanup
              </h2>
            </div>
            
            <div className="p-6">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Trash2 className="w-8 h-8 text-rose-600" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Found {orphanRecords.length} orphan records</h3>
                <p className="text-slate-500 mt-2 text-sm">
                  These records have missing or deleted parents and are taking up space.
                </p>
              </div>

              <div className="space-y-2 mb-6 max-h-40 overflow-y-auto">
                {orphanRecords.slice(0, 5).map((rec, idx) => (
                  <div key={idx} className="flex justify-between items-center p-2 bg-slate-50 border border-slate-100 rounded-lg text-sm">
                    <span className="font-medium text-slate-700">{rec.type}</span>
                    <span className="text-slate-500 text-xs">{rec.reason}</span>
                  </div>
                ))}
                {orphanRecords.length > 5 && (
                  <div className="text-center text-xs font-semibold text-slate-500 py-2">
                    + {orphanRecords.length - 5} more records
                  </div>
                )}
              </div>
              
              <div className="p-3 bg-amber-50 border border-amber-200 text-amber-800 text-xs rounded-lg rounded">
                <strong>Warning:</strong> Deleting these records cannot be undone. Make sure you have a recent backup.
              </div>
            </div>
            
            <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
              <button
                onClick={() => setShowCleanupConfirm(false)}
                disabled={isCleaning}
                className="px-4 py-2 bg-white border border-slate-300 text-slate-700 text-sm font-semibold rounded-lg hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={confirmCleanOrphans}
                disabled={isCleaning}
                className="px-6 py-2 bg-rose-600 text-white text-sm font-semibold rounded-lg hover:bg-rose-700 transition-colors disabled:opacity-50 flex items-center"
              >
                {isCleaning ? 'Cleaning...' : 'Clean Now'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Orphan Cleanup Report Modal */}
      {cleanupReport && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden flex flex-col">
            <div className="p-6 text-center">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Cleanup Complete</h3>
              <p className="text-slate-500 text-sm mb-6">
                Successfully deleted {cleanupReport.deleted} orphan records from the database.
              </p>
              <button
                onClick={() => setCleanupReport(null)}
                className="w-full py-2.5 bg-slate-900 text-white text-sm font-semibold rounded-lg hover:bg-slate-800 transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );

}
