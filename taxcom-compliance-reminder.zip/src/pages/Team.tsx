import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  Plus,
  Trash2,
  Sliders,
  CheckCircle,
  AlertTriangle,
  Briefcase,
  TrendingUp,
  UserCheck,
  UserX,
  Search,
  Filter,
  ArrowUpDown,
  Check,
  X,
  ChevronLeft,
  ChevronRight,
  Clock,
  FileText,
  CreditCard,
  Calendar,
  Eye,
  Edit,
  Power,
  Layers,
  UserMinus
} from 'lucide-react';
import {
  getAllStaff,
  createStaff,
  updateStaff,
  deleteStaff,
  getTasks,
  getClients,
  createTask,
  getReminders,
  getReminderHistory,
  addAuditLog
} from '../db/storage';
import { Staff, ComplianceTask, Client, ServiceCategory, TaskStatus, PaymentStatus, RecurrenceType, ReminderItem, ReminderHistoryItem } from '../types';
import { useToast } from '../components/Toast';
import { useAuth } from '../components/AuthContext';
import { isFirebaseEnabled, db, deleteDoc } from '../db/firebase';
import { collection, doc, getDocs } from 'firebase/firestore';

export default function Team() {
  const { showToast } = useToast();
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  // Core States
  const [staff, setStaff] = useState<Staff[]>(() => getAllStaff());
  const [clients, setClients] = useState<Client[]>(() => getClients());
  const [tasks, setTasks] = useState<ComplianceTask[]>(() => getTasks());

  const refreshData = () => {
    setStaff(getAllStaff());
    setClients(getClients());
    setTasks(getTasks());
  };

  // Search & Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRole, setFilterRole] = useState<string>('All');
  const [filterActive, setFilterActive] = useState<string>('All');
  const [filterWorkload, setFilterWorkload] = useState<string>('All');
  const [filterOverdueOnly, setFilterOverdueOnly] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>('All');

  // Sorting
  const [sortBy, setSortBy] = useState<'name' | 'overdue' | 'assigned' | 'completion'>('name');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  // Modals state
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isAssignOpen, setIsAssignOpen] = useState(false);
  const [isViewTasksOpen, setIsViewTasksOpen] = useState(false);

  // Form states - Create Staff
  const [createFormName, setCreateFormName] = useState('');
  const [createFormRole, setCreateFormRole] = useState<'Admin' | 'Manager' | 'Staff'>('Staff');
  const [createFormEmail, setCreateFormEmail] = useState('');
  const [createFormPhone, setCreateFormPhone] = useState('');

  // Form states - Edit Staff
  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);
  const [editFormName, setEditFormName] = useState('');
  const [editFormRole, setEditFormRole] = useState<'Admin' | 'Manager' | 'Staff'>('Staff');
  const [editFormEmail, setEditFormEmail] = useState('');
  const [editFormPhone, setEditFormPhone] = useState('');

  // Form states - Assign Task
  const [assignFormStaff, setAssignFormStaff] = useState<Staff | null>(null);
  const [assignFormClient, setAssignFormClient] = useState<string>('');
  const [assignFormCategory, setAssignFormCategory] = useState<ServiceCategory>('GST');
  const [assignFormReturnName, setAssignFormReturnName] = useState('');
  const [assignFormFY, setAssignFormFY] = useState('2026-27');
  const [assignFormAY, setAssignFormAY] = useState('2027-28');
  const [assignFormPeriod, setAssignFormPeriod] = useState('June 2026');
  const [assignFormDueDate, setAssignFormDueDate] = useState('2026-07-25');
  const [assignFormPriority, setAssignFormPriority] = useState<'Low' | 'Medium' | 'High' | 'Urgent'>('Medium');
  const [assignFormFees, setAssignFormFees] = useState(1500);
  const [assignFormRecurrence, setAssignFormRecurrence] = useState<RecurrenceType>('Monthly');
  const [assignFormDocs, setAssignFormDocs] = useState<string[]>(['Bank Statement', 'Sales Invoice']);
  const [assignFormNotes, setAssignFormNotes] = useState('');

  // Form states - View Tasks modal
  const [viewTasksStaff, setViewTasksStaff] = useState<Staff | null>(null);
  const [viewTasksSearch, setViewTasksSearch] = useState('');

  // Permanent Delete Modal states
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [staffToDelete, setStaffToDelete] = useState<Staff | null>(null);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [isCheckingDependencies, setIsCheckingDependencies] = useState(false);

  // Dynamic Workload helper function
  const computeStaffMetrics = (stId: string) => {
    const staffTasks = tasks.filter(t => !t.isDeleted && t.assignedStaffId === stId);
    const total = staffTasks.length;
    const completed = staffTasks.filter(t => t.status === 'Completed' || t.status === 'Filed').length;
    const pending = total - completed;

    const dueToday = staffTasks.filter(t => {
      return !(t.status === 'Completed' || t.status === 'Filed') && t.dueDate === '2026-07-17';
    }).length;

    const upcoming7Days = staffTasks.filter(t => {
      return !(t.status === 'Completed' || t.status === 'Filed') && t.dueDate > '2026-07-17' && t.dueDate <= '2026-07-24';
    }).length;

    const overdue = staffTasks.filter(t => {
      return !(t.status === 'Completed' || t.status === 'Filed') && t.dueDate < '2026-07-17';
    }).length;

    const docsPending = staffTasks.filter(t => {
      return t.status === 'Documents Pending' || (t.documentsPending && t.documentsPending.length > 0);
    }).length;

    const paymentPending = staffTasks.filter(t => {
      return t.paymentStatus === 'Pending' || t.paymentStatus === 'Partial';
    }).length;

    const rate = total > 0 ? Math.round((completed / total) * 100) : 0;

    // Use pending tasks, overdue tasks and due-today tasks to calculate workload
    const score = pending + (overdue * 2) + (dueToday * 1.5);
    let workload: 'Low' | 'Normal' | 'High' | 'Overloaded' = 'Low';
    if (score > 10) {
      workload = 'Overloaded';
    } else if (score > 6) {
      workload = 'High';
    } else if (score > 2) {
      workload = 'Normal';
    } else {
      workload = 'Low';
    }

    // Simulated last active time mapped statically to IDs for reliable clean visualization
    let lastActive = 'Active Now';
    if (stId.includes('st-')) {
      const charSum = stId.split('').reduce((acc, curr) => acc + curr.charCodeAt(0), 0);
      const diffMins = (charSum % 45) + 5;
      if (diffMins < 10) lastActive = 'Active Now';
      else if (diffMins < 60) lastActive = `${diffMins} mins ago`;
      else lastActive = `Today, 0${(diffMins % 4) + 9}:30 AM`;
    }

    return {
      total,
      completed,
      pending,
      dueToday,
      upcoming7Days,
      overdue,
      docsPending,
      paymentPending,
      rate,
      workload,
      lastActive,
      score
    };
  };

  // Global KPIs computation
  const globalKpis = React.useMemo(() => {
    const totalStaffCount = staff.length;
    const activeStaffCount = staff.filter(s => s.active).length;
    const totalAssignedTasks = tasks.filter(t => !t.isDeleted && t.assignedStaffId).length;
    
    const dueTodayCount = tasks.filter(t => 
      !t.isDeleted && 
      !(t.status === 'Completed' || t.status === 'Filed') && 
      t.dueDate === '2026-07-17'
    ).length;

    const overdueCount = tasks.filter(t => 
      !t.isDeleted && 
      !(t.status === 'Completed' || t.status === 'Filed') && 
      t.dueDate < '2026-07-17'
    ).length;

    const unassignedCount = tasks.filter(t => 
      !t.isDeleted && 
      !t.assignedStaffId
    ).length;

    return {
      totalStaff: totalStaffCount,
      activeStaff: activeStaffCount,
      totalAssignedTasks,
      dueToday: dueTodayCount,
      overdue: overdueCount,
      unassigned: unassignedCount
    };
  }, [staff, tasks]);

  // Unique compliance categories currently assigned to tasks
  const availableCategories = React.useMemo(() => {
    const cats = tasks.filter(t => !t.isDeleted).map(t => t.serviceCategory);
    return Array.from(new Set(cats));
  }, [tasks]);

  // Staff creation logic
  const handleCreateStaffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!createFormName.trim()) {
      showToast('Staff partner name is required.', 'error');
      return;
    }

    createStaff({
      name: createFormName.trim(),
      role: createFormRole,
      email: createFormEmail.trim() || '',
      phone: createFormPhone.trim() || undefined,
      active: true,
    });

    showToast(`Successfully created staff member "${createFormName}" as "${createFormRole}".`, 'success');
    setIsCreateOpen(false);
    
    // reset fields
    setCreateFormName('');
    setCreateFormRole('Staff');
    setCreateFormEmail('');
    setCreateFormPhone('');

    refreshData();
  };

  // Staff edit logic
  const handleEditStaffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStaff) return;
    if (!editFormName.trim()) {
      showToast('Staff partner name is required.', 'error');
      return;
    }

    updateStaff(selectedStaff.id, {
      name: editFormName.trim(),
      role: editFormRole,
      email: editFormEmail.trim() || '',
      phone: editFormPhone.trim() || undefined,
    });

    showToast(`Successfully updated profile details for "${editFormName}".`, 'success');
    setIsEditOpen(false);
    setSelectedStaff(null);
    refreshData();
  };

  // Soft activation / deactivation toggle
  const handleToggleActive = (st: Staff) => {
    // Safety check: Cannot deactivate self or default Admin
    if (st.id === currentUser?.id) {
      showToast('Deactivating your own session is prohibited.', 'error');
      return;
    }

    const nextState = !st.active;
    updateStaff(st.id, { active: nextState });
    
    showToast(
      `Soft ${nextState ? 'activation' : 'deactivation'} applied for "${st.name}".`, 
      nextState ? 'success' : 'warning'
    );
    refreshData();
  };

  // Deletion dependency check helper for local render & tooltip visibility
  const getStaffDependenciesCount = (stId: string, stName: string) => {
    // 1. Assigned / incomplete task count
    const assignedTasksCount = tasks.filter(t => !t.isDeleted && t.assignedStaffId === stId && t.status !== 'Completed' && t.status !== 'Filed').length;
    // 2. Completed task count
    const completedTasksCount = tasks.filter(t => !t.isDeleted && t.assignedStaffId === stId && (t.status === 'Completed' || t.status === 'Filed')).length;
    // 3. Client assignment
    const assignedClientsCount = clients.filter(c => !c.isDeleted && c.assignedStaffId === stId).length;
    // 4. Payment records (tasks assigned to this staff that have a payment or fee assigned)
    const paymentsCount = tasks.filter(t => !t.isDeleted && t.assignedStaffId === stId && (t.professionalFees > 0 || t.amountReceived > 0)).length;
    // 5. Reminders linked to this staff's tasks
    const remindersList = getReminders();
    const remindersCount = remindersList.filter(r => tasks.some(t => t.id === r.taskId && t.assignedStaffId === stId)).length;
    // 6. Reminder history linked to this staff's tasks or sent by this staff member
    const historyList = getReminderHistory();
    const historyCount = historyList.filter(h => h.sentBy === stName || tasks.some(t => t.id === h.taskId && t.assignedStaffId === stId)).length;

    const totalDeps = assignedTasksCount + completedTasksCount + assignedClientsCount + paymentsCount + remindersCount + historyCount;

    return {
      assignedTasksCount,
      completedTasksCount,
      assignedClientsCount,
      paymentsCount,
      remindersCount,
      historyCount,
      totalDeps
    };
  };

  // Perform a fresh live Firestore (or LocalStorage) check right before executing deletion
  const runFreshFirestoreCheck = async (stId: string, stName: string): Promise<{ hasDeps: boolean; reason?: string }> => {
    if (!isFirebaseEnabled || !db) {
      // Fallback if running in high-fidelity LocalStorage mode
      const freshTasks = getTasks();
      const freshClients = getClients();
      const freshReminders = getReminders();
      const freshHistory = getReminderHistory();

      const assignedTasks = freshTasks.filter(t => !t.isDeleted && t.assignedStaffId === stId && t.status !== 'Completed' && t.status !== 'Filed');
      const completedTasks = freshTasks.filter(t => !t.isDeleted && t.assignedStaffId === stId && (t.status === 'Completed' || t.status === 'Filed'));
      const assignedClients = freshClients.filter(c => !c.isDeleted && c.assignedStaffId === stId);
      const hasPayments = freshTasks.some(t => !t.isDeleted && t.assignedStaffId === stId && (t.professionalFees > 0 || t.amountReceived > 0));
      const hasReminders = freshReminders.some(r => freshTasks.some(t => t.id === r.taskId && t.assignedStaffId === stId));
      const hasHistory = freshHistory.some(h => h.sentBy === stName || freshTasks.some(t => t.id === h.taskId && t.assignedStaffId === stId));

      if (assignedTasks.length > 0) return { hasDeps: true, reason: `Assigned Tasks: ${assignedTasks.length}` };
      if (completedTasks.length > 0) return { hasDeps: true, reason: `Completed Tasks: ${completedTasks.length}` };
      if (assignedClients.length > 0) return { hasDeps: true, reason: `Assigned Clients: ${assignedClients.length}` };
      if (hasPayments) return { hasDeps: true, reason: 'Payment records exist' };
      if (hasReminders) return { hasDeps: true, reason: 'Reminder records exist' };
      if (hasHistory) return { hasDeps: true, reason: 'Reminder history records exist' };
      return { hasDeps: false };
    }

    try {
      // Fetch fresh live states from Firestore collections
      const clientsSnap = await getDocs(collection(db, 'clients'));
      const tasksSnap = await getDocs(collection(db, 'tasks'));
      const remindersSnap = await getDocs(collection(db, 'reminders'));
      const historySnap = await getDocs(collection(db, 'reminder_history'));

      const freshClients = clientsSnap.docs.map(doc => doc.data() as Client);
      const freshTasks = tasksSnap.docs.map(doc => doc.data() as ComplianceTask);
      const freshReminders = remindersSnap.docs.map(doc => doc.data() as ReminderItem);
      const freshHistory = historySnap.docs.map(doc => doc.data() as ReminderHistoryItem);

      const assignedTasks = freshTasks.filter(t => !t.isDeleted && t.assignedStaffId === stId && t.status !== 'Completed' && t.status !== 'Filed');
      const completedTasks = freshTasks.filter(t => !t.isDeleted && t.assignedStaffId === stId && (t.status === 'Completed' || t.status === 'Filed'));
      const assignedClients = freshClients.filter(c => !c.isDeleted && c.assignedStaffId === stId);
      const hasPayments = freshTasks.some(t => !t.isDeleted && t.assignedStaffId === stId && (t.professionalFees > 0 || t.amountReceived > 0));
      const hasReminders = freshReminders.some(r => freshTasks.some(t => t.id === r.taskId && t.assignedStaffId === stId));
      const hasHistory = freshHistory.some(h => h.sentBy === stName || freshTasks.some(t => t.id === h.taskId && t.assignedStaffId === stId));

      if (assignedTasks.length > 0) return { hasDeps: true, reason: `Assigned Tasks: ${assignedTasks.length}` };
      if (completedTasks.length > 0) return { hasDeps: true, reason: `Completed Tasks: ${completedTasks.length}` };
      if (assignedClients.length > 0) return { hasDeps: true, reason: `Assigned Clients: ${assignedClients.length}` };
      if (hasPayments) return { hasDeps: true, reason: 'Payment records exist' };
      if (hasReminders) return { hasDeps: true, reason: 'Reminder records exist' };
      if (hasHistory) return { hasDeps: true, reason: 'Reminder history records exist' };
      return { hasDeps: false };
    } catch (err: any) {
      console.error('Error executing fresh dependency validation on Firestore:', err);
      return { hasDeps: true, reason: `Firestore security/connection check failed: ${err.message}` };
    }
  };

  // Perform permanent deletion of the staff profile and dependent metadata
  const executePurgeStaff = async (st: Staff) => {
    try {
      // 1. Delete from LocalStorage (calls the existing deleteStaff function)
      deleteStaff(st.id);

      // 2. Fresh audit log recording (Rule 7)
      const currentUserEmail = currentUser?.email || 'Unknown Admin';
      const currentUserName = currentUser?.name || 'Admin';
      const timestamp = new Date().toISOString();
      const logDetails = `Deleted staff name: ${st.name}, Deleted staff email: ${st.email}, Deleted by: ${currentUserName} (${currentUserEmail}), Deletion date and time: ${timestamp}`;
      
      addAuditLog('Staff Profile Purged', st.id, st.name, st.email, logDetails);

      // 3. Delete from Firebase collections if Firebase is enabled (Rule 6)
      if (isFirebaseEnabled && db) {
        // Delete staff profile
        await deleteDoc(doc(db, 'staff', st.id));
        
        // Delete pending invitation records
        try {
          const invSnap = await getDocs(collection(db, 'pending_invitations'));
          for (const d of invSnap.docs) {
            const data = d.data();
            if (data.email === st.email || data.staffId === st.id || d.id === st.id) {
              await deleteDoc(doc(db, 'pending_invitations', d.id));
            }
          }
        } catch (e) {
          console.log('No pending invitation to delete or collection unmapped:', e);
        }

        // Delete staff tokens
        try {
          const tokensSnap = await getDocs(collection(db, 'staff_tokens'));
          for (const d of tokensSnap.docs) {
            const data = d.data();
            if (data.staffId === st.id || data.userId === st.id || d.id === st.id) {
              await deleteDoc(doc(db, 'staff_tokens', d.id));
            }
          }
        } catch (e) {
          console.log('No staff tokens to delete or collection unmapped:', e);
        }

        // Delete role mappings
        try {
          const rolesSnap = await getDocs(collection(db, 'role_mappings'));
          for (const d of rolesSnap.docs) {
            const data = d.data();
            if (data.staffId === st.id || data.userId === st.id || d.id === st.id) {
              await deleteDoc(doc(db, 'role_mappings', d.id));
            }
          }
        } catch (e) {
          console.log('No role mappings to delete or collection unmapped:', e);
        }

        // Delete non-essential session metadata
        try {
          const sessionsSnap = await getDocs(collection(db, 'session_metadata'));
          for (const d of sessionsSnap.docs) {
            const data = d.data();
            if (data.staffId === st.id || data.userId === st.id || d.id === st.id) {
              await deleteDoc(doc(db, 'session_metadata', d.id));
            }
          }
        } catch (e) {
          console.log('No session metadata to delete or collection unmapped:', e);
        }
      }

      showToast(`Successfully purged profile and cleared all historical records for ${st.name}.`, 'success');
      refreshData();
    } catch (err: any) {
      console.error('Purge execution error:', err);
      showToast(`Purge failed: ${err.message}`, 'error');
    }
  };

  const handleExecuteDelete = async () => {
    if (!staffToDelete) return;
    if (deleteConfirmText !== 'DELETE') {
      showToast('Please type DELETE to confirm.', 'error');
      return;
    }

    setIsCheckingDependencies(true);
    const { hasDeps, reason } = await runFreshFirestoreCheck(staffToDelete.id, staffToDelete.name);
    
    if (hasDeps) {
      setIsCheckingDependencies(false);
      showToast(`Delete Blocked: Fresh check found dependencies (${reason}).`, 'error');
      setIsDeleteModalOpen(false);
      setStaffToDelete(null);
      setDeleteConfirmText('');
      return;
    }

    await executePurgeStaff(staffToDelete);

    setIsCheckingDependencies(false);
    setIsDeleteModalOpen(false);
    setStaffToDelete(null);
    setDeleteConfirmText('');
  };

  // Admin Permanent Delete logic trigger
  const handlePermanentDelete = (st: Staff) => {
    if (currentUser?.role !== 'Admin') {
      showToast('Administrative privileges are required to permanently purge database files.', 'error');
      return;
    }

    if (st.id === currentUser?.id) {
      showToast('Cannot permanently delete your own active profile.', 'error');
      return;
    }

    setStaffToDelete(st);
    setDeleteConfirmText('');
    setIsDeleteModalOpen(true);
  };

  // Quick Compliance Task Assignment Submit
  const handleAssignTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!assignFormStaff) return;
    if (!assignFormClient) {
      showToast('Please select a target client partner.', 'error');
      return;
    }
    if (!assignFormReturnName.trim()) {
      showToast('Filing form return name is required (e.g. GSTR-3B).', 'error');
      return;
    }

    const clientObj = clients.find(c => c.id === assignFormClient);
    if (!clientObj) return;

    createTask({
      clientId: clientObj.id,
      clientName: clientObj.name,
      serviceCategory: assignFormCategory,
      returnName: assignFormReturnName.trim(),
      financialYear: assignFormFY,
      assessmentYear: assignFormAY,
      filingPeriod: assignFormPeriod,
      dueDate: assignFormDueDate,
      priority: assignFormPriority,
      assignedStaffId: assignFormStaff.id,
      assignedStaffName: assignFormStaff.name,
      status: 'Not Started',
      documentsRequired: assignFormDocs,
      documentsPending: assignFormDocs,
      professionalFees: Number(assignFormFees),
      amountReceived: 0,
      paymentStatus: 'Pending',
      recurrence: assignFormRecurrence,
      internalNotes: assignFormNotes.trim() || undefined
    });

    showToast(`Compliance task assigned successfully to "${assignFormStaff.name}".`, 'success');
    setIsAssignOpen(false);
    
    // Clear
    setAssignFormReturnName('');
    setAssignFormNotes('');
    setAssignFormFees(1500);

    refreshData();
  };

  // Collect filtered, sorted, paginated list of staff members
  const filteredStaff = React.useMemo(() => {
    return staff.filter((st) => {
      // 1. Search Query
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const matchesName = st.name.toLowerCase().includes(query);
        const matchesEmail = st.email.toLowerCase().includes(query);
        if (!matchesName && !matchesEmail) return false;
      }

      // 2. Role Filter
      if (filterRole !== 'All' && st.role !== filterRole) {
        return false;
      }

      // 3. Active status filter
      if (filterActive !== 'All') {
        const isActiveFilter = filterActive === 'Active';
        if (st.active !== isActiveFilter) return false;
      }

      const metrics = computeStaffMetrics(st.id);

      // 4. Workload Filter
      if (filterWorkload !== 'All' && metrics.workload !== filterWorkload) {
        return false;
      }

      // 5. Overdue filter
      if (filterOverdueOnly && metrics.overdue === 0) {
        return false;
      }

      // 6. Category Filter
      if (filterCategory !== 'All') {
        const staffTasks = tasks.filter(t => !t.isDeleted && t.assignedStaffId === st.id);
        const hasCategory = staffTasks.some(t => t.serviceCategory === filterCategory);
        if (!hasCategory) return false;
      }

      return true;
    }).sort((a, b) => {
      const metricsA = computeStaffMetrics(a.id);
      const metricsB = computeStaffMetrics(b.id);

      if (sortBy === 'overdue') {
        return metricsB.overdue - metricsA.overdue;
      }
      if (sortBy === 'assigned') {
        return metricsB.total - metricsA.total;
      }
      if (sortBy === 'completion') {
        return metricsA.rate - metricsB.rate; // lowest first
      }
      // default: staff name
      return a.name.localeCompare(b.name);
    });
  }, [staff, tasks, clients, searchQuery, filterRole, filterActive, filterWorkload, filterOverdueOnly, filterCategory, sortBy]);

  // Paginated chunk
  const paginatedStaff = React.useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredStaff.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredStaff, currentPage]);

  const totalPages = Math.ceil(filteredStaff.length / itemsPerPage) || 1;

  // Handle page resets on filter modifications
  React.useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, filterRole, filterActive, filterWorkload, filterOverdueOnly, filterCategory, sortBy]);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* 1. Header & Live Cloud Synchronicity */}
      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4 bg-white p-6 border border-slate-200 rounded-2xl shadow-xs">
        <div>
          <h1 id="team-header-title" className="text-2xl font-black text-slate-900 tracking-tight flex items-center">
            <Users className="w-6 h-6 mr-2.5 text-[#F5405E]" />
            Staff Partners & Workloads
          </h1>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            Audit team tasks, manage assignments, and review real-time workload parameters across enterprise roles. Soft deactivate members during off-seasons or permanently prune unassigned files.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Synchronicity Badge Indicator */}
          <div className={`inline-flex items-center px-3 py-1.5 rounded-lg text-xs font-semibold border ${
            isFirebaseEnabled 
              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
              : 'bg-rose-50 text-rose-700 border-rose-200'
          }`}>
            <span className={`w-2 h-2 rounded-full mr-2 ${isFirebaseEnabled ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`}></span>
            <div>
              <span className="font-bold">{isFirebaseEnabled ? 'Cloud Connected' : 'Offline'}</span>
              <span className="block text-[9px] text-slate-400 font-normal leading-none mt-0.5">
                {isFirebaseEnabled ? 'Live Firestore Synchronization Enabled' : 'Local Storage Engine Active'}
              </span>
            </div>
          </div>

          {(currentUser?.role === 'Admin' || currentUser?.role === 'Manager') && (
            <button
              onClick={() => setIsCreateOpen(true)}
              className="inline-flex items-center px-4 py-2.5 text-xs font-black text-white bg-[#F5405E] hover:bg-rose-600 rounded-xl shadow-sm transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4 mr-1.5" />
              Add Team Member
            </button>
          )}
        </div>
      </div>

      {/* 2. Summary KPI Metrics Panel */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
        {/* Total Staff */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex items-center space-x-3">
          <div className="p-2.5 bg-slate-100 rounded-xl text-slate-700">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Staff</span>
            <strong className="text-lg font-black text-slate-900 leading-tight">{globalKpis.totalStaff}</strong>
          </div>
        </div>

        {/* Active Staff */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex items-center space-x-3">
          <div className="p-2.5 bg-emerald-50 rounded-xl text-emerald-600">
            <UserCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Active Staff</span>
            <strong className="text-lg font-black text-slate-900 leading-tight">{globalKpis.activeStaff}</strong>
          </div>
        </div>

        {/* Total Assigned Tasks */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex items-center space-x-3">
          <div className="p-2.5 bg-blue-50 rounded-xl text-blue-600">
            <Briefcase className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Assigned Tasks</span>
            <strong className="text-lg font-black text-slate-900 leading-tight">{globalKpis.totalAssignedTasks}</strong>
          </div>
        </div>

        {/* Due Today */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex items-center space-x-3">
          <div className="p-2.5 bg-amber-50 rounded-xl text-amber-600">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Due Today</span>
            <strong className="text-lg font-black text-slate-900 leading-tight">{globalKpis.dueToday}</strong>
          </div>
        </div>

        {/* Overdue Tasks */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex items-center space-x-3">
          <div className="p-2.5 bg-rose-50 rounded-xl text-rose-600">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Overdue</span>
            <strong className="text-lg font-black text-[#F5405E] leading-tight">{globalKpis.overdue}</strong>
          </div>
        </div>

        {/* Unassigned Tasks */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex items-center space-x-3">
          <div className="p-2.5 bg-violet-50 rounded-xl text-violet-600">
            <UserX className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Unassigned</span>
            <strong className="text-lg font-black text-violet-700 leading-tight">{globalKpis.unassigned}</strong>
          </div>
        </div>
      </div>

      {/* 3. Search and Deep Filters console */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex items-center space-x-2 text-xs font-bold text-slate-800 border-b border-slate-100 pb-2">
          <Sliders className="w-4 h-4 text-[#F5405E]" />
          <span>Search & Workload Filters Console</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {/* Search name/email */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Search Member</label>
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search name or email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8.5 pr-3 py-1.5 text-xs font-semibold border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-rose-500 focus:border-rose-500"
              />
            </div>
          </div>

          {/* Role filter */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Security Role</label>
            <select
              value={filterRole}
              onChange={(e) => setFilterRole(e.target.value)}
              className="w-full p-1.5 text-xs font-bold border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none"
            >
              <option value="All">All Roles</option>
              <option value="Admin">Admin</option>
              <option value="Manager">Manager</option>
              <option value="Staff">Staff</option>
            </select>
          </div>

          {/* Active status filter */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Status</label>
            <select
              value={filterActive}
              onChange={(e) => setFilterActive(e.target.value)}
              className="w-full p-1.5 text-xs font-bold border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none"
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active Only</option>
              <option value="Inactive">Inactive Only</option>
            </select>
          </div>

          {/* Workload Level filter */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Workload Level</label>
            <select
              value={filterWorkload}
              onChange={(e) => setFilterWorkload(e.target.value)}
              className="w-full p-1.5 text-xs font-bold border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none"
            >
              <option value="All">All Workloads</option>
              <option value="Low">Low Workload</option>
              <option value="Normal">Normal Workload</option>
              <option value="High">High Workload</option>
              <option value="Overloaded">Overloaded</option>
            </select>
          </div>

          {/* Assigned Category filter */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Filing Specialty</label>
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="w-full p-1.5 text-xs font-bold border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none"
            >
              <option value="All">All Categories</option>
              {availableCategories.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          {/* Overdue Checkbox Toggle */}
          <div className="flex items-center pt-5">
            <label className="flex items-start gap-2.5 cursor-pointer text-xs font-bold text-slate-600 select-none whitespace-normal break-words">
              <input
                type="checkbox"
                checked={filterOverdueOnly}
                onChange={(e) => setFilterOverdueOnly(e.target.checked)}
                className="rounded border-slate-300 text-[#F5405E] focus:ring-[#F5405E] h-4 w-4 shrink-0 mt-0.5"
              />
              <span className="flex items-center text-rose-600 font-bold gap-1 whitespace-normal break-words">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                Overdue Tasks Only
              </span>
            </label>
          </div>
        </div>

        {/* Sorting controls and pagination sizing */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Sort by:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="border-none bg-transparent p-0 text-slate-800 font-black focus:outline-none focus:ring-0 cursor-pointer"
              >
                <option value="name">Staff Name</option>
                <option value="overdue">Highest Overdue</option>
                <option value="assigned">Highest Assigned Tasks</option>
                <option value="completion">Lowest Task Completion Rate</option>
              </select>
            </div>
          </div>

          <div className="text-[11px] text-slate-400 font-bold">
            Showing <strong className="text-slate-700">{filteredStaff.length === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1}</strong> to{' '}
            <strong className="text-slate-700">
              {Math.min(currentPage * itemsPerPage, filteredStaff.length)}
            </strong>{' '}
            of <strong className="text-slate-700">{filteredStaff.length}</strong> filtered team members
          </div>
        </div>
      </div>

      {/* Empty State */}
      {filteredStaff.length === 0 && (
        <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center shadow-xs">
          <UserX className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-black text-slate-800 text-sm">No Team Members Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
            We couldn't find any team members matching your search query, role filters, or workload levels. Clear filters to see your staff.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setFilterRole('All');
              setFilterActive('All');
              setFilterWorkload('All');
              setFilterCategory('All');
              setFilterOverdueOnly(false);
            }}
            className="mt-4 px-4 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
          >
            Reset All Filters
          </button>
        </div>
      )}

      {/* 4. Staff Grid Cards */}
      {filteredStaff.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {paginatedStaff.map((st) => {
            const metrics = computeStaffMetrics(st.id);
            const isSelf = st.id === currentUser?.id;
            const assignedClientsCount = clients.filter(c => !c.isDeleted && c.assignedStaffId === st.id).length;

            return (
              <div 
                key={st.id} 
                className={`bg-white border rounded-2xl p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between relative ${
                  !st.active ? 'opacity-70 border-slate-200 bg-slate-50/50' : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Active/Inactive Ribbon Header */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-extrabold text-slate-900 text-sm tracking-tight flex items-center">
                        {st.name}
                        {isSelf && (
                          <span className="ml-1.5 bg-rose-50 text-[#F5405E] px-1 py-0.5 rounded text-[8px] font-black uppercase">
                            You
                          </span>
                        )}
                      </h3>
                      <span className={`inline-block w-2 h-2 rounded-full ${st.active ? 'bg-emerald-500' : 'bg-slate-300'}`} />
                    </div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase tracking-wider ${
                        st.role === 'Admin'
                          ? 'bg-rose-50 text-[#F5405E] border border-rose-100'
                          : st.role === 'Manager'
                          ? 'bg-violet-50 text-violet-700 border border-violet-100'
                          : 'bg-blue-50 text-blue-700 border border-blue-100'
                      }`}>
                        {st.role}
                      </span>
                      <span className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase tracking-wider ${
                        st.active
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                          : 'bg-slate-100 text-slate-500 border border-slate-200'
                      }`}>
                        {st.active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </div>

                  {/* Workload Capacity Badge */}
                  <div className="text-right">
                    <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">Workload Capacity</span>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${
                      metrics.workload === 'Overloaded'
                        ? 'bg-rose-50 text-rose-700 border-rose-200 animate-pulse'
                        : metrics.workload === 'High'
                        ? 'bg-amber-50 text-amber-700 border-amber-200'
                        : metrics.workload === 'Normal'
                        ? 'bg-sky-50 text-sky-700 border-sky-200'
                        : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    }`}>
                      {metrics.workload}
                    </span>
                  </div>
                </div>

                {/* Info and stats parameters */}
                <div className="space-y-3.5 pt-3 border-t border-slate-100">
                  {/* Contacts */}
                  <div className="text-[11px] text-slate-500 space-y-1 font-semibold">
                    {st.email && (
                      <div className="flex items-center gap-1.5 truncate">
                        <span className="text-slate-400">Email:</span>
                        <span className="text-slate-700 font-mono truncate">{st.email}</span>
                      </div>
                    )}
                    {st.phone && (
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-400">Phone:</span>
                        <span className="text-slate-700 font-mono">{st.phone}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mt-1">
                      <span>Last active:</span>
                      <strong className="text-slate-500">{metrics.lastActive}</strong>
                    </div>
                  </div>

                  {/* Complete 3-grid metric cards */}
                  <div className="grid grid-cols-4 gap-2 text-center pt-1">
                    <div className="bg-slate-50/70 p-2 rounded-xl border border-slate-100">
                      <span className="block text-[8px] font-bold text-slate-400 uppercase">Assigned</span>
                      <strong className="text-sm font-black text-slate-800">{metrics.total}</strong>
                    </div>
                    <div className="bg-emerald-50/50 p-2 rounded-xl border border-emerald-100/50">
                      <span className="block text-[8px] font-bold text-emerald-500 uppercase">Filed</span>
                      <strong className="text-sm font-black text-emerald-600">{metrics.completed}</strong>
                    </div>
                    <div className={`p-2 rounded-xl border ${metrics.dueToday > 0 ? 'bg-amber-50 border-amber-200 text-amber-700' : 'bg-slate-50/70 border-slate-100 text-slate-800'}`}>
                      <span className="block text-[8px] font-bold text-slate-400 uppercase">Due Today</span>
                      <strong className="text-sm font-black">{metrics.dueToday}</strong>
                    </div>
                    <div className={`p-2 rounded-xl border ${metrics.overdue > 0 ? 'bg-rose-50 border-rose-200 text-rose-700 animate-pulse-subtle' : 'bg-slate-50/70 border-slate-100 text-slate-800'}`}>
                      <span className="block text-[8px] font-bold text-slate-400 uppercase">Overdue</span>
                      <strong className="text-sm font-black">{metrics.overdue}</strong>
                    </div>
                  </div>

                  {/* Secondary checklist metrics alerts */}
                  <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-500 font-bold">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                      <span>7d Upcoming: <strong className="text-slate-700">{metrics.upcoming7Days}</strong></span>
                    </div>
                    <div className="flex items-center gap-1">
                      <FileText className="w-3.5 h-3.5 text-orange-500 shrink-0" />
                      <span>Docs Pending: <strong className="text-slate-700">{metrics.docsPending}</strong></span>
                    </div>
                    <div className="flex items-center gap-1">
                      <CreditCard className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Fees Follow: <strong className="text-slate-700">{metrics.paymentPending}</strong></span>
                    </div>
                  </div>

                  {/* Task completion percentage representation (Item 12 check) */}
                  <div className="pt-2.5 border-t border-slate-100 space-y-1">
                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-bold">
                      <span>Filing Progress Rate:</span>
                      {metrics.total > 0 ? (
                        <span className="text-[#F5405E]">{metrics.rate}%</span>
                      ) : (
                        <span className="text-slate-400 italic text-[10px] bg-slate-50 px-1.5 py-0.5 rounded border border-slate-100">No tasks assigned</span>
                      )}
                    </div>
                    {metrics.total > 0 ? (
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-500 h-full rounded-full transition-all"
                          style={{ width: `${metrics.rate}%` }}
                        ></div>
                      </div>
                    ) : (
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden opacity-50">
                        <div className="bg-slate-300 h-full w-0 rounded-full"></div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Action buttons (Item 5) */}
                <div className="mt-5 pt-3.5 border-t border-slate-100 space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => {
                        setViewTasksStaff(st);
                        setIsViewTasksOpen(true);
                      }}
                      className="inline-flex items-center justify-center p-2 text-xs font-bold text-slate-700 hover:text-[#F5405E] bg-slate-100 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer gap-1 border border-transparent hover:border-rose-100"
                      title="View Tasks"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      View Tasks
                    </button>

                    {st.active && (currentUser?.role === 'Admin' || currentUser?.role === 'Manager') ? (
                      <button
                        onClick={() => {
                          setAssignFormStaff(st);
                          setIsAssignOpen(true);
                        }}
                        className="inline-flex items-center justify-center p-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer gap-1"
                        title="Assign Task"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Assign Task
                      </button>
                    ) : (
                      <button
                        disabled
                        className="inline-flex items-center justify-center p-2 text-xs font-bold text-slate-300 bg-slate-50 border border-slate-100 rounded-lg cursor-not-allowed gap-1"
                        title="Assign Task"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Assign Task
                      </button>
                    )}
                  </div>

                  <div className="flex items-center justify-between gap-1 text-[11px] pt-1.5">
                    {/* Edit Profile */}
                    {(currentUser?.role === 'Admin' || currentUser?.role === 'Manager' || isSelf) ? (
                      <button
                        onClick={() => {
                          setSelectedStaff(st);
                          setEditFormName(st.name);
                          setEditFormRole(st.role);
                          setEditFormEmail(st.email);
                          setEditFormPhone(st.phone || '');
                          setIsEditOpen(true);
                        }}
                        className="inline-flex items-center text-slate-500 hover:text-slate-800 font-bold transition-colors cursor-pointer gap-1 p-1 hover:bg-slate-50 rounded"
                        title="Edit Profile"
                      >
                        <Edit className="w-3 h-3 text-slate-400" />
                        Edit Profile
                      </button>
                    ) : (
                      <span 
                        className="text-slate-300 cursor-not-allowed inline-flex items-center gap-1 p-1"
                        title="Edit Profile"
                      >
                        <Edit className="w-3 h-3 text-slate-200" />
                        Edit Profile
                      </span>
                    )}

                    {/* Soft Activate/Deactivate */}
                    {(currentUser?.role === 'Admin' || currentUser?.role === 'Manager') && !isSelf ? (
                      <button
                        onClick={() => handleToggleActive(st)}
                        className={`inline-flex items-center font-bold gap-1 p-1 hover:bg-slate-50 rounded cursor-pointer ${
                          st.active ? 'text-amber-600 hover:text-amber-800' : 'text-emerald-600 hover:text-emerald-800'
                        }`}
                        title={st.active ? "Deactivate Staff" : "Activate Staff"}
                      >
                        {st.active ? <UserMinus className="w-3 h-3" /> : <UserCheck className="w-3 h-3" />}
                        {st.active ? 'Deactivate' : 'Activate'}
                      </button>
                    ) : (
                      <span 
                        className="text-slate-300 cursor-not-allowed inline-flex items-center gap-1 p-1"
                        title="Activate/Deactivate"
                      >
                        <Power className="w-3 h-3 text-slate-200" />
                        {st.active ? 'Deactivate' : 'Activate'}
                      </span>
                    )}

                    {/* Admin Permanent Delete Option */}
                    {currentUser?.role === 'Admin' && !isSelf && (
                      (() => {
                        const { totalDeps } = getStaffDependenciesCount(st.id, st.name);
                        const isAllowed = totalDeps === 0;
                        return (
                          <button
                            onClick={() => isAllowed && handlePermanentDelete(st)}
                            disabled={!isAllowed}
                            className={`inline-flex items-center font-bold transition-colors gap-1 p-1 rounded ${
                              isAllowed 
                                ? 'text-rose-500 hover:text-rose-700 hover:bg-rose-50 cursor-pointer' 
                                : 'text-slate-300 cursor-not-allowed opacity-50'
                            }`}
                            title={isAllowed ? "Permanently Delete Profile" : "Profile cannot be deleted because related records exist. Deactivate the profile instead."}
                          >
                            <Trash2 className={`w-3 h-3 ${isAllowed ? 'text-rose-400' : 'text-slate-300'}`} />
                            Delete
                          </button>
                        );
                      })()
                    )}
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* 5. Detailed Workload Table below the Cards (Item 9) */}
      {filteredStaff.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center space-x-2">
              <Layers className="w-4.5 h-4.5 text-[#F5405E]" />
              <h2 className="text-sm font-black text-slate-800 tracking-tight">Staff Workload Matrix Ledger</h2>
            </div>
            <span className="text-[10px] uppercase font-bold text-[#F5405E] bg-rose-50 px-2.5 py-1 rounded-full">
              Filing Period: 2026 Season
            </span>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-100">
            <table className="min-w-full divide-y divide-slate-150 text-left text-xs">
              <thead className="bg-slate-50 font-black text-slate-400 uppercase text-[9px] tracking-wider">
                <tr>
                  <th className="px-4 py-3">Staff Name</th>
                  <th className="px-4 py-3">Role</th>
                  <th className="px-4 py-3 text-center">Assigned</th>
                  <th className="px-4 py-3 text-center">Due Today</th>
                  <th className="px-4 py-3 text-center">Upcoming</th>
                  <th className="px-4 py-3 text-center">Overdue</th>
                  <th className="px-4 py-3 text-center">Completed</th>
                  <th className="px-4 py-3 text-center">Completion Rate</th>
                  <th className="px-4 py-3 text-center">Workload Status</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-semibold text-slate-700 bg-white">
                {paginatedStaff.map((st) => {
                  const metrics = computeStaffMetrics(st.id);
                  const isSelf = st.id === currentUser?.id;
                  const assignedClientsCount = clients.filter(c => !c.isDeleted && c.assignedStaffId === st.id).length;

                  return (
                    <tr 
                      key={st.id} 
                      className={`hover:bg-slate-50/50 transition-colors ${
                        !st.active ? 'opacity-60 bg-slate-50/30' : ''
                      }`}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-2">
                          <span className={`w-2 h-2 rounded-full ${st.active ? 'bg-emerald-500' : 'bg-slate-300'}`}></span>
                          <div>
                            <span className="font-extrabold text-slate-900 block truncate max-w-[150px]">
                              {st.name}
                            </span>
                            <span className="block text-[9px] text-slate-400 font-mono font-medium truncate max-w-[150px]">
                              {st.email || 'No email created'}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-block px-1.5 py-0.5 rounded text-[8px] font-extrabold uppercase tracking-wider ${
                          st.role === 'Admin'
                            ? 'bg-rose-50 text-[#F5405E]'
                            : st.role === 'Manager'
                            ? 'bg-violet-50 text-violet-700'
                            : 'bg-blue-50 text-blue-700'
                        }`}>
                          {st.role}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center font-bold text-slate-800">{metrics.total}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={metrics.dueToday > 0 ? 'text-amber-600 font-extrabold' : 'text-slate-400'}>
                          {metrics.dueToday}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center text-slate-500">{metrics.upcoming7Days}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={metrics.overdue > 0 ? 'text-[#F5405E] font-black' : 'text-slate-400'}>
                          {metrics.overdue}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center text-emerald-600 font-bold">{metrics.completed}</td>
                      <td className="px-4 py-3 text-center">
                        {metrics.total > 0 ? (
                          <div className="inline-flex items-center gap-1.5">
                            <span className="font-black text-slate-800">{metrics.rate}%</span>
                            <div className="w-10 bg-slate-100 h-1.5 rounded-full overflow-hidden hidden sm:block">
                              <div className="bg-emerald-500 h-full" style={{ width: `${metrics.rate}%` }}></div>
                            </div>
                          </div>
                        ) : (
                          <span className="text-slate-400 italic text-[10px]">No tasks assigned</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-extrabold uppercase border ${
                          metrics.workload === 'Overloaded'
                            ? 'bg-rose-50 text-rose-700 border-rose-150'
                            : metrics.workload === 'High'
                            ? 'bg-amber-50 text-amber-700 border-amber-150'
                            : metrics.workload === 'Normal'
                            ? 'bg-sky-50 text-sky-700 border-sky-150'
                            : 'bg-emerald-50 text-emerald-700 border-emerald-150'
                        }`}>
                          {metrics.workload}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1 text-[11px]">
                          {/* View tasks */}
                          <button
                            onClick={() => {
                              setViewTasksStaff(st);
                              setIsViewTasksOpen(true);
                            }}
                            className="p-1 text-slate-500 hover:text-rose-600 hover:bg-slate-100 rounded cursor-pointer"
                            title="View Tasks"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {/* Assign task if active */}
                          {st.active && (currentUser?.role === 'Admin' || currentUser?.role === 'Manager') ? (
                            <button
                              onClick={() => {
                                setAssignFormStaff(st);
                                setIsAssignOpen(true);
                              }}
                              className="p-1 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded cursor-pointer"
                              title="Assign Task"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          ) : null}

                          {/* Edit profile */}
                          {(currentUser?.role === 'Admin' || currentUser?.role === 'Manager' || isSelf) ? (
                            <button
                              onClick={() => {
                                setSelectedStaff(st);
                                setEditFormName(st.name);
                                setEditFormRole(st.role);
                                setEditFormEmail(st.email);
                                setEditFormPhone(st.phone || '');
                                setIsEditOpen(true);
                              }}
                              className="p-1 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded cursor-pointer"
                              title="Edit Profile"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                          ) : null}

                          {/* Toggle active */}
                          {(currentUser?.role === 'Admin' || currentUser?.role === 'Manager') && !isSelf ? (
                            <button
                              onClick={() => handleToggleActive(st)}
                              className={`p-1 rounded cursor-pointer ${
                                st.active ? 'text-amber-500 hover:bg-amber-50' : 'text-emerald-500 hover:bg-emerald-50'
                              }`}
                              title={st.active ? 'Deactivate Staff' : 'Activate Staff'}
                            >
                              <Power className="w-3.5 h-3.5" />
                            </button>
                          ) : null}

                          {/* Delete */}
                          {currentUser?.role === 'Admin' && !isSelf && (
                            (() => {
                              const { totalDeps } = getStaffDependenciesCount(st.id, st.name);
                              const isAllowed = totalDeps === 0;
                              return (
                                <button
                                  onClick={() => isAllowed && handlePermanentDelete(st)}
                                  disabled={!isAllowed}
                                  className={`p-1 rounded ${
                                    isAllowed 
                                      ? 'text-rose-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer' 
                                      : 'text-slate-300 cursor-not-allowed opacity-40'
                                  }`}
                                  title={isAllowed ? "Permanently Delete Profile" : "Profile cannot be deleted because related records exist. Deactivate the profile instead."}
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              );
                            })()
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between bg-white border border-slate-200 rounded-2xl px-5 py-4 shadow-2xs text-xs font-bold text-slate-500">
          <button
            onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
            disabled={currentPage === 1}
            className={`inline-flex items-center px-3 py-1.5 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-50 gap-1.5 ${
              currentPage === 1 ? 'opacity-40 cursor-not-allowed hover:bg-white' : ''
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            Previous
          </button>

          <div className="flex items-center space-x-1">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                className={`w-8 h-8 rounded-lg flex items-center justify-center cursor-pointer transition-all ${
                  currentPage === page 
                    ? 'bg-[#F5405E] text-white' 
                    : 'hover:bg-slate-100 text-slate-600'
                }`}
              >
                {page}
              </button>
            ))}
          </div>

          <button
            onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
            disabled={currentPage === totalPages}
            className={`inline-flex items-center px-3 py-1.5 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-50 gap-1.5 ${
              currentPage === totalPages ? 'opacity-40 cursor-not-allowed hover:bg-white' : ''
            }`}
          >
            Next
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* MODAL: REGISTER TEAM PARTNER */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-sm w-full p-6 space-y-4 animate-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-extrabold text-slate-900 text-sm">Create Team Partner</h3>
              <button onClick={() => setIsCreateOpen(false)} className="text-slate-400 hover:text-slate-600 font-bold text-xs cursor-pointer">✕</button>
            </div>

            <form onSubmit={handleCreateStaffSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Patel"
                  value={createFormName}
                  onChange={(e) => setCreateFormName(e.target.value)}
                  className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 font-bold focus:bg-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Taxcom Technologies Security Role *</label>
                <select
                  value={createFormRole}
                  onChange={(e) => setCreateFormRole(e.target.value as any)}
                  className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 font-bold focus:bg-white"
                >
                  <option value="Staff">Staff (View own clients only)</option>
                  <option value="Manager">Manager (Read all, cannot modify billing)</option>
                  <option value="Admin">Admin (Full read/write permissions)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Email Address</label>
                <input
                  type="email"
                  placeholder="e.g. ramesh@taxcom.co.in"
                  value={createFormEmail}
                  onChange={(e) => setCreateFormEmail(e.target.value)}
                  className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Phone Number</label>
                <input
                  type="tel"
                  placeholder="e.g. +919876543210"
                  value={createFormPhone}
                  onChange={(e) => setCreateFormPhone(e.target.value)}
                  className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-none"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-3.5 py-1.5 text-xs text-slate-500 hover:text-slate-700 cursor-pointer font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 text-xs font-black text-white bg-[#F5405E] hover:bg-rose-600 rounded-lg shadow-xs cursor-pointer"
                >
                  Add Partner
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EDIT STAFF PROFILE */}
      {isEditOpen && selectedStaff && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-sm w-full p-6 space-y-4 animate-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-extrabold text-slate-900 text-sm">Edit Staff Profile</h3>
              <button onClick={() => { setIsEditOpen(false); setSelectedStaff(null); }} className="text-slate-400 hover:text-slate-600 font-bold text-xs cursor-pointer">✕</button>
            </div>

            <form onSubmit={handleEditStaffSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="Full Name"
                  value={editFormName}
                  onChange={(e) => setEditFormName(e.target.value)}
                  className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 font-bold focus:bg-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Taxcom Technologies Security Role *</label>
                <select
                  value={editFormRole}
                  onChange={(e) => setEditFormRole(e.target.value as any)}
                  disabled={selectedStaff.id === currentUser?.id}
                  className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 font-bold focus:bg-white disabled:opacity-50"
                >
                  <option value="Staff">Staff (View own clients only)</option>
                  <option value="Manager">Manager (Read all, cannot modify billing)</option>
                  <option value="Admin">Admin (Full read/write permissions)</option>
                </select>
                {selectedStaff.id === currentUser?.id && (
                  <span className="text-[9px] text-amber-600 block mt-1 font-bold">
                    Role transitions are restricted on your own active session.
                  </span>
                )}
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Email Address</label>
                <input
                  type="email"
                  placeholder="Email"
                  value={editFormEmail}
                  onChange={(e) => setEditFormEmail(e.target.value)}
                  className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Phone Number</label>
                <input
                  type="tel"
                  placeholder="Phone Number"
                  value={editFormPhone}
                  onChange={(e) => setEditFormPhone(e.target.value)}
                  className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-none"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => { setIsEditOpen(false); setSelectedStaff(null); }}
                  className="px-3.5 py-1.5 text-xs text-slate-500 hover:text-slate-700 cursor-pointer font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-1.5 text-xs font-black text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: VIEW TASKS DETAILED LIST */}
      {isViewTasksOpen && viewTasksStaff && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-2xl w-full p-6 space-y-4 animate-in zoom-in-95 duration-150 flex flex-col max-h-[85vh]">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 shrink-0">
              <div>
                <h3 className="font-extrabold text-slate-900 text-sm">Assigned Tasks: {viewTasksStaff.name}</h3>
                <span className="text-[10px] text-slate-400 font-bold block">{viewTasksStaff.role} Partner backlogs</span>
              </div>
              <button 
                onClick={() => { setIsViewTasksOpen(false); setViewTasksStaff(null); setViewTasksSearch(''); }} 
                className="text-slate-400 hover:text-slate-600 font-bold text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Quick search within tasks */}
            <div className="shrink-0">
              <div className="relative">
                <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search tasks by client name or filing category..."
                  value={viewTasksSearch}
                  onChange={(e) => setViewTasksSearch(e.target.value)}
                  className="w-full pl-8.5 pr-3 py-1.5 text-xs font-semibold border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:outline-none"
                />
              </div>
            </div>

            {/* Tasks list */}
            <div className="flex-1 overflow-y-auto min-h-[200px] border border-slate-100 rounded-xl p-2 bg-slate-50/50">
              {(() => {
                const staffTasks = tasks.filter(t => !t.isDeleted && t.assignedStaffId === viewTasksStaff.id && (
                  viewTasksSearch === '' ||
                  t.clientName.toLowerCase().includes(viewTasksSearch.toLowerCase()) ||
                  t.serviceCategory.toLowerCase().includes(viewTasksSearch.toLowerCase()) ||
                  t.returnName.toLowerCase().includes(viewTasksSearch.toLowerCase())
                ));

                if (staffTasks.length === 0) {
                  return (
                    <div className="text-center py-12 text-xs text-slate-400 font-semibold">
                      <Briefcase className="w-8 h-8 text-slate-350 mx-auto mb-2 opacity-60" />
                      No active tasks found matching criteria.
                    </div>
                  );
                }

                return (
                  <div className="space-y-2">
                    {staffTasks.map((t) => (
                      <div key={t.id} className="bg-white border border-slate-200 rounded-xl p-3 shadow-3xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-slate-900 text-xs">{t.clientName}</span>
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider bg-slate-100 text-slate-600">
                              {t.serviceCategory}
                            </span>
                          </div>
                          <div className="text-[10px] text-slate-500 font-semibold mt-0.5 space-x-2">
                            <span>Form: <strong className="text-slate-700">{t.returnName}</strong></span>
                            <span>Period: <strong className="text-slate-700">{t.filingPeriod}</strong></span>
                            <span>Due Date: <strong className={t.dueDate < '2026-07-17' ? 'text-rose-600 font-bold' : 'text-slate-700'}>{t.dueDate}</strong></span>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 justify-between sm:justify-end">
                          <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${
                            t.status === 'Completed' || t.status === 'Filed'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                              : t.status === 'Ready to File'
                              ? 'bg-blue-50 text-blue-700 border border-blue-100'
                              : 'bg-amber-50 text-amber-700 border border-amber-100 animate-pulse-subtle'
                          }`}>
                            {t.status}
                          </span>

                          <div className="text-right text-[10px] font-bold text-slate-500">
                            <div>Fees: ₹{t.professionalFees}</div>
                            {t.outstandingAmount > 0 ? (
                              <div className="text-rose-600">O/S: ₹{t.outstandingAmount}</div>
                            ) : (
                              <div className="text-emerald-600">Paid</div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                );
              })()}
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-slate-100 shrink-0">
              <button
                onClick={() => {
                  setIsViewTasksOpen(false);
                  setViewTasksStaff(null);
                  setViewTasksSearch('');
                  navigate('/tasks');
                }}
                className="text-xs text-[#F5405E] hover:underline font-bold"
              >
                Go to Tasks Console →
              </button>
              
              <button
                type="button"
                onClick={() => { setIsViewTasksOpen(false); setViewTasksStaff(null); setViewTasksSearch(''); }}
                className="px-5 py-2 text-xs font-black text-white bg-slate-900 hover:bg-slate-800 rounded-xl cursor-pointer shadow-xs"
              >
                Close View
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ASSIGN TASK FORM */}
      {isAssignOpen && assignFormStaff && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-lg w-full p-6 space-y-4 animate-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 shrink-0">
              <div>
                <h3 className="font-extrabold text-slate-900 text-sm">Assign Task: {assignFormStaff.name}</h3>
                <span className="text-[10px] text-slate-400 font-bold block">Create compliance record assigned directly to {assignFormStaff.name}</span>
              </div>
              <button onClick={() => { setIsAssignOpen(false); setAssignFormStaff(null); }} className="text-slate-400 hover:text-slate-600 font-bold text-xs cursor-pointer">✕</button>
            </div>

            <form onSubmit={handleAssignTaskSubmit} className="flex-1 overflow-y-auto space-y-4 text-xs pr-1">
              
              {/* Select Client dropdown */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Target Client *</label>
                <select
                  required
                  value={assignFormClient}
                  onChange={(e) => setAssignFormClient(e.target.value)}
                  className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 font-bold focus:bg-white"
                >
                  <option value="">-- Choose Client Partner --</option>
                  {clients.filter(c => !c.isDeleted && c.status === 'Active').map((cl) => (
                    <option key={cl.id} value={cl.id}>{cl.name} ({cl.tradeName || 'No trade name'})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 xs:grid-cols-2 gap-4">
                {/* Category */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Service Category *</label>
                  <select
                    value={assignFormCategory}
                    onChange={(e) => {
                      const cat = e.target.value as ServiceCategory;
                      setAssignFormCategory(cat);
                      // Auto-suggestion for return names based on category
                      if (cat === 'GST') setAssignFormReturnName('GSTR-3B');
                      else if (cat === 'Income Tax') setAssignFormReturnName('ITR-1');
                      else if (cat === 'TDS') setAssignFormReturnName('Form 24Q');
                      else if (cat === 'FSSAI') setAssignFormReturnName('FSSAI Renewal');
                    }}
                    className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 font-bold focus:bg-white"
                  >
                    <option value="GST">GST</option>
                    <option value="Income Tax">Income Tax</option>
                    <option value="TDS">TDS</option>
                    <option value="MCA or ROC">MCA or ROC</option>
                    <option value="LLP Compliance">LLP Compliance</option>
                    <option value="FSSAI">FSSAI</option>
                    <option value="PF">PF</option>
                    <option value="ESI">ESI</option>
                    <option value="Professional Tax">Professional Tax</option>
                    <option value="Trade Licence">Trade Licence</option>
                    <option value="DSC Renewal">DSC Renewal</option>
                    <option value="Custom Service">Custom Service</option>
                  </select>
                </div>

                {/* Return Name */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Filing Return Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. GSTR-3B"
                    value={assignFormReturnName}
                    onChange={(e) => setAssignFormReturnName(e.target.value)}
                    className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 font-bold focus:bg-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 xs:grid-cols-3 gap-4">
                {/* FY */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Financial Year *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 2026-27"
                    value={assignFormFY}
                    onChange={(e) => setAssignFormFY(e.target.value)}
                    className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-none"
                  />
                </div>

                {/* AY */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Assessment Year *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 2027-28"
                    value={assignFormAY}
                    onChange={(e) => setAssignFormAY(e.target.value)}
                    className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-none"
                  />
                </div>

                {/* Filing Period */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Filing Period *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. June 2026"
                    value={assignFormPeriod}
                    onChange={(e) => setAssignFormPeriod(e.target.value)}
                    className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 xs:grid-cols-2 gap-4">
                {/* Due Date */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Due Date *</label>
                  <input
                    type="date"
                    required
                    value={assignFormDueDate}
                    onChange={(e) => setAssignFormDueDate(e.target.value)}
                    className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 font-bold focus:bg-white focus:outline-none"
                  />
                </div>

                {/* Priority */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Priority Level *</label>
                  <select
                    value={assignFormPriority}
                    onChange={(e) => setAssignFormPriority(e.target.value as any)}
                    className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 font-bold focus:bg-white"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Urgent">Urgent ⚡</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 xs:grid-cols-2 gap-4">
                {/* Fees */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Professional Fees (INR) *</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={assignFormFees}
                    onChange={(e) => setAssignFormFees(Number(e.target.value))}
                    className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 font-bold focus:bg-white focus:outline-none"
                  />
                </div>

                {/* Recurrence */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Filing Recurrence *</label>
                  <select
                    value={assignFormRecurrence}
                    onChange={(e) => setAssignFormRecurrence(e.target.value as any)}
                    className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 font-bold focus:bg-white"
                  >
                    <option value="Monthly">Monthly</option>
                    <option value="Quarterly">Quarterly</option>
                    <option value="Half-Yearly">Half-Yearly</option>
                    <option value="Annual">Annual</option>
                    <option value="One-Time">One-Time</option>
                  </select>
                </div>
              </div>

              {/* Documents Required */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Required Client Documents</label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  {['Bank Statement', 'Sales Invoice', 'Purchase Sheets', 'Challan Receipt', 'PAN/GST Cards'].map((docName) => {
                    const isChecked = assignFormDocs.includes(docName);
                    return (
                      <label key={docName} className="flex items-start gap-2 text-slate-600 font-bold cursor-pointer whitespace-normal break-words text-xs">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {
                            if (isChecked) {
                              setAssignFormDocs(assignFormDocs.filter(d => d !== docName));
                            } else {
                              setAssignFormDocs([...assignFormDocs, docName]);
                            }
                          }}
                          className="rounded border-slate-300 text-[#F5405E] focus:ring-[#F5405E] h-3.5 w-3.5 shrink-0 mt-0.5"
                        />
                        <span className="leading-tight">{docName}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Internal notes */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Internal Scope Instructions</label>
                <textarea
                  placeholder="e.g. Audit sales figures against bank credits..."
                  value={assignFormNotes}
                  onChange={(e) => setAssignFormNotes(e.target.value)}
                  className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 focus:bg-white focus:outline-none h-16 font-semibold"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100 shrink-0">
                <button
                  type="button"
                  onClick={() => { setIsAssignOpen(false); setAssignFormStaff(null); }}
                  className="px-4 py-2 text-xs text-slate-500 hover:text-slate-700 cursor-pointer font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-black text-white bg-[#F5405E] hover:bg-rose-600 rounded-lg shadow-sm cursor-pointer"
                >
                  Assign Compliance Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* MODAL: PERMANENTLY DELETE PROFILE CONFIRMATION */}
      {isDeleteModalOpen && staffToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" id="delete-confirmation-modal">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-sm w-full p-6 space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-extrabold text-slate-900 text-sm">Permanently delete {staffToDelete.name}?</h3>
              <button 
                onClick={() => {
                  setIsDeleteModalOpen(false);
                  setStaffToDelete(null);
                  setDeleteConfirmText('');
                }} 
                className="text-slate-400 hover:text-slate-600 font-bold text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <p className="text-slate-600 font-medium leading-relaxed">
                This profile has no assigned records. This action will permanently remove the staff profile and cannot be undone.
              </p>

              <div className="space-y-1.5">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  To confirm, type <strong className="text-rose-600">DELETE</strong> below:
                </label>
                <input
                  type="text"
                  placeholder="Type DELETE to confirm"
                  value={deleteConfirmText}
                  onChange={(e) => setDeleteConfirmText(e.target.value)}
                  className="block w-full border border-slate-200 rounded-lg p-2.5 bg-slate-50 font-bold focus:bg-white focus:outline-none uppercase"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsDeleteModalOpen(false);
                    setStaffToDelete(null);
                    setDeleteConfirmText('');
                  }}
                  className="px-3.5 py-1.5 text-xs text-slate-500 hover:text-slate-700 cursor-pointer font-bold"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={deleteConfirmText !== 'DELETE' || isCheckingDependencies}
                  onClick={handleExecuteDelete}
                  className="px-5 py-1.5 text-xs font-black text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-xs cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                >
                  {isCheckingDependencies ? 'Checking...' : 'Permanently Delete'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
