import React, { useState } from 'react';
import {
  Plus,
  Search,
  Filter,
  FileSpreadsheet,
  Download,
  Trash2,
  Edit2,
  FileText,
  Clock,
  Briefcase,
  AlertCircle,
  HelpCircle,
  SlidersHorizontal,
  CheckCircle,
  TrendingUp,
  CreditCard,
  RefreshCcw,
  PlusCircle,
  CalendarDays,
  CheckSquare,
  Upload,
  Eye,
  FileDown,
  Paperclip,
  Loader2,
  X
} from 'lucide-react';
import {
  getTasks,
  getClients,
  getClientById,
  getStaff,
  createTask,
  updateTask,
  deleteTask,
  addAuditLog
} from '../db/storage';
import { ComplianceTask, Client, Staff, ServiceCategory, TaskStatus, RecurrenceType } from '../types';
import { useToast } from '../components/Toast';
import ImportWizard from '../components/ImportWizard';
import { useAuth } from '../components/AuthContext';
import * as XLSX from 'xlsx';

export default function Tasks() {
  const { showToast } = useToast();
  const { currentUser } = useAuth();
  const [tasks, setTasks] = useState<ComplianceTask[]>(() => getTasks());
  const clientsList = getClients();
  const staffList = getStaff();

  React.useEffect(() => {
    const handleSync = () => {
      setTasks(getTasks());
    };
    window.addEventListener('database-sync', handleSync);
    return () => window.removeEventListener('database-sync', handleSync);
  }, []);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [filterPriority, setFilterPriority] = useState<string>('All');
  const [filterStaff, setFilterStaff] = useState<string>('All');
  const [filterPayment, setFilterPayment] = useState<string>('All');
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);

  // Modals
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<ComplianceTask | null>(null);
  const [taskToDelete, setTaskToDelete] = useState<ComplianceTask | null>(null);
  const [paymentToDelete, setPaymentToDelete] = useState<any>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);

  // Form Field States
  const [formClientId, setFormClientId] = useState('');
  const [formCategory, setFormCategory] = useState<ServiceCategory>('GST');
  const [formReturnName, setFormReturnName] = useState('');
  const [formFY, setFormFY] = useState('2026-27');
  const [formPeriod, setFormPeriod] = useState('');
  const [formDueDate, setFormDueDate] = useState('');
  const [formPriority, setFormPriority] = useState<'Low' | 'Medium' | 'High' | 'Urgent'>('Medium');
  const [formStaffId, setFormStaffId] = useState('');
  const [formStatus, setFormStatus] = useState<TaskStatus>('Not Started');
  
  // Document tracker list
  const [formDocsRequired, setFormDocsRequired] = useState<string[]>([]);
  const [formDocsPending, setFormDocsPending] = useState<string[]>([]);
  const [customDocName, setCustomDocName] = useState('');

  const [formNotes, setFormNotes] = useState('');
  const [formFees, setFormFees] = useState<number>(3000);
  const [formReceived, setFormReceived] = useState<number>(0);
  const [formLastPaymentDate, setFormLastPaymentDate] = useState('');

  const [formFilingDate, setFormFilingDate] = useState('');
  const [formAck, setFormAck] = useState('');
  const [formCompletionDate, setFormCompletionDate] = useState('');
  const [formRecurrence, setFormRecurrence] = useState<RecurrenceType>('Monthly');

  // Enhanced state fields
  const [formPayments, setFormPayments] = useState<any[]>([]);
  const [formDocumentDetails, setFormDocumentDetails] = useState<Record<string, any>>({});
  const [formAcknowledgementPdf, setFormAcknowledgementPdf] = useState<string>('');
  const [formAcknowledgementPdfName, setFormAcknowledgementPdfName] = useState<string>('');
  const [formAcknowledgementDate, setFormAcknowledgementDate] = useState<string>('');
  const [formNotesHistory, setFormNotesHistory] = useState<any[]>([]);
  const [newNoteText, setNewNoteText] = useState<string>('');
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [previewFile, setPreviewFile] = useState<{ name: string; data: string } | null>(null);

  // For adding a new payment inline
  const [newPaymentDate, setNewPaymentDate] = useState('');
  const [newPaymentAmount, setNewPaymentAmount] = useState('');
  const [newPaymentMode, setNewPaymentMode] = useState('UPI');
  const [newPaymentTxId, setNewPaymentTxId] = useState('');
  const [newPaymentRemarks, setNewPaymentRemarks] = useState('');

  // Auto-populate completion date when task status becomes Completed
  React.useEffect(() => {
    if (formStatus === 'Completed' && !formCompletionDate) {
      const todayStr = new Date().toISOString().split('T')[0];
      setFormCompletionDate(todayStr);
    }
  }, [formStatus]);

  const handleDocFileChange = (docName: string, file: File | null) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setFormDocumentDetails(prev => ({
        ...prev,
        [docName]: {
          ...prev[docName],
          docName,
          fileName: file.name,
          fileData: dataUrl,
          receivedDate: prev[docName]?.receivedDate || new Date().toISOString().split('T')[0],
          receivedBy: prev[docName]?.receivedBy || currentUser?.name || 'Staff'
        }
      }));
      // Automatically mark as not pending if document is uploaded
      setFormDocsPending(prev => prev.filter(d => d !== docName));
      showToast(`Document "${docName}" attached successfully!`, 'success');
    };
    reader.readAsDataURL(file);
  };

  const handleAckPdfChange = (file: File | null) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setFormAcknowledgementPdf(dataUrl);
      setFormAcknowledgementPdfName(file.name);
      showToast('Government Acknowledgement PDF uploaded!', 'success');
    };
    reader.readAsDataURL(file);
  };

  const handleDownloadAckPdf = () => {
    if (formAcknowledgementPdf && formAcknowledgementPdfName) {
      const link = document.createElement('a');
      link.href = formAcknowledgementPdf;
      link.download = formAcknowledgementPdfName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showToast('Downloading Acknowledgement PDF...', 'info');
    }
  };

  const refreshList = () => {
    setTasks(getTasks());
  };

  const serviceCategories: ServiceCategory[] = [
    'GST',
    'Income Tax',
    'TDS',
    'MCA or ROC',
    'LLP Compliance',
    'FSSAI',
    'PF',
    'ESI',
    'Professional Tax',
    'Trade Licence',
    'DSC Renewal',
    'Udyam',
    'IEC',
    'Trademark',
    'Custom Service',
  ];

  const taskStatuses: TaskStatus[] = [
    'Not Started',
    'Documents Pending',
    'Client Confirmation Pending',
    'In Progress',
    'Ready to File',
    'Filed',
    'Completed',
    'On Hold',
  ];

  const standardDocs = [
    'Sales Data',
    'Purchase Data',
    'Bank Statement',
    'TDS Details',
    'Challan',
    'OTP',
    'Digital Signature',
    'Signed Documents',
    'Previous Return',
    'Books of Accounts',
  ];

  const totalPaymentsAmount = formPayments.reduce((sum, p) => sum + p.amount, 0);
  const calculatedOutstanding = Math.max(0, formFees - totalPaymentsAmount);

  const handleOpenCreateModal = () => {
    setEditingTask(null);
    setFormClientId(clientsList[0]?.id || '');
    setFormCategory('GST');
    setFormReturnName('GSTR-3B');
    setFormFY('2026-27');
    setFormPeriod('June 2026');
    setFormDueDate('2026-07-20');
    setFormPriority('Medium');
    setFormStaffId(staffList[0]?.id || '');
    setFormStatus('Not Started');
    setFormDocsRequired(['Sales Data', 'Purchase Data']);
    setFormDocsPending(['Sales Data', 'Purchase Data']);
    setFormNotes('');
    setFormFees(3500);
    setFormReceived(0);
    setFormLastPaymentDate('');
    setFormFilingDate('');
    setFormAck('');
    setFormCompletionDate('');
    setFormRecurrence('Monthly');
    // Enhanced fields resets
    setFormPayments([]);
    setFormDocumentDetails({});
    setFormAcknowledgementPdf('');
    setFormAcknowledgementPdfName('');
    setFormAcknowledgementDate('');
    setFormNotesHistory([]);
    setNewNoteText('');
    setIsSaving(false);
    setIsFormOpen(true);
  };

  const handleOpenEditModal = (task: ComplianceTask) => {
    setEditingTask(task);
    setFormClientId(task.clientId);
    setFormCategory(task.serviceCategory);
    setFormReturnName(task.returnName);
    setFormFY(task.financialYear);
    setFormPeriod(task.filingPeriod);
    setFormDueDate(task.dueDate);
    setFormPriority(task.priority);
    setFormStaffId(task.assignedStaffId);
    setFormStatus(task.status);
    setFormDocsRequired(task.documentsRequired || []);
    setFormDocsPending(task.documentsPending || []);
    setFormNotes(task.internalNotes || '');
    setFormFees(task.professionalFees);
    setFormReceived(task.amountReceived);
    setFormLastPaymentDate(task.lastPaymentDate || '');
    setFormFilingDate(task.filingDate || '');
    setFormAck(task.acknowledgementNumber || '');
    setFormCompletionDate(task.completionDate || '');
    setFormRecurrence(task.recurrence);
    // Enhanced fields hydration
    setFormPayments(task.payments || []);
    setFormDocumentDetails(task.documentDetails || {});
    setFormAcknowledgementPdf(task.acknowledgementPdf || '');
    setFormAcknowledgementPdfName(task.acknowledgementPdfName || '');
    setFormAcknowledgementDate(task.acknowledgementDate || '');
    setFormNotesHistory(task.notesHistory || []);
    setNewNoteText('');
    setIsSaving(false);
    setIsFormOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formClientId) {
      showToast('Please select a Client.', 'error');
      return;
    }
    if (!formReturnName.trim()) {
      showToast('Form or Return Name is required.', 'error');
      return;
    }

    const clientObj = clientsList.find((c) => c.id === formClientId);
    const staffObj = staffList.find((s) => s.id === formStaffId);

    // Sum of payment amounts
    const totalPaymentsAmount = formPayments.reduce((sum, p) => sum + p.amount, 0);

    // Calculate Payment status
    let paymentStatus: 'Paid' | 'Partial' | 'Pending' = 'Pending';
    if (totalPaymentsAmount >= formFees) {
      paymentStatus = 'Paid';
    } else if (totalPaymentsAmount > 0) {
      paymentStatus = 'Partial';
    }

    // Auto-populate completion date when status is Completed
    let finalCompletionDate = formCompletionDate;
    if (formStatus === 'Completed' && !finalCompletionDate) {
      finalCompletionDate = new Date().toISOString().split('T')[0];
    }

    // Append notes history if there is a new note
    const updatedNotesHistory = [...formNotesHistory];
    if (newNoteText.trim()) {
      updatedNotesHistory.push({
        id: 'nt-' + Math.random().toString(36).substr(2, 9),
        timestamp: new Date().toISOString(),
        userName: currentUser?.name || 'Staff',
        note: newNoteText.trim()
      });
    }

    const payload = {
      clientId: formClientId,
      clientName: clientObj?.name || 'Unknown Client',
      serviceCategory: formCategory,
      returnName: formReturnName,
      financialYear: formFY,
      filingPeriod: formPeriod,
      dueDate: formDueDate,
      priority: formPriority,
      assignedStaffId: formStaffId,
      assignedStaffName: staffObj?.name || 'Unassigned',
      status: formStatus,
      documentsRequired: formDocsRequired,
      documentsPending: formDocsPending,
      internalNotes: newNoteText.trim() ? newNoteText.trim() : (formNotes || undefined),
      professionalFees: Number(formFees),
      amountReceived: Number(totalPaymentsAmount),
      paymentStatus,
      lastPaymentDate: formLastPaymentDate || undefined,
      filingDate: formFilingDate || undefined,
      acknowledgementNumber: formAck || undefined,
      completionDate: finalCompletionDate || undefined,
      recurrence: formRecurrence,
      // Enhanced Properties
      payments: formPayments,
      documentDetails: formDocumentDetails,
      acknowledgementPdf: formAcknowledgementPdf,
      acknowledgementPdfName: formAcknowledgementPdfName,
      acknowledgementDate: formAcknowledgementDate,
      notesHistory: updatedNotesHistory
    };

    setIsSaving(true);
    setTimeout(async () => {
      if (editingTask) {
        await updateTask(editingTask.id, payload);
        showToast(`Updated compliance task: ${formReturnName}`, 'success');
      } else {
        await createTask(payload);
        showToast(`Createed compliance task: ${formReturnName}`, 'success');
      }

      // Record detailed Audit Log of every change
      const auditChanges: string[] = [];
      if (editingTask) {
        if (formStatus !== editingTask.status) {
          auditChanges.push(`Filing Status updated from "${editingTask.status}" to "${formStatus}"`);
        }
        if (Number(formFees) !== editingTask.professionalFees) {
          auditChanges.push(`Professional Fees updated from ₹${editingTask.professionalFees} to ₹${formFees}`);
        }
        const prevPaymentsCount = editingTask.payments?.length || 0;
        if (formPayments.length !== prevPaymentsCount) {
          auditChanges.push(`Payment History updated (Total transactions: ${formPayments.length}, Total Received: ₹${totalPaymentsAmount})`);
        }
        if (formDueDate !== editingTask.dueDate) {
          auditChanges.push(`Filing Due Date updated from ${editingTask.dueDate} to ${formDueDate}`);
        }
        if (formAck !== (editingTask.acknowledgementNumber || '')) {
          auditChanges.push(`Government Ack No updated from "${editingTask.acknowledgementNumber || 'None'}" to "${formAck || 'None'}"`);
        }
        if (formAcknowledgementDate !== (editingTask.acknowledgementDate || '')) {
          auditChanges.push(`Acknowledgement Date updated to "${formAcknowledgementDate || 'None'}"`);
        }
        if (formAcknowledgementPdfName !== (editingTask.acknowledgementPdfName || '')) {
          auditChanges.push(`Acknowledgement PDF updated to "${formAcknowledgementPdfName || 'None'}"`);
        }
        if (newNoteText.trim()) {
          auditChanges.push(`New filing note added: "${newNoteText.trim().substring(0, 30)}..."`);
        }

        formDocsRequired.forEach(docName => {
          const oldDetail = editingTask.documentDetails?.[docName];
          const newDetail = formDocumentDetails[docName];
          if (newDetail?.fileName !== oldDetail?.fileName) {
            auditChanges.push(`Document "${docName}": file changed to "${newDetail?.fileName || 'None'}"`);
          }
          if (newDetail?.receivedDate !== oldDetail?.receivedDate) {
            auditChanges.push(`Document "${docName}": received date set to "${newDetail?.receivedDate || 'None'}"`);
          }
        });
      } else {
        auditChanges.push(`Createed new compliance task for ${clientObj?.name || 'Client'}`);
      }

      if (auditChanges.length > 0) {
        addAuditLog(
          editingTask ? 'Task Modified' : 'Task Created',
          editingTask ? editingTask.id : 'new-task',
          formReturnName,
          undefined,
          auditChanges.join('; ')
        );
      }

      setIsSaving(false);
      setIsFormOpen(false);
      refreshList();
    }, 800);
  };

  const handleDeleteTask = (task: ComplianceTask) => {
    setTaskToDelete(task);
  };

  const confirmDeleteTask = async () => {
    if (taskToDelete) {
      setIsDeleting(true);
      try {
        await deleteTask(taskToDelete.id);
        showToast('Filing task permanently deleted successfully.', 'warning');
        refreshList();
        setTaskToDelete(null);
      } catch (err) {
        console.error('Delete error', err);
        showToast(err instanceof Error ? err.message : 'Error deleting task', 'error');
      } finally {
        setIsDeleting(false);
      }
    }
  };

  const handleToggleRequiredDoc = (doc: string) => {
    if (formDocsRequired.includes(doc)) {
      setFormDocsRequired(prev => prev.filter(d => d !== doc));
      setFormDocsPending(prev => prev.filter(d => d !== doc));
    } else {
      setFormDocsRequired(prev => [...prev, doc]);
      setFormDocsPending(prev => [...prev, doc]);
    }
  };

  const handleTogglePendingDoc = (doc: string) => {
    if (formDocsPending.includes(doc)) {
      setFormDocsPending(prev => prev.filter(d => d !== doc));
    } else {
      if (!formDocsRequired.includes(doc)) {
        setFormDocsRequired(prev => [...prev, doc]);
      }
      setFormDocsPending(prev => [...prev, doc]);
    }
  };

  const handleAddCustomDoc = () => {
    if (customDocName.trim()) {
      const doc = customDocName.trim();
      if (!formDocsRequired.includes(doc)) {
        setFormDocsRequired(prev => [...prev, doc]);
        setFormDocsPending(prev => [...prev, doc]);
      }
      setCustomDocName('');
      showToast(`Added custom document checklist item: "${doc}"`, 'success');
    }
  };

  // EXPORT TO EXCEL
  const handleExportExcel = () => {
    try {
      const dataToExport = filteredTasks.map(t => ({
        'Client Name': t.clientName,
        'Service Category': t.serviceCategory,
        'Return Name': t.returnName,
        'Filing Period': t.filingPeriod,
        'Financial Year': t.financialYear,
        'Due Date': t.dueDate,
        'Priority': t.priority,
        'Assigned Staff': t.assignedStaffName,
        'Status': t.status,
        'Professional Fees (₹)': t.professionalFees,
        'Amount Received (₹)': t.amountReceived,
        'Outstanding Amount (₹)': t.outstandingAmount,
        'Payment Status': t.paymentStatus,
        'Acknowledgement Number': t.acknowledgementNumber || '',
        'Completion Date': t.completionDate || '',
        'Recurrence': t.recurrence
      }));

      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Compliance Tasks');
      XLSX.writeFile(workbook, `taxcom_tasks_${new Date().toISOString().split('T')[0]}.xlsx`);
      showToast('Compliance task sheet exported as Excel workbook successfully!', 'success');
    } catch (err: any) {
      showToast(`Export failed: ${err.message}`, 'error');
    }
  };

  // CSV IMPORT WIZARD HANDLER
  const importFieldsDefinition = [
    { key: 'clientName', label: 'Client Legal Name', required: true },
    { key: 'serviceCategory', label: 'Service Category', required: true },
    { key: 'returnName', label: 'Return Name', required: true },
    { key: 'financialYear', label: 'Financial Year', required: true },
    { key: 'filingPeriod', label: 'Filing Period', required: true },
    { key: 'dueDate', label: 'Due Date', required: true },
    { key: 'priority', label: 'Priority', required: true },
    { key: 'professionalFees', label: 'Professional Fees', required: true },
  ];

  const handleImportedData = (data: any[]) => {
    data.forEach(async (row) => {
      // Find matching client by name, or use first client
      const matchedClient = clientsList.find(c => c.name.toLowerCase() === row.clientName.toLowerCase()) || clientsList[0];
      const payload = {
        clientId: matchedClient?.id || '',
        clientName: matchedClient?.name || row.clientName,
        serviceCategory: (serviceCategories.includes(row.serviceCategory) ? row.serviceCategory : 'GST') as ServiceCategory,
        returnName: row.returnName,
        financialYear: row.financialYear || '2026-27',
        assessmentYear: '2027-28',
        filingPeriod: row.filingPeriod,
        dueDate: row.dueDate,
        priority: (['Low', 'Medium', 'High', 'Urgent'].includes(row.priority) ? row.priority : 'Medium') as any,
        assignedStaffId: staffList[0]?.id || currentUser?.id || '',
        assignedStaffName: staffList[0]?.name || currentUser?.name || 'Unassigned',
        status: 'Not Started' as const,
        documentsRequired: ['Sales Data'],
        documentsPending: ['Sales Data'],
        professionalFees: Number(row.professionalFees) || 3000,
        amountReceived: 0,
        paymentStatus: 'Pending' as const,
        recurrence: 'Monthly' as const,
      };
      await createTask(payload);
    });
    refreshList();
    setIsImportOpen(false);
  };

  // Filters and searches
  const filteredTasks = tasks.filter((t) => {
    // Role based restriction
    if (currentUser?.role === 'Staff' && t.assignedStaffId !== currentUser?.id) {
      return false;
    }

    const query = searchQuery.toLowerCase();
    const matchSearch =
      t.clientName.toLowerCase().includes(query) ||
      t.returnName.toLowerCase().includes(query) ||
      t.serviceCategory.toLowerCase().includes(query) ||
      (t.acknowledgementNumber && t.acknowledgementNumber.toLowerCase().includes(query));

    const matchCategory = filterCategory === 'All' || t.serviceCategory === filterCategory;
    const matchStatus = filterStatus === 'All' || t.status === filterStatus;
    const matchPriority = filterPriority === 'All' || t.priority === filterPriority;
    const matchStaff = filterStaff === 'All' || t.assignedStaffId === filterStaff;
    const matchPayment = filterPayment === 'All' || t.paymentStatus === filterPayment;

    return matchSearch && matchCategory && matchStatus && matchPriority && matchStaff && matchPayment;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center">
            <CheckSquare className="w-6 h-6 mr-2.5 text-[#F5405E]" />
            Client Compliance Tasks
          </h1>
          <p className="text-xs text-slate-500">Track GSTR-1, 3B, TDS, MCA and income tax schedules with real-time payment audit trails.</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsImportOpen(true)}
            className="inline-flex items-center justify-center h-10 px-4 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 shadow-xs cursor-pointer transition-colors"
          >
            <FileSpreadsheet className="w-4 h-4 mr-1.5 text-[#F5405E] shrink-0" />
            Import Excel/CSV
          </button>
          
          <button
            onClick={handleExportExcel}
            className="inline-flex items-center justify-center h-10 px-4 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 shadow-xs cursor-pointer transition-colors"
          >
            <Download className="w-4 h-4 mr-1.5 text-slate-500 shrink-0" />
            Export Excel
          </button>

          <button
            onClick={handleOpenCreateModal}
            className="inline-flex items-center justify-center h-10 px-4 text-xs font-bold text-white bg-[#F5405E] hover:bg-rose-600 rounded-lg shadow-sm cursor-pointer transition-colors"
          >
            <Plus className="w-4 h-4 mr-1.5 shrink-0" />
            Add Compliance Task
          </button>
        </div>
      </div>

      {/* Filters Panel Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col lg:flex-row gap-3">
          
          {/* Global Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search by Client Name, Return or Form Name, Acknowledgement..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 h-10 w-full text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-rose-500 bg-slate-50/30"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="text-xs border border-slate-300 rounded-lg px-3 h-10 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
            >
              <option value="All">All Categories</option>
              {serviceCategories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="text-xs border border-slate-300 rounded-lg px-3 h-10 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
            >
              <option value="All">All Statuses</option>
              {taskStatuses.map(stat => (
                <option key={stat} value={stat}>{stat}</option>
              ))}
            </select>

            <button
              onClick={() => setIsFilterPanelOpen(!isFilterPanelOpen)}
              className={`inline-flex items-center justify-center px-3.5 h-10 text-xs font-semibold rounded-lg border cursor-pointer transition-colors ${
                isFilterPanelOpen || filterPriority !== 'All' || filterStaff !== 'All' || filterPayment !== 'All'
                  ? 'bg-rose-50 text-[#F5405E] border-rose-200'
                  : 'bg-white text-slate-700 border-slate-300'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5 mr-1.5 shrink-0" />
              Advanced
            </button>
          </div>
        </div>

        {/* Advanced Filters block */}
        {isFilterPanelOpen && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3 border-t border-slate-100 animate-in slide-in-from-top duration-150">
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">Priority</label>
              <select
                value={filterPriority}
                onChange={(e) => setFilterPriority(e.target.value)}
                className="block w-full text-xs border border-slate-300 rounded-lg px-3 h-10 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
              >
                <option value="All">All Priorities</option>
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Urgent">Urgent</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">Assigned Staff</label>
              <select
                value={filterStaff}
                onChange={(e) => setFilterStaff(e.target.value)}
                className="block w-full text-xs border border-slate-300 rounded-lg px-3 h-10 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
              >
                <option value="All">All Staff</option>
                {staffList.map((st) => (
                  <option key={st.id} value={st.id}>{st.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">Payment Status</label>
              <select
                value={filterPayment}
                onChange={(e) => setFilterPayment(e.target.value)}
                className="block w-full text-xs border border-slate-300 rounded-lg px-3 h-10 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
              >
                <option value="All">All Payments</option>
                <option value="Paid">Paid</option>
                <option value="Partial">Partial</option>
                <option value="Pending">Pending</option>
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Tasks tabular data */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        {filteredTasks.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-sm font-semibold text-slate-500">No compliance tasks found matching criteria.</p>
            <p className="text-xs text-slate-400 mt-1">Add tasks manually or import via CSV templates.</p>
          </div>
        ) : (
          <div className="w-full overflow-x-auto overflow-y-auto max-h-[70vh]">
            <table className="w-full text-left text-sm border-collapse">
              <thead className="sticky top-0 z-10 bg-slate-50 shadow-sm">
                <tr className="border-b border-slate-200 text-slate-500 text-xs font-bold uppercase tracking-wider">
                  <th className="py-3 px-4">Client Name</th>
                  <th className="py-3 px-4">Compliance Return</th>
                  <th className="py-3 px-4">Timeline</th>
                  <th className="py-3 px-4">Documents Required</th>
                  <th className="py-3 px-4">Payment Tracking</th>
                  <th className="py-3 px-4">Staff / Recurrence</th>
                  <th className="py-3 px-4">Filing Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTasks.map((task) => {
                  const todayObj = new Date('2026-07-17');
                  const dueObj = new Date(task.dueDate);
                  const isOverdue = dueObj < todayObj && task.status !== 'Completed' && task.status !== 'Filed';

                  return (
                    <tr key={task.id} className="hover:bg-slate-50/50">
                      <td className="py-4 px-4">
                        <span className="font-extrabold text-slate-900 block whitespace-normal break-words max-w-[180px] leading-tight">{getClientById(task.clientId)?.name || task.clientName}</span>
                        <span className="text-[10px] text-slate-400 font-bold block mt-1">FY {task.financialYear}</span>
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-1.5">
                          <span className="text-xs font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded">{task.serviceCategory}</span>
                          <span className={`text-[9px] font-extrabold px-1 py-0.5 rounded ${
                            task.priority === 'Urgent'
                              ? 'bg-red-100 text-red-700'
                              : task.priority === 'High'
                              ? 'bg-amber-100 text-amber-700'
                              : 'bg-slate-100 text-slate-600'
                          }`}>
                            {task.priority}
                          </span>
                        </div>
                        <span className="text-xs font-bold text-slate-800 block mt-1.5 whitespace-normal break-words max-w-[200px] leading-tight">{task.returnName}</span>
                        <span className="text-[11px] text-slate-400 block font-semibold mt-0.5">{task.filingPeriod}</span>
                      </td>
                      <td className="py-4 px-4 text-xs">
                        <span className={`font-bold block ${isOverdue ? 'text-rose-600' : 'text-slate-700'}`}>
                          Due: {task.dueDate}
                        </span>
                        {isOverdue && (
                          <span className="inline-flex items-center px-1 rounded text-[8px] font-bold bg-rose-100 text-rose-700 uppercase mt-0.5 animate-pulse">
                            Overdue
                          </span>
                        )}
                        {task.completionDate && <span className="text-emerald-600 text-[10px] font-medium block">Done: {task.completionDate}</span>}
                      </td>
                      <td className="py-4 px-4 text-xs">
                        <div className="space-y-1">
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider font-bold block">
                            Required ({task.documentsRequired?.length || 0})
                          </span>
                          <span className="text-[11px] text-slate-700 block font-semibold">
                            Pending: <strong className="text-rose-600">{task.documentsPending?.length || 0}</strong>
                          </span>
                           {task.documentsPending?.length > 0 && (
                            <div className="flex flex-wrap gap-1 max-w-[160px]">
                              {task.documentsPending.slice(0, 2).map((d, i) => (
                                <span key={i} className="bg-rose-50 text-rose-700 text-[9px] px-1.5 py-0.5 rounded border border-rose-100 whitespace-normal break-words max-w-full">
                                  {d}
                                </span>
                              ))}
                              {task.documentsPending.length > 2 && (
                                <span className="bg-slate-100 text-slate-600 text-[9px] px-1 rounded">+{task.documentsPending.length - 2} more</span>
                              )}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="py-4 px-4 text-xs space-y-0.5">
                        <div className="font-semibold text-slate-700">Fees: ₹{task.professionalFees}</div>
                        <div className="text-emerald-600">Recd: ₹{task.amountReceived}</div>
                        <div className={`font-bold ${task.outstandingAmount > 0 ? 'text-rose-600 bg-rose-50 px-1 rounded' : 'text-slate-400'}`}>
                          Bal: ₹{task.outstandingAmount}
                        </div>
                        <span className={`inline-block px-1 rounded text-[9px] font-bold uppercase tracking-wider ${
                          task.paymentStatus === 'Paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : task.paymentStatus === 'Partial'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}>
                          {task.paymentStatus}
                        </span>
                      </td>
                      <td className="py-4 px-4 text-xs">
                        <span className="block font-semibold text-slate-800">{task.assignedStaffName}</span>
                        <span className="inline-flex items-center text-[10px] font-medium text-slate-400 bg-slate-100 px-1 py-0.5 rounded mt-1">
                          <CalendarDays className="w-3 h-3 mr-1" />
                          {task.recurrence}
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold ${
                          task.status === 'Completed' || task.status === 'Filed'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : task.status === 'In Progress'
                            ? 'bg-blue-50 text-blue-700 border border-blue-200'
                            : task.status === 'Documents Pending'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-slate-100 text-slate-600 border border-slate-200'
                        }`}>
                          {task.status}
                        </span>
                        {task.acknowledgementNumber && (
                          <span className="block font-mono text-[9px] text-slate-400 mt-1">Ack: {task.acknowledgementNumber}</span>
                        )}
                      </td>
                      <td className="py-4 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => handleOpenEditModal(task)}
                            title="Edit task & payment"
                            className="p-2.5 sm:p-1.5 text-slate-500 hover:text-[#F5405E] hover:bg-rose-50 rounded-lg transition-colors cursor-pointer min-w-[36px] min-h-[36px] flex items-center justify-center"
                          >
                            <Edit2 className="w-4 h-4 shrink-0" />
                          </button>
                          <button
                            onClick={() => handleDeleteTask(task)}
                            title="Delete task"
                            className="p-2.5 sm:p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer min-w-[36px] min-h-[36px] flex items-center justify-center"
                          >
                            <Trash2 className="w-4 h-4 shrink-0" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* TASK CREATE / EDIT DIALOG FORM MODAL */}
      
      {/* DELETE CONFIRMATION MODAL */}
      {taskToDelete && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-sm overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
            <div className="p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-rose-100 mx-auto flex items-center justify-center mb-4">
                <Trash2 className="w-6 h-6 text-rose-600" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Delete Task</h3>
              <p className="text-sm text-slate-500">
                Are you sure you want to delete the task <strong className="font-semibold text-slate-700">"{taskToDelete.returnName}"</strong> for <strong className="font-semibold text-slate-700">{taskToDelete.clientName}</strong>?
              </p>
            </div>
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-center gap-3">
              <button
                disabled={isDeleting}
                onClick={() => setTaskToDelete(null)}
                className="px-4 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-all disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                disabled={isDeleting}
                onClick={confirmDeleteTask}
                className={`px-4 py-2 text-sm font-bold text-white bg-rose-500 hover:bg-rose-600 rounded-lg transition-all shadow-sm ${isDeleting ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      
      {/* DELETE PAYMENT MODAL */}
      {paymentToDelete && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-sm overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
            <div className="p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-rose-100 mx-auto flex items-center justify-center mb-4">
                <Trash2 className="w-6 h-6 text-rose-600" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Delete Payment</h3>
              <p className="text-sm text-slate-500">
                Are you sure you want to delete this payment transaction? This action cannot be undone.
              </p>
            </div>
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-center gap-3">
              <button
                onClick={() => setPaymentToDelete(null)}
                className="px-4 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-all"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setFormPayments(prev => prev.filter(item => item.id !== paymentToDelete.id));
                  showToast('Payment transaction removed.', 'info');
                  setPaymentToDelete(null);
                }}
                className="px-4 py-2 text-sm font-bold text-white bg-rose-500 hover:bg-rose-600 rounded-lg transition-all shadow-sm"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {isFormOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center sm:p-4">
          <div className="bg-white sm:rounded-2xl shadow-xl border-0 sm:border border-slate-100 max-w-3xl w-full h-full sm:h-auto sm:max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 border-b border-slate-100 bg-slate-50 flex items-center justify-between border-l-4 border-l-[#F5405E] pl-4 shrink-0">
              <h3 className="font-extrabold text-slate-900 text-lg">
                {editingTask ? 'Edit Compliance Task' : 'Create Compliance Task'}
              </h3>
              <button onClick={() => setIsFormOpen(false)} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
            </div>

            <form onSubmit={handleFormSubmit} className="flex-1 flex flex-col overflow-hidden">
              {/* Scrollable Form Body */}
              <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-6 bg-slate-50/20">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  
                  {/* Client Dropdown */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Client Master *</label>
                    <select
                      required
                      value={formClientId}
                      onChange={(e) => setFormClientId(e.target.value)}
                      className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
                    >
                      <option value="">-- Select Client --</option>
                      {clientsList
                        .filter((c) => c.status === 'Active' || c.id === formClientId || c.clientId === formClientId)
                        .map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.clientId} – {c.name} {c.status === 'Inactive' ? ' (INACTIVE)' : ''}
                          </option>
                        ))}
                    </select>
                  </div>

                  {/* Service Category */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Service Category *</label>
                    <select
                      value={formCategory}
                      onChange={(e) => {
                        const newCat = e.target.value as ServiceCategory;
                        setFormCategory(newCat);
                        if (newCat === 'GST') {
                          setFormReturnName('GSTR-3B');
                        } else if (newCat === 'Income Tax') {
                          setFormReturnName('ITR-1');
                        } else if (newCat === 'TDS') {
                          setFormReturnName('Form 24Q');
                        }
                      }}
                      className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
                    >
                      {serviceCategories.map((cat) => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>

                  {/* Return Name */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Return / Form Name *</label>
                    {formCategory === 'GST' ? (
                      <div className="space-y-2">
                        <select
                          required
                          value={["GSTR-1", "GSTR-3B", "CMP-08", "GSTR-4", "GSTR-9", "GSTR-9C"].includes(formReturnName) ? formReturnName : "Custom"}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === 'Custom') {
                              setFormReturnName('Custom');
                            } else {
                              setFormReturnName(val);
                            }
                          }}
                          className="w-full h-10 text-xs border border-rose-200 rounded-lg px-3 bg-rose-50/10 font-bold text-[#F5405E] transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#F5405E]/15 focus:border-[#F5405E] cursor-pointer"
                        >
                          {["GSTR-1", "GSTR-3B", "CMP-08", "GSTR-4", "GSTR-9", "GSTR-9C", "Custom"].map((opt) => (
                            <option key={opt} value={opt}>{opt}</option>
                          ))}
                        </select>
                        {(formReturnName === 'Custom' || !["GSTR-1", "GSTR-3B", "CMP-08", "GSTR-4", "GSTR-9", "GSTR-9C"].includes(formReturnName)) && (
                          <input
                            type="text"
                            required
                            placeholder="Enter custom form name..."
                            value={formReturnName === 'Custom' ? '' : formReturnName}
                            onChange={(e) => setFormReturnName(e.target.value)}
                            className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white focus:outline-none focus:ring-1 focus:ring-[#F5405E] animate-in slide-in-from-top-1 duration-200 font-bold text-[#F5405E]"
                          />
                        )}
                      </div>
                    ) : (
                      <input
                        type="text"
                        required
                        placeholder="e.g. GSTR-3B"
                        value={formReturnName}
                        onChange={(e) => setFormReturnName(e.target.value)}
                        className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-semibold"
                      />
                    )}
                  </div>

                  {/* FY / AY */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Financial Year *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. 2026-27"
                      value={formFY}
                      onChange={(e) => setFormFY(e.target.value)}
                      className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white text-center animate-in fade-in font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500"
                    />
                  </div>

                  {/* Filing Period */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Filing Period *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. June 2026, Q1 (Apr-Jun)"
                      value={formPeriod}
                      onChange={(e) => setFormPeriod(e.target.value)}
                      className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500"
                    />
                  </div>

                  {/* Due Date */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Filing Due Date *</label>
                    <input
                      type="date"
                      required
                      value={formDueDate}
                      onChange={(e) => setFormDueDate(e.target.value)}
                      className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white font-bold text-[#F5405E] focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
                    />
                  </div>

                  {/* Priority */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Priority *</label>
                    <select
                      value={formPriority}
                      onChange={(e) => setFormPriority(e.target.value as any)}
                      className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
                    >
                      <option value="Low">Low</option>
                      <option value="Medium">Medium</option>
                      <option value="High">High</option>
                      <option value="Urgent">Urgent</option>
                    </select>
                  </div>

                  {/* Assigned Staff */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Assigned Staff Partner *</label>
                    <select
                      value={formStaffId}
                      onChange={(e) => setFormStaffId(e.target.value)}
                      className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
                    >
                      {staffList.map((st) => (
                        <option key={st.id} value={st.id}>{st.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Recurrence Selector */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Recurrence Cycle *</label>
                    <select
                      value={formRecurrence}
                      onChange={(e) => setFormRecurrence(e.target.value as RecurrenceType)}
                      className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
                    >
                      <option value="Monthly">Monthly</option>
                      <option value="Quarterly">Quarterly</option>
                      <option value="Half-Yearly">Half-Yearly</option>
                      <option value="Annual">Annual</option>
                      <option value="One-Time">One-Time</option>
                      <option value="Custom Recurrence">Custom Recurrence</option>
                    </select>
                  </div>

                  {/* Task Status */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Task / Filing Status *</label>
                    <select
                      value={formStatus}
                      onChange={(e) => setFormStatus(e.target.value as TaskStatus)}
                      className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white font-bold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
                    >
                      {taskStatuses.map((stat) => (
                        <option key={stat} value={stat}>{stat}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Document tracker checklist section */}
                <div className="p-4 sm:p-5 bg-gradient-to-br from-slate-50 to-slate-100/50 border border-slate-200/80 rounded-2xl space-y-4 shadow-xs transition-all duration-300 hover:shadow-md">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center w-full sm:w-auto whitespace-normal break-words">
                      <FileText className="w-4 h-4 mr-1.5 text-[#F5405E] shrink-0" />
                      <span className="break-words whitespace-normal leading-tight">Document Checklist Tracking ({formDocsRequired.length} required)</span>
                    </h4>
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
                      <input
                        type="text"
                        placeholder="Add custom doc..."
                        value={customDocName}
                        onChange={(e) => setCustomDocName(e.target.value)}
                        className="text-xs border border-slate-300 rounded-lg px-3 w-full sm:w-40 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500 h-10 font-semibold"
                      />
                      <button
                        type="button"
                        onClick={handleAddCustomDoc}
                        className="text-xs font-bold bg-[#F5405E] text-white hover:bg-rose-600 transition-colors rounded-lg px-4 flex items-center justify-center gap-1.5 shrink-0 h-10 w-full sm:w-auto cursor-pointer shadow-sm"
                      >
                        <PlusCircle className="w-4 h-4 shrink-0" />
                        <span>Add</span>
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 pt-1">
                    {Array.from(new Set([...standardDocs, ...formDocsRequired, ...formDocsPending])).map((doc) => {
                      const isReq = formDocsRequired.includes(doc);
                      const isPend = formDocsPending.includes(doc);
                      return (
                        <div key={doc} className="p-2.5 border border-slate-200 rounded-lg bg-white flex flex-col justify-between space-y-2 shadow-xs">
                          <span className="text-[11px] font-bold text-slate-800 leading-tight block whitespace-normal break-words" title={doc}>
                            {doc}
                          </span>
                          <div className="flex flex-wrap items-center justify-between gap-2.5 text-[10px] pt-1 border-t border-slate-100">
                            <label className="flex items-start gap-1.5 text-slate-500 cursor-pointer whitespace-normal break-words">
                              <input
                                type="checkbox"
                                checked={isReq}
                                onChange={() => handleToggleRequiredDoc(doc)}
                                className="accent-rose-500 h-3.5 w-3.5 shrink-0 mt-0.5"
                              />
                              <span>Required</span>
                            </label>
                            <label className={`flex items-start gap-1.5 cursor-pointer whitespace-normal break-words ${isPend ? 'text-rose-600 font-bold' : 'text-slate-400'}`}>
                              <input
                                type="checkbox"
                                checked={isPend}
                                disabled={!isReq}
                                onChange={() => handleTogglePendingDoc(doc)}
                                className="accent-rose-500 h-3.5 w-3.5 shrink-0 mt-0.5"
                              />
                              <span>Pending</span>
                            </label>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Payments tracker block */}
                <div className="p-4 bg-rose-50/30 border border-rose-100 rounded-xl space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-[#F5405E] uppercase tracking-wider flex items-center">
                      <CreditCard className="w-4 h-4 mr-1" />
                      Professional Fee Payment Audit & History
                    </h4>
                    <span className="text-[10px] font-bold text-slate-400 bg-white border border-slate-200 rounded-lg px-2 py-0.5">
                      Transactions: {formPayments.length}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-500 mb-1 uppercase">Professional Fee (₹)</label>
                      <input
                        type="number"
                        required
                        min={0}
                        value={formFees}
                        onChange={(e) => setFormFees(Number(e.target.value))}
                        className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white font-semibold text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-500 mb-1 uppercase">Total Amount Received (₹)</label>
                      <div className="w-full text-xs border border-slate-200 rounded-lg p-3 bg-slate-100 font-bold text-emerald-600 shadow-inner">
                        ₹{totalPaymentsAmount.toLocaleString('en-IN')}
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-500 mb-1 uppercase">Outstanding Balance (₹)</label>
                      <div className={`w-full text-xs border rounded-lg p-3 font-bold shadow-inner ${
                        calculatedOutstanding > 0 ? 'bg-rose-50 border-rose-200 text-rose-600' : 'bg-emerald-50 border-emerald-200 text-emerald-600'
                      }`}>
                        ₹{calculatedOutstanding.toLocaleString('en-IN')}
                      </div>
                    </div>
                  </div>

                  {/* Inline Add Payment Form */}
                  <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-3 shadow-xs">
                    <h5 className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center">
                      <Plus className="w-4 h-4 mr-1.5 text-[#F5405E] shrink-0" />
                      Record New Payment Receipt
                    </h5>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                      <div>
                        <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Payment Date</label>
                        <input
                          type="date"
                          value={newPaymentDate}
                          onChange={(e) => setNewPaymentDate(e.target.value)}
                          className="w-full h-10 text-xs border border-slate-200 rounded-lg px-3 bg-slate-50/50 focus:outline-none focus:ring-1 focus:ring-rose-500 font-semibold cursor-pointer"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Amount (₹)</label>
                        <input
                          type="number"
                          placeholder="Amount"
                          value={newPaymentAmount}
                          onChange={(e) => setNewPaymentAmount(e.target.value)}
                          className="w-full h-10 text-xs border border-slate-200 rounded-lg px-3 bg-slate-50/50 focus:outline-none focus:ring-1 focus:ring-rose-500 font-semibold"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Payment Mode</label>
                        <select
                          value={newPaymentMode}
                          onChange={(e) => setNewPaymentMode(e.target.value)}
                          className="w-full h-10 text-xs border border-slate-200 rounded-lg px-3 bg-slate-50/50 focus:outline-none focus:ring-1 focus:ring-rose-500 font-semibold cursor-pointer"
                        >
                          <option value="UPI">UPI</option>
                          <option value="Bank Transfer">Bank Transfer</option>
                          <option value="Cash">Cash</option>
                          <option value="Cheque">Cheque</option>
                          <option value="Card">Card</option>
                          <option value="Net Banking">Net Banking</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Transaction ID</label>
                        <input
                          type="text"
                          placeholder="Txn ID"
                          value={newPaymentTxId}
                          onChange={(e) => setNewPaymentTxId(e.target.value)}
                          className="w-full h-10 text-xs border border-slate-200 rounded-lg px-3 bg-slate-50/50 focus:outline-none focus:ring-1 focus:ring-rose-500 font-semibold"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] font-bold text-slate-400 uppercase mb-1">Remarks</label>
                        <input
                          type="text"
                          placeholder="e.g. Adv. fees"
                          value={newPaymentRemarks}
                          onChange={(e) => setNewPaymentRemarks(e.target.value)}
                          className="w-full h-10 text-xs border border-slate-200 rounded-lg px-3 bg-slate-50/50 focus:outline-none focus:ring-1 focus:ring-rose-500 font-semibold"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          if (!newPaymentAmount || Number(newPaymentAmount) <= 0) {
                            showToast('Please enter a valid payment amount.', 'warning');
                            return;
                          }
                          const pDate = newPaymentDate || new Date().toISOString().split('T')[0];
                          const newPaymentObj = {
                            id: 'pm-' + Math.random().toString(36).substr(2, 9),
                            date: pDate,
                            amount: Number(newPaymentAmount),
                            mode: newPaymentMode,
                            transactionId: newPaymentTxId || 'N/A',
                            remarks: newPaymentRemarks || 'No remarks'
                          };
                          setFormPayments(prev => [...prev, newPaymentObj]);
                          setFormLastPaymentDate(pDate);
                          
                          // Reset form
                          setNewPaymentAmount('');
                          setNewPaymentTxId('');
                          setNewPaymentRemarks('');
                          showToast(`Recorded payment of ₹${newPaymentObj.amount} successfully!`, 'success');
                        }}
                        className="inline-flex items-center justify-center h-10 px-4 text-xs font-bold text-white bg-[#F5405E] hover:bg-rose-600 rounded-lg transition-colors shadow-sm cursor-pointer"
                      >
                        <Plus className="w-4 h-4 mr-1.5 shrink-0" />
                        Add Payment Receipt
                      </button>
                    </div>
                  </div>

                  {/* Payments list/table */}
                  {formPayments.length > 0 ? (
                    <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto shadow-xs">
                      <table className="w-full text-left text-[11px] border-collapse">
                        <thead>
                          <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[9px]">
                            <th className="py-2.5 px-3">Date</th>
                            <th className="py-2.5 px-3">Mode</th>
                            <th className="py-2.5 px-3">Txn ID</th>
                            <th className="py-2.5 px-3">Remarks</th>
                            <th className="py-2.5 px-3 text-right">Amount (₹)</th>
                            <th className="py-2.5 px-2 text-center">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-semibold text-slate-700">
                          {formPayments.map((p) => (
                            <tr key={p.id} className="hover:bg-slate-50/50">
                              <td className="py-2.5 px-3 text-slate-600">{p.date}</td>
                              <td className="py-2.5 px-3 text-rose-600">{p.mode}</td>
                              <td className="py-2.5 px-3 font-mono text-[10px]">{p.transactionId}</td>
                              <td className="py-2.5 px-3 text-slate-500 font-medium max-w-[120px] whitespace-normal break-all" title={p.remarks}>{p.remarks}</td>
                              <td className="py-2.5 px-3 text-right text-emerald-600">₹{p.amount.toLocaleString('en-IN')}</td>
                              <td className="py-2.5 px-2 text-center">
                                <button
                                  type="button"
                                  onClick={() => setPaymentToDelete(p)}
                                  className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg min-w-[32px] min-h-[32px] flex items-center justify-center cursor-pointer"
                                  title="Delete Payment"
                                >
                                  <Trash2 className="w-3.5 h-3.5 shrink-0" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <p className="text-[10px] text-slate-400 font-medium text-center py-2">No payment transactions recorded yet.</p>
                  )}
                </div>

                {/* Filing & Acknowledgement Details block */}
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-4">
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center">
                    <CheckCircle className="w-4 h-4 mr-1 text-[#F5405E]" />
                    Government Filing & Acknowledgement
                  </h4>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Date Filed</label>
                      <input
                        type="date"
                        value={formFilingDate}
                        onChange={(e) => setFormFilingDate(e.target.value)}
                        className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Government Ack No</label>
                      <input
                        type="text"
                        placeholder="e.g. ACK9988771122"
                        value={formAck}
                        onChange={(e) => setFormAck(e.target.value)}
                        className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white font-mono font-bold text-slate-800 uppercase focus:outline-none focus:ring-1 focus:ring-rose-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Acknowledgement Date</label>
                      <input
                        type="date"
                        value={formAcknowledgementDate}
                        onChange={(e) => setFormAcknowledgementDate(e.target.value)}
                        className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Completion Date</label>
                      <input
                        type="date"
                        value={formCompletionDate}
                        onChange={(e) => setFormCompletionDate(e.target.value)}
                        className="w-full h-10 text-xs border border-slate-300 rounded-lg px-3 bg-white font-semibold text-emerald-600 focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Government Ack PDF Uploader */}
                  <div className="p-3 bg-white border border-slate-200 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div>
                      <span className="font-bold text-slate-700 block">Government Acknowledgement PDF Receipt</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        {formAcknowledgementPdfName ? `Attached: ${formAcknowledgementPdfName}` : 'No PDF attached yet'}
                      </span>
                    </div>

                    <div className="flex items-center space-x-2">
                      {formAcknowledgementPdf ? (
                        <>
                          <button
                            type="button"
                            onClick={() => setPreviewFile({ name: formAcknowledgementPdfName || 'Acknowledgement.pdf', data: formAcknowledgementPdf })}
                            className="inline-flex items-center px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors border border-slate-200"
                          >
                            <Eye className="w-3.5 h-3.5 mr-1 text-slate-500" />
                            View Ack PDF
                          </button>
                          <button
                            type="button"
                            onClick={handleDownloadAckPdf}
                            className="inline-flex items-center px-3 py-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded transition-colors border border-emerald-200"
                          >
                            <Download className="w-3.5 h-3.5 mr-1" />
                            Download PDF
                          </button>
                          <label className="inline-flex items-center px-3 py-1.5 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 rounded cursor-pointer transition-colors border border-slate-200">
                            <Upload className="w-3.5 h-3.5 mr-1 text-slate-500" />
                            Replace PDF
                            <input
                              type="file"
                              accept="application/pdf"
                              className="hidden"
                              onChange={(e) => handleAckPdfChange(e.target.files?.[0] || null)}
                            />
                          </label>
                        </>
                      ) : (
                        <label className="inline-flex items-center px-4 py-2 text-xs font-bold text-white bg-slate-700 hover:bg-slate-800 rounded cursor-pointer transition-colors shadow-xs">
                          <Upload className="w-4 h-4 mr-1.5" />
                          Upload Ack PDF Receipt
                          <input
                            type="file"
                            accept="application/pdf"
                            className="hidden"
                            onChange={(e) => handleAckPdfChange(e.target.files?.[0] || null)}
                          />
                        </label>
                      )}
                    </div>
                  </div>
                </div>

                {/* Note History and Add Note block */}
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Filing Notes History</label>
                    {formNotesHistory.length > 0 ? (
                      <div className="space-y-2 max-h-48 overflow-y-auto bg-slate-50 border border-slate-200 rounded-xl p-3">
                        {formNotesHistory.map((n) => (
                          <div key={n.id} className="text-xs bg-white p-2.5 border border-slate-100 rounded-lg shadow-2xs space-y-1">
                            <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold">
                              <span>{n.userName}</span>
                              <span>{new Date(n.timestamp).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}</span>
                            </div>
                            <p className="text-slate-700 font-medium break-words whitespace-pre-wrap">{n.note}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center p-4 bg-slate-50/50 border border-dashed border-slate-200 rounded-xl">
                        <p className="text-[11px] text-slate-400 font-medium">No previous internal notes recorded.</p>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Add New Internal Note / Instructions</label>
                    <textarea
                      rows={2}
                      placeholder="Enter special filing updates or staff instructions to append to history..."
                      value={newNoteText}
                      onChange={(e) => setNewNoteText(e.target.value)}
                      className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white font-medium focus:ring-1 focus:ring-[#F5405E] focus:outline-none"
                    />
                    {formNotes && !formNotesHistory.length && (
                      <div className="mt-1 text-[10px] text-slate-400 font-bold">
                        Original Note: <span className="font-semibold text-slate-500 italic">"{formNotes}"</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Sticky Footer */}
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end gap-3 z-10 shrink-0">
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={() => setIsFormOpen(false)}
                  className="inline-flex items-center justify-center h-10 px-4 text-xs font-bold text-slate-500 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg disabled:opacity-50 transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="inline-flex items-center justify-center h-10 px-5 text-xs font-bold text-white bg-[#F5405E] hover:bg-rose-600 rounded-lg shadow-sm disabled:opacity-80 transition-all cursor-pointer"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-1.5 animate-spin shrink-0" />
                      Saving changes...
                    </>
                  ) : editingTask ? (
                    'Save Updates'
                  ) : (
                    'Publish Task'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* FILE PREVIEW MODAL */}
      {previewFile && (
        <div className="fixed inset-0 z-[100] bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-100 max-w-4xl w-full flex flex-col overflow-hidden animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
              <h4 className="font-bold text-slate-900 truncate flex items-center space-x-2">
                <FileText className="w-4 h-4 text-rose-500" />
                <span>File Preview: {previewFile.name}</span>
              </h4>
              <button
                type="button"
                onClick={() => setPreviewFile(null)}
                className="text-slate-400 hover:text-slate-600 font-bold p-1 hover:bg-slate-100 rounded"
              >
                ✕
              </button>
            </div>
            <div className="p-4 bg-slate-100/50 flex items-center justify-center min-h-[50vh] max-h-[70vh] overflow-auto">
              {previewFile.data.startsWith('data:image/') ? (
                <img
                  src={previewFile.data}
                  alt={previewFile.name}
                  referrerPolicy="no-referrer"
                  className="max-w-full max-h-[60vh] object-contain rounded shadow"
                />
              ) : previewFile.data.startsWith('data:application/pdf') ? (
                <iframe
                  src={previewFile.data}
                  title={previewFile.name}
                  className="w-full h-[60vh] rounded border border-slate-200 shadow"
                />
              ) : (
                <div className="text-center p-8 bg-white border border-slate-200 rounded-lg max-w-sm">
                  <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-sm font-semibold text-slate-700 mb-1">{previewFile.name}</p>
                  <p className="text-xs text-slate-400 mb-4">This file type cannot be previewed directly in the browser.</p>
                  <a
                    href={previewFile.data}
                    download={previewFile.name}
                    className="inline-flex items-center px-4 py-2 text-xs font-bold text-white bg-slate-800 hover:bg-slate-900 rounded-lg shadow"
                  >
                    <Download className="w-3.5 h-3.5 mr-1.5" />
                    Download to View
                  </a>
                </div>
              )}
            </div>
            <div className="p-3 bg-slate-50 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={() => setPreviewFile(null)}
                className="px-4 py-2 text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* COMPLIANCE IMPORT MODAL */}
      <ImportWizard
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        title="Import Compliance Calendar Spreadsheet"
        fields={importFieldsDefinition}
        existingKeys={[]} // allow duplicates as tasks recur
        duplicateCheckKey="returnName"
        onImport={handleImportedData}
      />

    </div>
  );
}
