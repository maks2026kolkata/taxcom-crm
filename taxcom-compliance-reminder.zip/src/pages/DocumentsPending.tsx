import React, { useState, useEffect } from 'react';
import {
  FileText,
  Search,
  CheckCircle,
  Clock,
  AlertCircle,
  CheckSquare,
  ArrowRight,
  Filter,
  UserCheck
} from 'lucide-react';
import { getTasks, updateTask, getStaff, getClientById } from '../db/storage';
import { ComplianceTask } from '../types';
import { useToast } from '../components/Toast';

export default function DocumentsPending() {
  const { showToast } = useToast();
  const [tasks, setTasks] = useState<ComplianceTask[]>(() => getTasks());
  const staffList = getStaff();

  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStaff, setFilterStaff] = useState('All');
  const [docToReceive, setDocToReceive] = useState<{task: ComplianceTask, doc: string} | null>(null);

  React.useEffect(() => {
    const handleSync = () => {
      setTasks(getTasks());
    };
    window.addEventListener('database-sync', handleSync);
    return () => window.removeEventListener('database-sync', handleSync);
  }, []);

  const refreshList = () => {
    setTasks(getTasks());
  };

  const handleReceiveDoc = (task: ComplianceTask, docToReceive: string) => {
    const updatedPending = task.documentsPending.filter(d => d !== docToReceive);
    if (updatedPending.length === 0) {
      setDocToReceive({task, doc: docToReceive});
      return;
    }
    // Proceed normally if not last document
    updateTask(task.id, {
      documentsPending: updatedPending,
      status: 'In Progress',
    });
    showToast('Document marked as received.', 'success');
    refreshList();
  };
  
  const confirmLastDoc = (status: 'Ready to File' | 'In Progress') => {
    if (docToReceive) {
      const {task, doc} = docToReceive;
      const updatedPending = task.documentsPending.filter(d => d !== doc);
      updateTask(task.id, {
        documentsPending: updatedPending,
        status: status,
      });
      showToast(`All documents received! Status updated to "${status}"`, 'success');
      refreshList();
      setDocToReceive(null);
    }
  };

  const oldHandleReceiveDoc = (task: ComplianceTask, docToReceive: string) => {
    const updatedPending = task.documentsPending.filter(d => d !== docToReceive);
    
    // Check if that was the last pending document
    if (updatedPending.length === 0) {
      const confirmStatus = true; // disabled
      
      const newStatus = confirmStatus ? 'Ready to File' : 'In Progress';
      updateTask(task.id, {
        documentsPending: updatedPending,
        status: newStatus,
      });
      showToast(`All documents received! Status updated to "${newStatus}"`, 'success');
    } else {
      updateTask(task.id, {
        documentsPending: updatedPending,
      });
      showToast(`Marked "${docToReceive}" as received.`, 'success');
    }
    
    refreshList();
  };

  // Filter tasks with documents pending
  const docPendingTasks = tasks.filter((t) => {
    if (t.isDeleted) return false;
    
    // Explicitly check for status OR tasks that have documents required but some are pending
    const hasDocsPending = t.documentsPending && t.documentsPending.length > 0;
    const isDocPendingStatus = t.status === 'Documents Pending' || hasDocsPending;
    if (!isDocPendingStatus) return false;

    const query = searchQuery.toLowerCase();
    const matchSearch =
      (getClientById(t.clientId)?.name || t.clientName).toLowerCase().includes(query) ||
      t.returnName.toLowerCase().includes(query) ||
      t.serviceCategory.toLowerCase().includes(query);

    const matchStaff = filterStaff === 'All' || t.assignedStaffId === filterStaff;

    return matchSearch && matchStaff;
  });

  const totalPendingDocsCount = docPendingTasks.reduce((sum, t) => sum + (t.documentsPending?.length || 0), 0);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Title Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center">
          <FileText className="w-6 h-6 mr-2.5 text-[#F5405E]" />
          Document Checklist & Pending Tracker
        </h1>
        <p className="text-xs text-slate-500">
          Track and sign off on missing client invoices, bank statements, challans, and portal credentials.
        </p>
      </div>

      {/* KPI statistics row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex items-center space-x-4">
          <div className="p-3 bg-rose-50 text-rose-500 rounded-lg">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-xs font-semibold uppercase tracking-wider text-slate-400">Tasks Awaiting Docs</span>
            <span className="text-2xl font-bold text-rose-600">{docPendingTasks.length}</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex items-center space-x-4">
          <div className="p-3 bg-amber-50 text-amber-500 rounded-lg">
            <AlertCircle className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <span className="block text-xs font-semibold uppercase tracking-wider text-slate-400">Total Outstanding Files</span>
            <span className="text-2xl font-bold text-amber-500">{totalPendingDocsCount}</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex items-center space-x-4 bg-emerald-50/10 border-emerald-100">
          <div className="p-3 bg-emerald-50 text-emerald-500 rounded-lg">
            <CheckCircle className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-xs font-semibold uppercase tracking-wider text-slate-400">Filing Progression</span>
            <span className="text-xs font-bold text-slate-500 block mt-1">Smart sign-off upgrades status to "Ready to File" automatically.</span>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4.5 w-4.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by Client Name or Return Form..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-4 py-2 w-full text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-rose-500 bg-slate-50/30"
          />
        </div>

        <div className="flex items-center space-x-2">
          <select
            value={filterStaff}
            onChange={(e) => setFilterStaff(e.target.value)}
            className="text-xs border border-slate-300 rounded-lg px-3 py-2 bg-white font-semibold"
          >
            <option value="All">All Staff Partners</option>
            {staffList.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Dynamic Grid of Cards representing task checklists */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {docPendingTasks.length === 0 ? (
          <div className="col-span-2 p-12 bg-white rounded-xl border border-slate-200 text-center text-slate-400">
            <p className="text-sm font-semibold">Perfect! No compliance tasks are currently bottlenecked on missing client documents.</p>
            <p className="text-xs mt-1">All shared data is compiled and active filings are in progress.</p>
          </div>
        ) : (
          docPendingTasks.map((task) => (
            <div key={task.id} className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4 hover:shadow-sm transition-all flex flex-col justify-between">
              <div>
                {/* Header info */}
                <div className="flex items-start justify-between space-x-3">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-rose-500 bg-rose-50 px-2 py-0.5 rounded">
                      {task.serviceCategory}
                    </span>
                    <h3 className="font-extrabold text-slate-900 text-md mt-1.5 leading-tight">{getClientById(task.clientId)?.name || task.clientName}</h3>
                    <p className="text-xs text-slate-500 mt-1">
                      Return: <strong className="text-slate-700">{task.returnName}</strong> | Period: {task.filingPeriod}
                    </p>
                  </div>
                  <div className="text-right text-xs">
                    <span className="text-slate-400 font-bold block">Filing Due:</span>
                    <strong className="text-rose-600 block">{task.dueDate}</strong>
                  </div>
                </div>

                {/* Checklist box */}
                <div className="mt-4 pt-3 border-t border-slate-100">
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Outstanding Document Checklist ({task.documentsPending.length} pending)
                  </span>
                  
                  <div className="space-y-1.5 max-h-[140px] overflow-y-auto">
                    {task.documentsPending.map((doc) => (
                      <div
                        key={doc}
                        className="flex items-center justify-between p-2 rounded-md bg-slate-50 border border-slate-100 hover:bg-rose-50/20 hover:border-rose-100 transition-colors"
                      >
                        <span className="text-xs font-semibold text-slate-700">{doc}</span>
                        <button
                          onClick={() => handleReceiveDoc(task, doc)}
                          className="inline-flex items-center text-[10px] font-bold text-emerald-600 hover:text-emerald-700 bg-white border border-emerald-200 rounded px-2 py-0.5 shadow-2xs"
                        >
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Mark Received
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Staff Assignments info at bottom of card */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center font-medium">
                  <UserCheck className="w-3.5 h-3.5 mr-1" />
                  Assigned Staff: <strong className="text-slate-600 ml-1">{task.assignedStaffName}</strong>
                </span>
                <span className="font-semibold text-[#F5405E] bg-rose-50/50 px-2 py-0.5 rounded">
                  Status: {task.status}
                </span>
              </div>
            </div>
          ))
        )}
      </div>

    </div>
  );
}
