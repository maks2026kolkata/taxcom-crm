import React, { useState } from 'react';
import {
  Plus,
  Search,
  Filter,
  FileSpreadsheet,
  Download,
  Trash2,
  Edit2,
  UserCheck,
  Eye,
  EyeOff,
  Briefcase,
  SlidersHorizontal,
  X,
  Users,
  Power,
  ShieldAlert,
  AlertTriangle
} from 'lucide-react';
import {
  getClients,
  getStaff,
  createClient,
  updateClient,
  deleteClient,
  permanentlyDeleteClient,
  getTasks,
  getReminders,
  getReminderHistory,
  getAuditLogs,
  addAuditLog
} from '../db/storage';
import { Client, Staff } from '../types';
import { useToast } from '../components/Toast';
import ImportWizard from '../components/ImportWizard';
import { useAuth } from '../components/AuthContext';
import * as XLSX from 'xlsx';
import { isFirebaseEnabled, db } from '../db/firebase';
import { collection, getDocs } from 'firebase/firestore';

export default function Clients() {
  const { showToast } = useToast();
  const { currentUser } = useAuth();
  const [clients, setClients] = useState<Client[]>(() => getClients());
  const staffList = getStaff();

  React.useEffect(() => {
    const handleSync = () => {
      setClients(getClients());
    };
    window.addEventListener('database-sync', handleSync);
    return () => window.removeEventListener('database-sync', handleSync);
  }, []);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'All' | 'Active' | 'Inactive' | 'Archived'>('All');
  const [filterEntity, setFilterEntity] = useState<string>('All');
  const [filterStaff, setFilterStaff] = useState<string>('All');
  const [filterService, setFilterService] = useState<string>('All');
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);

  // Modal State
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDiscardModalOpen, setIsDiscardModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [isImportOpen, setIsImportOpen] = useState(false);

  // Form Field State
  const [formClientId, setFormClientId] = useState('');
  const [formName, setFormName] = useState('');
  const [formTradeName, setFormTradeName] = useState('');
  const [formEntityType, setFormEntityType] = useState('Proprietorship');
  const [formMobile, setFormMobile] = useState('');
  const [formWhatsapp, setFormWhatsapp] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formGstin, setFormGstin] = useState('');
  const [formPan, setFormPan] = useState('');
  const [formCinLlp, setFormCinLlp] = useState('');
  const [formFssai, setFormFssai] = useState('');
  const [formAddress, setFormAddress] = useState('');
  const [formAssignedStaff, setFormAssignedStaff] = useState('');
  const [formStatus, setFormStatus] = useState<'Active' | 'Inactive' | 'Archived'>('Active');
  const [formNotes, setFormNotes] = useState('');

  // Enhanced Field States
  const [formPrimaryContactPerson, setFormPrimaryContactPerson] = useState('');
  const [formState, setFormState] = useState('');
  const [formPinCode, setFormPinCode] = useState('');
  const [formServicesAvailed, setFormServicesAvailed] = useState<string[]>([]);
  const [formCustomFields, setFormCustomFields] = useState<Array<{ fieldName: string; fieldValue: string }>>([{ fieldName: '', fieldValue: '' }]);
  const [formPortalCredentials, setFormPortalCredentials] = useState<Array<{ portalName: string; customPortalName?: string; userId: string; password?: string }>>([]);
  const [visiblePasswords, setVisiblePasswords] = useState<Record<number, boolean>>({});
  const [sameAsMobile, setSameAsMobile] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Deletion Modal States
  const [clientToDelete, setClientToDelete] = useState<Client | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteConfirmationText, setDeleteConfirmationText] = useState('');
  const [isCheckingDependencies, setIsCheckingDependencies] = useState(false);
  const [isDeletingClient, setIsDeletingClient] = useState(false);
  const [dependencyCheckResult, setDependencyCheckResult] = useState<{
    hasDependencies: boolean;
    tasksCount: number;
    remindersCount: number;
    documentsCount: number;
    paymentsCount: number;
    filingHistoryCount: number;
    reportsCount: number;
    notesCount: number;
    activityLogsCount: number;
    historyCount: number;
    servicesCount: number;
    rawTasks: any[];
    rawPayments: any[];
    rawPayTx: any[];
    rawReminders: any[];
    rawDocs: any[];
    rawDocRecords: any[];
    rawAttachments: any[];
    rawFileMetadata: any[];
    rawHistory: any[];
    rawComm: any[];
    rawServices: any[];
  } | null>(null);

  // Edit / Load State
  const [isLoadingClientData, setIsLoadingClientData] = useState(false);

  const servicesList = [
    'GST',
    'Income Tax',
    'TDS',
    'MCA/ROC',
    'LLP',
    'FSSAI',
    'PF',
    'ESI',
    'Professional Tax',
    'Trade Licence',
    'DSC',
    'Trademark',
    'Udyam',
    'IEC',
    'Other'
  ];

  const handleMobileChange = (val: string) => {
    const numeric = val.replace(/\D/g, '');
    setFormMobile(numeric);
    if (sameAsMobile) {
      setFormWhatsapp(numeric);
    }
  };

  const handleSameAsMobileChange = (checked: boolean) => {
    setSameAsMobile(checked);
    if (checked) {
      setFormWhatsapp(formMobile);
    }
  };

  const handleAddCustomField = () => {
    setFormCustomFields([...formCustomFields, { fieldName: '', fieldValue: '' }]);
  };

  const handleRemoveCustomField = (index: number) => {
    setFormCustomFields(formCustomFields.filter((_, i) => i !== index));
  };

  const handleUpdateCustomField = (index: number, key: 'fieldName' | 'fieldValue', val: string) => {
    const updated = [...formCustomFields];
    updated[index][key] = val;
    setFormCustomFields(updated);
  };

  const handleAddPortalCredential = () => {
    setFormPortalCredentials([...formPortalCredentials, { portalName: 'GST', userId: '', password: '' }]);
  };

  const handleRemovePortalCredential = (index: number) => {
    setFormPortalCredentials(formPortalCredentials.filter((_, i) => i !== index));
    setVisiblePasswords(prev => {
      const updated = { ...prev };
      delete updated[index];
      return updated;
    });
  };

  const handleUpdatePortalCredential = (index: number, key: string, val: string) => {
    const updated = [...formPortalCredentials];
    updated[index] = { ...updated[index], [key]: val };
    setFormPortalCredentials(updated);
  };

  const togglePasswordVisibility = (index: number) => {
    setVisiblePasswords(prev => ({ ...prev, [index]: !prev[index] }));
  };

  const refreshList = () => {
    setClients(getClients());
  };

  const checkClientHasLinkedRecords = (client: Client): boolean => {
    const tasks = getTasks();
    const reminders = getReminders();
    const history = getReminderHistory();
    const auditLogs = getAuditLogs();
    
    const matches = (item: any) => {
      if (!item) return false;
      return item.clientId === client.id || item.clientId === client.clientId;
    };

    // 1. Compliance Tasks
    const clientTasks = tasks.filter(matches);
    const tasksCount = clientTasks.length;

    // 2. Reminders
    const clientReminders = reminders.filter(matches);
    const remindersCount = clientReminders.length + history.filter(matches).length;

    // 3. Documents
    const tasksWithDocs = clientTasks.filter(t => 
      (t.documentsRequired && t.documentsRequired.length > 0) || 
      (t.documentsPending && t.documentsPending.length > 0) ||
      (t.documentDetails && Object.keys(t.documentDetails).length > 0)
    );
    const documentsCount = tasksWithDocs.length;

    // 4. Payments
    const tasksWithReceived = clientTasks.filter(t => 
      t.amountReceived > 0 || 
      t.professionalFees > 0 || 
      (t.payments && t.payments.length > 0)
    );
    const paymentsCount = tasksWithReceived.length;

    // 5. GST/ITR Filing History
    const filingHistoryTasks = clientTasks.filter(t => 
      t.status === 'Filed' || 
      t.status === 'Completed' || 
      (t.filingDate && t.filingDate.trim() !== '') || 
      (t.acknowledgementNumber && t.acknowledgementNumber.trim() !== '')
    );
    const filingHistoryCount = filingHistoryTasks.length;

    // 6. Reports (references appearing in reports, e.g. tasks/reminders/payments)
    const reportsCount = clientTasks.length + paymentsCount + clientReminders.length;

    // 7. Notes
    const clientNotesCount = client.notes && client.notes.trim() ? 1 : 0;
    const taskNotesCount = clientTasks.filter(t => t.internalNotes && t.internalNotes.trim()).length;
    const notesHistoryCount = clientTasks.reduce((acc, t) => acc + (t.notesHistory?.length || 0), 0);
    const notesCount = clientNotesCount + taskNotesCount + notesHistoryCount;

    // 8. Activity Logs
    const clientTaskIds = new Set(clientTasks.map(t => t.id));
    const matchedAuditLogs = auditLogs.filter(log => 
      log.targetId === client.id || 
      log.targetId === client.clientId || 
      log.targetName === client.name ||
      clientTaskIds.has(log.targetId)
    );
    const activityLogsCount = matchedAuditLogs.length;

    return (
      tasksCount > 0 ||
      remindersCount > 0 ||
      documentsCount > 0 ||
      paymentsCount > 0 ||
      filingHistoryCount > 0 ||
      reportsCount > 0 ||
      notesCount > 0 ||
      activityLogsCount > 0
    );
  };

  const handleOpenCreateModal = () => {
    setEditingClient(null);
    setFormClientId(`TAX-${String(getClients().length + 1).padStart(3, '0')}`);
    setFormName('');
    setFormTradeName('');
    setFormEntityType('Proprietorship');
    setFormMobile('');
    setFormWhatsapp('');
    setFormEmail('');
    setFormGstin('');
    setFormPan('');
    setFormCinLlp('');
    setFormFssai('');
    setFormAddress('');
    setFormAssignedStaff(staffList[0]?.id || '');
    setFormStatus('Active');
    setFormNotes('');

    // Enhanced resets
    setFormPrimaryContactPerson('');
    setFormState('');
    setFormPinCode('');
    setFormServicesAvailed([]);
    setFormCustomFields([{ fieldName: '', fieldValue: '' }]);
    setFormPortalCredentials([]);
    setVisiblePasswords({});
    setSameAsMobile(false);
    setFormErrors({});
    setIsSubmitting(false);

    setIsFormOpen(true);
  };

  const handleOpenEditModal = (client: Client) => {
    setIsFormOpen(true);
    setIsLoadingClientData(true);
    
    setTimeout(() => {
      setEditingClient(client);
      setFormClientId(client.clientId);
      setFormName(client.name);
      setFormTradeName(client.tradeName || '');
      setFormEntityType(client.entityType);
      setFormMobile(client.mobileNumber || '');
      setFormWhatsapp(client.whatsappNumber || '');
      setFormEmail(client.emailAddress || '');
      setFormGstin(client.gstin || '');
      setFormPan(client.pan || '');
      setFormCinLlp(client.cinOrLlpin || '');
      setFormFssai(client.fssaiNumber || '');
      setFormAddress(client.address || '');
      setFormAssignedStaff(client.assignedStaffId || '');
      setFormStatus(client.status);
      setFormNotes(client.notes || '');

      // Enhanced populates
      setFormPrimaryContactPerson(client.primaryContactPerson || '');
      setFormState(client.state || '');
      setFormPinCode(client.pinCode || '');
      setFormServicesAvailed(client.servicesAvailed || []);
      setFormCustomFields(client.customFields && client.customFields.length > 0 ? client.customFields : [{ fieldName: '', fieldValue: '' }]);
      setFormPortalCredentials(client.portalCredentials && client.portalCredentials.length > 0 ? client.portalCredentials : []);
      setVisiblePasswords({});
      setSameAsMobile(client.mobileNumber && client.mobileNumber === client.whatsappNumber ? true : false);
      setFormErrors({});
      setIsSubmitting(false);
      setIsLoadingClientData(false);
    }, 450);
  };

  const hasUnsavedChanges = (): boolean => {
    if (!editingClient) {
      return false;
    }
    if (formName !== editingClient.name) return true;
    if (formTradeName !== (editingClient.tradeName || '')) return true;
    if (formEntityType !== editingClient.entityType) return true;
    if (formMobile !== (editingClient.mobileNumber || '')) return true;
    if (formWhatsapp !== (editingClient.whatsappNumber || '')) return true;
    if (formEmail !== (editingClient.emailAddress || '')) return true;
    if (formGstin !== (editingClient.gstin || '')) return true;
    if (formPan !== (editingClient.pan || '')) return true;
    if (formCinLlp !== (editingClient.cinOrLlpin || '')) return true;
    if (formFssai !== (editingClient.fssaiNumber || '')) return true;
    if (formAddress !== (editingClient.address || '')) return true;
    if (formAssignedStaff !== (editingClient.assignedStaffId || '')) return true;
    if (formStatus !== editingClient.status) return true;
    if (formNotes !== (editingClient.notes || '')) return true;
    if (formPrimaryContactPerson !== (editingClient.primaryContactPerson || '')) return true;
    if (formState !== (editingClient.state || '')) return true;
    if (formPinCode !== (editingClient.pinCode || '')) return true;

    const oldServices = editingClient.servicesAvailed || [];
    if (JSON.stringify([...oldServices].sort()) !== JSON.stringify([...formServicesAvailed].sort())) return true;

    const cleanedCustomFields = formCustomFields.filter(cf => cf.fieldName.trim() || cf.fieldValue.trim());
    const oldCustomFields = editingClient.customFields || [];
    if (JSON.stringify(cleanedCustomFields) !== JSON.stringify(oldCustomFields)) return true;

    const cleanedPortalCredentials = formPortalCredentials.filter(pc => pc.userId.trim() || (pc.password && pc.password.trim()));
    const oldPortalCredentials = editingClient.portalCredentials || [];
    if (JSON.stringify(cleanedPortalCredentials) !== JSON.stringify(oldPortalCredentials)) return true;

    return false;
  };

  const handleCloseModal = () => {
    if (editingClient && hasUnsavedChanges()) {
      setIsDiscardModalOpen(true);
      return;
    }
    setIsFormOpen(false);
  };
  
  const confirmDiscardChanges = () => {
    setIsDiscardModalOpen(false);
    setIsFormOpen(false);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormErrors({});

    const errors: Record<string, string> = {};

    // 1. Client Legal Name (Required)
    if (!formName.trim()) {
      errors.name = 'Client Legal Name is required.';
    }

    // 2. Client ID/Code (Required)
    if (!formClientId.trim()) {
      errors.clientId = 'Client Code is required.';
    }

    // 3. Mobile Number (Optional, but must be exactly 10 digits if provided)
    if (formMobile.trim()) {
      if (!/^\d{10}$/.test(formMobile.trim())) {
        errors.mobile = 'Mobile number must be exactly 10 digits.';
      }
    }

    // 4. WhatsApp Number (Optional, but must be exactly 10 digits if provided)
    if (formWhatsapp.trim()) {
      if (!/^\d{10}$/.test(formWhatsapp.trim())) {
        errors.whatsapp = 'WhatsApp number must be exactly 10 digits.';
      }
    }

    // 5. GSTIN (Optional, but must match standard 15-character format if provided)
    if (formGstin.trim()) {
      const gstinRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/i;
      if (!gstinRegex.test(formGstin.trim())) {
        errors.gstin = 'GSTIN must follow 15-character GST format (e.g., 27AAAAA1111A1Z1).';
      }
    }

    // 6. PAN (Optional, but must follow 10-character PAN format if provided)
    if (formPan.trim()) {
      const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/i;
      if (!panRegex.test(formPan.trim())) {
        errors.pan = 'PAN must follow 10-character PAN format (e.g., ABCDE1234F).';
      }
    }

    // 7. FSSAI License No. (Optional, must be exactly 14 digits if provided)
    if (formFssai.trim()) {
      if (!/^\d{14}$/.test(formFssai.trim())) {
        errors.fssai = 'FSSAI number must be exactly 14 digits.';
      }
    }

    // 8. CIN/LLPIN (Optional, must be 21 chars for CIN or 7-8 chars for LLPIN)
    if (formCinLlp.trim()) {
      const isCin = /^[A-Z0-9]{21}$/i.test(formCinLlp.trim());
      const isLlpin = /^[A-Z0-9]{7,8}$/i.test(formCinLlp.trim());
      if (!isCin && !isLlpin) {
        errors.cinLlp = 'CIN must be 21 alphanumeric characters, or LLPIN must be 7-8 alphanumeric characters.';
      }
    }

    // 9. Prevent duplicate GSTIN, PAN, mobile number and email
    const allClients = getClients();
    allClients.forEach((otherClient) => {
      // Skip the client currently being edited
      if (editingClient && otherClient.id === editingClient.id) {
        return;
      }

      if (formClientId.trim() && otherClient.clientId && otherClient.clientId.trim().toUpperCase() === formClientId.trim().toUpperCase()) {
        errors.clientId = 'A client with this Client Code already exists.';
      }
      if (formGstin.trim() && otherClient.gstin && otherClient.gstin.trim().toUpperCase() === formGstin.trim().toUpperCase()) {
        errors.gstin = 'A client with this GSTIN already exists.';
      }
      if (formPan.trim() && otherClient.pan && otherClient.pan.trim().toUpperCase() === formPan.trim().toUpperCase()) {
        errors.pan = 'A client with this PAN already exists.';
      }
      if (formMobile.trim() && otherClient.mobileNumber && otherClient.mobileNumber.trim() === formMobile.trim()) {
        errors.mobile = 'A client with this mobile number already exists.';
      }
      if (formEmail.trim() && otherClient.emailAddress && otherClient.emailAddress.trim().toLowerCase() === formEmail.trim().toLowerCase()) {
        errors.email = 'A client with this email address already exists.';
      }
    });

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      showToast('Please fix the validation errors before submitting.', 'error');
      return;
    }

    // Set loading state
    setIsSubmitting(true);

    try {
      // Filter out empty custom fields to keep database clean
      const cleanedCustomFields = formCustomFields.filter(cf => cf.fieldName.trim() || cf.fieldValue.trim());

      const cleanedPortalCredentials = formPortalCredentials
        .filter(pc => pc.userId.trim() || (pc.password && pc.password.trim()))
        .map(pc => ({
          portalName: pc.portalName,
          customPortalName: pc.portalName === 'Other' ? pc.customPortalName : undefined,
          userId: pc.userId,
          password: pc.password
        }));

      const payload = {
        clientId: formClientId,
        name: formName,
        tradeName: formTradeName,
        entityType: formEntityType,
        mobileNumber: formMobile || undefined,
        whatsappNumber: formWhatsapp || undefined,
        emailAddress: formEmail || undefined,
        gstin: formGstin || undefined,
        pan: formPan || undefined,
        cinOrLlpin: formCinLlp || undefined,
        fssaiNumber: formFssai || undefined,
        address: formAddress || undefined,
        assignedStaffId: formAssignedStaff || undefined,
        status: formStatus,
        notes: formNotes || undefined,
        // Enhanced optional fields
        primaryContactPerson: formPrimaryContactPerson || undefined,
        state: formState || undefined,
        pinCode: formPinCode || undefined,
        servicesAvailed: formServicesAvailed,
        customFields: cleanedCustomFields,
        portalCredentials: cleanedPortalCredentials,
      };

      if (editingClient) {
        const oldValuesList: string[] = [];
        const newValuesList: string[] = [];

        const fieldsToCompare: (keyof Client)[] = [
          'clientId', 'name', 'tradeName', 'entityType', 'mobileNumber', 
          'whatsappNumber', 'emailAddress', 'gstin', 'pan', 'cinOrLlpin', 
          'fssaiNumber', 'address', 'assignedStaffId', 'status', 'notes',
          'primaryContactPerson', 'state', 'pinCode'
        ];

        fieldsToCompare.forEach(f => {
          const oldVal = editingClient[f];
          const newVal = payload[f as keyof typeof payload];
          if (oldVal !== newVal) {
            oldValuesList.push(`${String(f)}: ${oldVal ?? 'None'}`);
            newValuesList.push(`${String(f)}: ${newVal ?? 'None'}`);
          }
        });

        const oldServices = editingClient.servicesAvailed || [];
        const newServices = payload.servicesAvailed || [];
        if (JSON.stringify([...oldServices].sort()) !== JSON.stringify([...newServices].sort())) {
          oldValuesList.push(`servicesAvailed: [${oldServices.join(', ')}]`);
          newValuesList.push(`servicesAvailed: [${newServices.join(', ')}]`);
        }

        const oldCustom = editingClient.customFields || [];
        const newCustom = payload.customFields || [];
        if (JSON.stringify(oldCustom) !== JSON.stringify(newCustom)) {
          oldValuesList.push(`customFields: ${JSON.stringify(oldCustom)}`);
          newValuesList.push(`customFields: ${JSON.stringify(newCustom)}`);
        }

        const oldCreds = editingClient.portalCredentials || [];
        const newCreds = payload.portalCredentials || [];
        if (JSON.stringify(oldCreds) !== JSON.stringify(newCreds)) {
          oldValuesList.push(`portalCredentials: ${JSON.stringify(oldCreds)}`);
          newValuesList.push(`portalCredentials: ${JSON.stringify(newCreds)}`);
        }

        const oldValuesStr = oldValuesList.join(' | ') || 'No changes';
        const newValuesStr = newValuesList.join(' | ') || 'No changes';

        updateClient(editingClient.id, payload);
        
        addAuditLog(
          'Client Modified Deep Log',
          editingClient.id,
          editingClient.name,
          oldValuesStr,
          newValuesStr
        );

        showToast('Client updated successfully.', 'success');
      } else {
        createClient(payload);
        showToast(`Successfully created new client: ${formName}`, 'success');
      }

      setIsFormOpen(false);
      refreshList();
    } catch (err: any) {
      showToast(`Failed to save: ${err.message}`, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Helper to query any Firestore collection gracefully
  const fetchFirestoreCollection = async (collectionName: string): Promise<any[]> => {
    if (!isFirebaseEnabled || !db) return [];
    try {
      const colRef = collection(db, collectionName);
      const snap = await getDocs(colRef);
      const items: any[] = [];
      snap.forEach(doc => {
        items.push({ id: doc.id, ...doc.data() });
      });
      return items;
    } catch (error) {
      console.warn(`Could not fetch Firestore collection "${collectionName}":`, error);
      return [];
    }
  };

  // Helper to load any local storage collection gracefully
  const fetchLocalStorageCollection = (keyName: string): any[] => {
    try {
      const data = localStorage.getItem(keyName);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn(`Could not load local storage key "${keyName}":`, e);
    }
    return [];
  };

  // Get comprehensive live dependency statistics for a client
  const getLiveDependencyStats = async (client: Client) => {
    // Gather all collections in parallel to speed up checking
    const [
      fsTasks,
      fsPayments,
      fsPaymentTransactions,
      fsReminders,
      fsDocuments,
      fsDocRecords,
      fsAttachments,
      fsFileMetadata,
      fsHistory,
      fsCommHistory,
      fsClientServices,
      fsAuditLogs,
    ] = await Promise.all([
      fetchFirestoreCollection('tasks'),
      fetchFirestoreCollection('payments'),
      fetchFirestoreCollection('payment_transactions'),
      fetchFirestoreCollection('reminders'),
      fetchFirestoreCollection('documents'),
      fetchFirestoreCollection('document_records'),
      fetchFirestoreCollection('attachments'),
      fetchFirestoreCollection('uploaded_file_metadata'),
      fetchFirestoreCollection('reminder_history'),
      fetchFirestoreCollection('communication_history'),
      fetchFirestoreCollection('client_services'),
      fetchFirestoreCollection('audit_logs'),
    ]);

    const lsTasks = fetchLocalStorageCollection('taxcom_tasks');
    const lsTasksAlt = fetchLocalStorageCollection('tasks');
    const lsPayments = fetchLocalStorageCollection('taxcom_payments');
    const lsPaymentsAlt = fetchLocalStorageCollection('payments');
    const lsPayTx = fetchLocalStorageCollection('taxcom_payment_transactions');
    const lsPayTxAlt = fetchLocalStorageCollection('payment_transactions');
    const lsReminders = fetchLocalStorageCollection('taxcom_reminders');
    const lsRemindersAlt = fetchLocalStorageCollection('reminders');
    const lsDocs = fetchLocalStorageCollection('taxcom_documents');
    const lsDocsAlt = fetchLocalStorageCollection('documents');
    const lsDocRecs = fetchLocalStorageCollection('taxcom_document_records');
    const lsDocRecsAlt = fetchLocalStorageCollection('document_records');
    const lsAttach = fetchLocalStorageCollection('taxcom_attachments');
    const lsAttachAlt = fetchLocalStorageCollection('attachments');
    const lsMeta = fetchLocalStorageCollection('taxcom_uploaded_file_metadata');
    const lsMetaAlt = fetchLocalStorageCollection('uploaded_file_metadata');
    const lsHistory = fetchLocalStorageCollection('taxcom_reminder_history');
    const lsHistoryAlt = fetchLocalStorageCollection('reminder_history');
    const lsComm = fetchLocalStorageCollection('taxcom_communication_history');
    const lsCommAlt = fetchLocalStorageCollection('communication_history');
    const lsServs = fetchLocalStorageCollection('taxcom_client_services');
    const lsServsAlt = fetchLocalStorageCollection('client_services');
    const lsAuditLogs = fetchLocalStorageCollection('taxcom_audit_logs');
    const lsAuditLogsAlt = fetchLocalStorageCollection('audit_logs');

    // Helper to combine and deduplicate elements by ID if available
    const combine = (fsList: any[], lsList1: any[], lsList2: any[]) => {
      const map = new Map<string, any>();
      const items = [...fsList, ...lsList1, ...lsList2];
      items.forEach((item, index) => {
        const id = item.id || `item-${index}`;
        map.set(id, item);
      });
      return Array.from(map.values());
    };

    const allTasks = combine(fsTasks, lsTasks, lsTasksAlt).filter(t => !t.isDeleted);
    const allPayments = combine(fsPayments, lsPayments, lsPaymentsAlt);
    const allPayTx = combine(fsPaymentTransactions, lsPayTx, lsPayTxAlt);
    const allReminders = combine(fsReminders, lsReminders, lsRemindersAlt);
    const allDocuments = combine(fsDocuments, lsDocs, lsDocsAlt);
    const allDocRecords = combine(fsDocRecords, lsDocRecs, lsDocRecsAlt);
    const allAttachments = combine(fsAttachments, lsAttach, lsAttachAlt);
    const allFileMetadata = combine(fsFileMetadata, lsMeta, lsMetaAlt);
    const allHistory = combine(fsHistory, lsHistory, lsHistoryAlt);
    const allComm = combine(fsCommHistory, lsComm, lsCommAlt);
    const allClientServices = combine(fsClientServices, lsServs, lsServsAlt);
    const allAuditLogs = combine(fsAuditLogs, lsAuditLogs, lsAuditLogsAlt);

    // Helper matching clientId or id
    const matches = (item: any) => {
      if (!item) return false;
      return item.clientId === client.id || item.clientId === client.clientId;
    };

    // 1. Compliance Tasks
    const clientTasks = allTasks.filter(matches);
    const tasksCount = clientTasks.length;

    // 2. Reminders
    const clientReminders = allReminders.filter(matches);
    const remindersCount = clientReminders.length + allHistory.filter(matches).length;

    // 3. Documents
    const matchedDocs = allDocuments.filter(matches);
    const matchedDocRecords = allDocRecords.filter(matches);
    const matchedAttachments = allAttachments.filter(matches);
    const matchedFileMetadata = allFileMetadata.filter(matches);
    const tasksWithDocs = clientTasks.filter(t => 
      (t.documentsRequired && t.documentsRequired.length > 0) || 
      (t.documentsPending && t.documentsPending.length > 0) ||
      (t.documentDetails && Object.keys(t.documentDetails).length > 0)
    );
    const documentsCount = matchedDocs.length + matchedDocRecords.length + matchedAttachments.length + matchedFileMetadata.length + tasksWithDocs.length;

    // 4. Payments
    const matchedPayments = allPayments.filter(matches);
    const matchedPayTx = allPayTx.filter(matches);
    const tasksWithReceived = clientTasks.filter(t => t.amountReceived > 0 || t.professionalFees > 0 || (t.payments && t.payments.length > 0));
    const paymentsCount = matchedPayments.length + matchedPayTx.length + tasksWithReceived.length;

    // 5. GST/ITR Filing History
    const filingHistoryTasks = clientTasks.filter(t => 
      t.status === 'Filed' || 
      t.status === 'Completed' || 
      (t.filingDate && t.filingDate.trim() !== '') || 
      (t.acknowledgementNumber && t.acknowledgementNumber.trim() !== '')
    );
    const filingHistoryCount = filingHistoryTasks.length;

    // 6. Reports (references appearing in reports, e.g. tasks/reminders/payments)
    const reportsCount = clientTasks.length + paymentsCount + clientReminders.length;

    // 7. Notes
    const clientNotesCount = client.notes && client.notes.trim() ? 1 : 0;
    const taskNotesCount = clientTasks.filter(t => t.internalNotes && t.internalNotes.trim()).length;
    const notesHistoryCount = clientTasks.reduce((acc, t) => acc + (t.notesHistory?.length || 0), 0);
    const notesCount = clientNotesCount + taskNotesCount + notesHistoryCount;

    // 8. Activity Logs
    const clientTaskIds = new Set(clientTasks.map(t => t.id));
    const matchedAuditLogs = allAuditLogs.filter(log => 
      log.targetId === client.id || 
      log.targetId === client.clientId || 
      log.targetName === client.name ||
      clientTaskIds.has(log.targetId)
    );
    const activityLogsCount = matchedAuditLogs.length;

    const hasDeps = 
      tasksCount > 0 || 
      remindersCount > 0 || 
      documentsCount > 0 || 
      paymentsCount > 0 || 
      filingHistoryCount > 0 || 
      reportsCount > 0 || 
      notesCount > 0 || 
      activityLogsCount > 0;

    return {
      hasDependencies: hasDeps,
      tasksCount,
      remindersCount,
      documentsCount,
      paymentsCount,
      filingHistoryCount,
      reportsCount,
      notesCount,
      activityLogsCount,
      historyCount: allHistory.filter(matches).length + allComm.filter(matches).length,
      servicesCount: allClientServices.filter(matches).length + (client.servicesAvailed?.length || 0),
      rawTasks: clientTasks,
      rawPayments: matchedPayments,
      rawPayTx: matchedPayTx,
      rawReminders: clientReminders,
      rawDocs: matchedDocs,
      rawDocRecords: matchedDocRecords,
      rawAttachments: matchedAttachments,
      rawFileMetadata: matchedFileMetadata,
      rawHistory: allHistory.filter(matches),
      rawComm: allComm.filter(matches),
      rawServices: allClientServices.filter(matches),
    };
  };

  const handleDeleteClick = (client: Client) => {
    setClientToDelete(client);
    setDeleteConfirmationText('');
    setDependencyCheckResult(null);
    setIsDeleteModalOpen(true);
    setIsCheckingDependencies(true);

    getLiveDependencyStats(client)
      .then((res) => {
        setDependencyCheckResult(res);
        setIsCheckingDependencies(false);
      })
      .catch((err) => {
        console.error("Error checking dependencies:", err);
        setIsCheckingDependencies(false);
      });
  };

  const handleDeactivateClientInModal = () => {
    if (!clientToDelete) return;
    updateClient(clientToDelete.id, { status: 'Inactive' });
    showToast('Client deactivated successfully.', 'success');
    setIsDeleteModalOpen(false);
    setClientToDelete(null);
    refreshList();
  };

  const handlePermanentDeleteSubmit = async () => {
    if (!clientToDelete) return;
    setIsDeletingClient(true);
    try {
      // 5. Run a fresh dependency query immediately before permanent deletion
      const freshDeps = await getLiveDependencyStats(clientToDelete);
      
      // 6. Ensure the operation is protected against a race condition
      if (freshDeps.hasDependencies) {
        showToast("This client cannot be deleted because compliance records exist. Please deactivate or archive the client instead.", "error");
        setDependencyCheckResult(freshDeps); // Update UI to reflect the new counts
        setIsDeletingClient(false);
        return;
      }

      permanentlyDeleteClient(clientToDelete.id);
      showToast('Client deleted successfully.', 'success');
      setIsDeleteModalOpen(false);
      setClientToDelete(null);
      refreshList();
    } catch (err: any) {
      showToast(`Delete failed: ${err.message}`, 'error');
    } finally {
      setIsDeletingClient(false);
    }
  };

  const handleDownloadBackup = async () => {
    if (!clientToDelete) return;
    try {
      showToast('Generating client backup...', 'info');
      const stats = await getLiveDependencyStats(clientToDelete);

      const workbook = XLSX.utils.book_new();

      // Helper function to create sheet and preserve text format
      const createSheetWithTextPreservation = (data: any[]) => {
        if (data.length === 0) {
          return XLSX.utils.json_to_sheet([{ Message: 'No records found' }]);
        }
        const headers = Object.keys(data[0]);
        const aoa = [headers];
        data.forEach(row => {
          aoa.push(headers.map(h => {
            const val = row[h];
            return val === undefined || val === null ? '' : val;
          }));
        });
        const ws = XLSX.utils.aoa_to_sheet(aoa);

        // Explicitly numeric/monetary fields
        const numericFields = ['fees', 'amount', 'received', 'outstanding', 'balance', 'rate', 'count'];
        const colIndicesToKeepNumeric = headers.map((h, idx) => {
          const low = h.toLowerCase();
          const isNumeric = numericFields.some(nf => low.includes(nf));
          return isNumeric ? idx : -1;
        }).filter(idx => idx !== -1);

        const refVal = ws['!ref'];
        if (refVal) {
          const range = XLSX.utils.decode_range(refVal);
          for (let r = range.s.r + 1; r <= range.e.r; ++r) {
            for (let c = range.s.c; c <= range.e.c; ++c) {
              if (colIndicesToKeepNumeric.includes(c)) {
                const cellAddress = XLSX.utils.encode_cell({ r, c });
                const cell = ws[cellAddress];
                if (cell && cell.v !== '') {
                  cell.t = 'n';
                  cell.v = Number(cell.v);
                }
              } else {
                const cellAddress = XLSX.utils.encode_cell({ r, c });
                const cell = ws[cellAddress];
                if (cell) {
                  cell.t = 's';
                  cell.v = String(cell.v);
                }
              }
            }
          }
        }
        return ws;
      };

      // 1. Profile sheet
      const profileData = [
        { Field: 'Client ID', Value: clientToDelete.clientId || '' },
        { Field: 'Legal Name', Value: clientToDelete.name || '' },
        { Field: 'Trade Name', Value: clientToDelete.tradeName || '' },
        { Field: 'Entity Type', Value: clientToDelete.entityType || '' },
        { Field: 'Mobile Number', Value: clientToDelete.mobileNumber || '' },
        { Field: 'WhatsApp Number', Value: clientToDelete.whatsappNumber || '' },
        { Field: 'Email Address', Value: clientToDelete.emailAddress || '' },
        { Field: 'GSTIN', Value: clientToDelete.gstin || '' },
        { Field: 'PAN', Value: clientToDelete.pan || '' },
        { Field: 'CIN / LLPIN', Value: clientToDelete.cinOrLlpin || '' },
        { Field: 'FSSAI Number', Value: clientToDelete.fssaiNumber || '' },
        { Field: 'Address', Value: clientToDelete.address || '' },
        { Field: 'Primary Contact Person', Value: clientToDelete.primaryContactPerson || '' },
        { Field: 'State', Value: clientToDelete.state || '' },
        { Field: 'Pincode', Value: clientToDelete.pinCode || '' },
        { Field: 'Status', Value: clientToDelete.status || '' },
        { Field: 'Notes', Value: clientToDelete.notes || '' },
        { Field: 'Created At', Value: clientToDelete.createdAt || '' },
      ];
      const wsProfile = createSheetWithTextPreservation(profileData);
      XLSX.utils.book_append_sheet(workbook, wsProfile, 'Profile');

      // 2. Compliance Tasks sheet
      const tasksData = stats.rawTasks.map(t => ({
        'Task ID': t.id,
        'Service Category': t.serviceCategory || '',
        'Return Name': t.returnName || '',
        'Filing Period': t.filingPeriod || '',
        'Due Date': t.dueDate || '',
        'Status': t.status || '',
        'Priority': t.priority || '',
        'Professional Fees': t.professionalFees || 0,
        'Amount Received': t.amountReceived || 0,
        'Outstanding Amount': t.outstandingAmount || 0,
        'Payment Status': t.paymentStatus || '',
      }));
      const wsTasks = createSheetWithTextPreservation(tasksData);
      XLSX.utils.book_append_sheet(workbook, wsTasks, 'Compliance Tasks');

      // 3. Payments sheet
      const paymentsData: any[] = [];
      stats.rawPayments.forEach(p => {
        paymentsData.push({
          'Payment ID': p.id || '',
          'Amount': p.amount || 0,
          'Date': p.date || p.createdAt || '',
          'Method': p.method || '',
          'Reference Number': p.referenceNumber || p.refNo || '',
          'Notes': p.notes || '',
        });
      });
      stats.rawPayTx.forEach(pt => {
        paymentsData.push({
          'Payment ID': pt.id || '',
          'Amount': pt.amount || 0,
          'Date': pt.date || pt.createdAt || '',
          'Method': pt.method || '',
          'Reference Number': pt.referenceNumber || pt.refNo || '',
          'Notes': pt.notes || '',
        });
      });
      stats.rawTasks.forEach(t => {
        if (t.amountReceived > 0) {
          paymentsData.push({
            'Payment ID': `Task Payment (${t.id})`,
            'Amount': t.amountReceived,
            'Date': t.lastPaymentDate || 'N/A',
            'Method': 'Recorded on Task',
            'Reference Number': t.returnName || '',
            'Notes': `Filing Period: ${t.filingPeriod}`,
          });
        }
      });
      const wsPayments = createSheetWithTextPreservation(paymentsData);
      XLSX.utils.book_append_sheet(workbook, wsPayments, 'Payments');

      // 4. Reminders sheet
      const remindersData = stats.rawReminders.map(r => ({
        'Reminder ID': r.id,
        'Task Name': r.taskName || '',
        'Service Category': r.serviceCategory || '',
        'Due Date': r.dueDate || '',
        'Interval Type': r.intervalType || '',
        'Status': r.status || '',
      }));
      const wsReminders = createSheetWithTextPreservation(remindersData);
      XLSX.utils.book_append_sheet(workbook, wsReminders, 'Reminders');

      // 5. Documents sheet
      const documentsData: any[] = [];
      stats.rawDocs.forEach(d => {
        documentsData.push({
          'Document ID': d.id || '',
          'Name': d.name || d.fileName || '',
          'Type': d.type || '',
          'Uploaded At': d.uploadedAt || d.createdAt || '',
          'Status': d.status || '',
          'Size': d.size || '',
          'Reference': d.referenceNumber || '',
        });
      });
      stats.rawDocRecords.forEach(dr => {
        documentsData.push({
          'Document ID': dr.id || '',
          'Name': dr.name || dr.fileName || '',
          'Type': dr.type || '',
          'Uploaded At': dr.uploadedAt || dr.createdAt || '',
          'Status': dr.status || '',
          'Size': dr.size || '',
          'Reference': dr.referenceNumber || '',
        });
      });
      stats.rawAttachments.forEach(a => {
        documentsData.push({
          'Document ID': a.id || '',
          'Name': a.name || a.fileName || '',
          'Type': 'Attachment',
          'Uploaded At': a.uploadedAt || a.createdAt || '',
          'Status': 'Received',
          'Size': a.size || '',
          'Reference': a.referenceNumber || '',
        });
      });
      stats.rawFileMetadata.forEach(fm => {
        documentsData.push({
          'Document ID': fm.id || '',
          'Name': fm.name || fm.fileName || '',
          'Type': 'Uploaded File Metadata',
          'Uploaded At': fm.uploadedAt || fm.createdAt || '',
          'Status': 'Received',
          'Size': fm.size || '',
          'Reference': fm.referenceNumber || '',
        });
      });
      stats.rawTasks.forEach(t => {
        if (t.documentsRequired && t.documentsRequired.length > 0) {
          t.documentsRequired.forEach(docName => {
            const isPending = t.documentsPending?.includes(docName);
            documentsData.push({
              'Document ID': `Task Req (${t.id})`,
              'Name': docName,
              'Type': 'Task Requirement',
              'Uploaded At': 'N/A',
              'Status': isPending ? 'Pending' : 'Received',
              'Size': 'N/A',
              'Reference': t.returnName,
            });
          });
        }
      });
      const wsDocuments = createSheetWithTextPreservation(documentsData);
      XLSX.utils.book_append_sheet(workbook, wsDocuments, 'Documents');

      // 6. Communication History sheet
      const commData: any[] = [];
      stats.rawHistory.forEach(h => {
        commData.push({
          'Log ID': h.id,
          'Task Name': h.taskName || '',
          'Sent Method': h.sentMethod || '',
          'Sent Date Time': h.sentDateTime || h.createdAt || '',
          'Sent By': h.sentBy || '',
          'Remarks': h.remarks || '',
        });
      });
      stats.rawComm.forEach(c => {
        commData.push({
          'Log ID': c.id,
          'Task Name': c.taskName || '',
          'Sent Method': c.sentMethod || '',
          'Sent Date Time': c.sentDateTime || c.createdAt || '',
          'Sent By': c.sentBy || '',
          'Remarks': c.remarks || '',
        });
      });
      const wsComm = createSheetWithTextPreservation(commData);
      XLSX.utils.book_append_sheet(workbook, wsComm, 'Communication History');

      // 7. Assigned Services sheet
      const servicesData: any[] = [];
      stats.rawServices.forEach(s => {
        servicesData.push({
          'Service Name': s.serviceName || s.name || '',
          'Assigned At': s.assignedAt || s.createdAt || '',
          'Status': s.status || 'Active',
        });
      });
      if (clientToDelete.servicesAvailed && clientToDelete.servicesAvailed.length > 0) {
        clientToDelete.servicesAvailed.forEach(s => {
          servicesData.push({
            'Service Name': s,
            'Assigned At': clientToDelete.createdAt || '',
            'Status': 'Active',
          });
        });
      }
      const wsServices = createSheetWithTextPreservation(servicesData);
      XLSX.utils.book_append_sheet(workbook, wsServices, 'Assigned Services');

      // 8. Custom Fields sheet
      const customFieldsData = (clientToDelete.customFields || []).map(f => ({
        'Field Label': f.fieldName || '',
        'Field Value': f.fieldValue || '',
      }));
      const wsCustomFields = createSheetWithTextPreservation(customFieldsData);
      XLSX.utils.book_append_sheet(workbook, wsCustomFields, 'Custom Fields');

      XLSX.writeFile(workbook, `client_backup_${clientToDelete.clientId || 'data'}_${new Date().toISOString().split('T')[0]}.xlsx`);
      showToast('Client backup exported successfully!', 'success');
    } catch (err: any) {
      showToast(`Backup failed: ${err.message}`, 'error');
    }
  };

  const handleToggleStatus = (client: Client) => {
    if ((client.status === 'Inactive' || client.status === 'Archived') && currentUser?.role !== 'Admin') {
      showToast('Only Administrators can reactivate inactive or archived client records.', 'error');
      return;
    }
    
    const newStatus = client.status === 'Active' ? 'Inactive' : 'Active';
    updateClient(client.id, { status: newStatus });
    showToast(`Client ${newStatus === 'Active' ? 'activated' : 'deactivated'} successfully.`, 'success');
    refreshList();
  };

  // EXPORT TO EXCEL
  const handleExportExcel = () => {
    try {
      const dataToExport = filteredClients.map(c => {
        const staffName = c.assignedStaffName || 'Unassigned';
        const portalUrl = c.portalCredentials?.map(pc => pc.portalUrl || '').join(' | ') || '';
        const portalUserId = c.portalCredentials?.map(pc => pc.userId).join(' | ') || '';
        const portalPassword = c.portalCredentials?.map(pc => pc.password || '').join(' | ') || '';
        
        return {
          'Client ID': c.clientId,
          'Client Name': c.name,
          'Trade Name': c.tradeName || '',
          'Entity Type': c.entityType,
          'Mobile': c.mobileNumber || '',
          'WhatsApp': c.whatsappNumber || '',
          'Email': c.emailAddress || '',
          'GSTIN': c.gstin || '',
          'PAN': c.pan || '',
          'CIN / LLPIN': c.cinOrLlpin || '',
          'FSSAI': c.fssaiNumber || '',
          'Assigned Staff': staffName,
          'Status': c.status,
          'Notes': c.notes || '',
          'Portal Login URL': portalUrl,
          'User ID': portalUserId,
          'Password': portalPassword
        };
      });

      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Clients');
      XLSX.writeFile(workbook, `taxcom_clients_${new Date().toISOString().split('T')[0]}.xlsx`);
      showToast('Clients list exported as Excel workbook successfully!', 'success');
    } catch (err: any) {
      showToast(`Export failed: ${err.message}`, 'error');
    }
  };

  // EXCEL / CSV IMPORT WIZARD HANDLER
  const importFieldsDefinition = [
    { key: 'clientId', label: 'Client ID', required: true },
    { key: 'name', label: 'Client Name', required: true },
    { key: 'tradeName', label: 'Trade Name', required: false },
    { key: 'entityType', label: 'Entity Type', required: true },
    { key: 'mobileNumber', label: 'Mobile Number', required: false },
    { key: 'whatsappNumber', label: 'WhatsApp Number', required: false },
    { key: 'emailAddress', label: 'Email Address', required: false, validation: (val: string) => !val.includes('@') ? 'Invalid email layout' : null },
    { key: 'gstin', label: 'GSTIN', required: false, validation: (val: string) => val.length !== 15 ? 'GSTIN must be 15 chars' : null },
    { key: 'pan', label: 'PAN', required: false, validation: (val: string) => val.length !== 10 ? 'PAN must be 10 chars' : null },
    { key: 'cinOrLlpin', label: 'CIN or LLPIN', required: false },
    { key: 'fssaiNumber', label: 'FSSAI Number', required: false },
    { key: 'address', label: 'Address', required: false },
    { key: 'notes', label: 'Notes', required: false },
  ];

  const handleImportedData = (data: any[]) => {
    data.forEach((row) => {
      // Map to proper types
      const payload = {
        clientId: row.clientId || `TAX-IMP-${Math.random().toString(36).substr(2, 4).toUpperCase()}`,
        name: row.name,
        tradeName: row.tradeName || '',
        entityType: row.entityType || 'Proprietorship',
        mobileNumber: row.mobileNumber || undefined,
        whatsappNumber: row.whatsappNumber || undefined,
        emailAddress: row.emailAddress || undefined,
        gstin: row.gstin || undefined,
        pan: row.pan || undefined,
        cinOrLlpin: row.cinOrLlpin || undefined,
        fssaiNumber: row.fssaiNumber || undefined,
        address: row.address || undefined,
        assignedStaffId: staffList[0]?.id || undefined, // auto assign first staff
        status: 'Active' as const,
        notes: row.notes || undefined,
      };
      createClient(payload);
    });
    refreshList();
    setIsImportOpen(false);
  };

  // Filter & Search computation
  const filteredClients = clients.filter((c) => {
    // Role based restriction
    if (currentUser?.role === 'Staff' && c.assignedStaffId !== currentUser?.id) {
      return false;
    }

    const query = searchQuery.toLowerCase();
    const matchSearch =
      c.name.toLowerCase().includes(query) ||
      c.clientId.toLowerCase().includes(query) ||
      (c.tradeName && c.tradeName.toLowerCase().includes(query)) ||
      (c.gstin && c.gstin.toLowerCase().includes(query)) ||
      (c.pan && c.pan.toLowerCase().includes(query)) ||
      (c.mobileNumber && c.mobileNumber.includes(query));

    const matchStatus = filterStatus === 'All' || c.status === filterStatus;
    const matchEntity = filterEntity === 'All' || c.entityType === filterEntity;
    const matchStaff = filterStaff === 'All' || c.assignedStaffId === filterStaff;
    const matchService = filterService === 'All' || (c.servicesAvailed && c.servicesAvailed.includes(filterService));

    return matchSearch && matchStatus && matchEntity && matchStaff && matchService;
  });

  const entityTypesList = [
    'Proprietorship',
    'Partnership',
    'Limited Liability Partnership',
    'Private Limited Company',
    'Public Limited Company',
    'One Person Company',
    'Trust',
    'Society',
    'Other',
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center">
            <Users className="w-6 h-6 mr-2.5 text-[#F5405E]" />
            Client Master Database
          </h1>
          <p className="text-xs text-slate-500">Add, edit, manage and import customer dossiers compliant with Taxcom Technologies workflows.</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsImportOpen(true)}
            className="inline-flex items-center justify-center h-10 px-4 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 shadow-xs cursor-pointer transition-colors"
          >
            <FileSpreadsheet className="w-4 h-4 mr-1.5 text-[#F5405E] shrink-0" />
            Import Excel/CSV
          </button>
          
          <button
            onClick={handleExportExcel}
            className="inline-flex items-center justify-center h-10 px-4 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 shadow-xs cursor-pointer transition-colors"
          >
            <Download className="w-4 h-4 mr-1.5 text-slate-500 shrink-0" />
            Export Excel
          </button>

          <button
            onClick={handleOpenCreateModal}
            className="inline-flex items-center justify-center h-10 px-4 text-xs font-bold text-white bg-[#F5405E] hover:bg-rose-600 rounded-lg shadow-sm cursor-pointer transition-colors"
          >
            <Plus className="w-4 h-4 mr-1.5 shrink-0" />
            Add New Client
          </button>
        </div>
      </div>

      {/* Control Filters Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Global Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search by Client ID, Name, GSTIN, PAN, Phone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 h-10 w-full text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-rose-500 bg-slate-50/30"
            />
          </div>

          {/* Quick Filters */}
          <div className="flex items-center gap-2">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="text-xs border border-slate-300 rounded-lg px-3 h-10 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Archived">Archived</option>
            </select>

            <button
              onClick={() => setIsFilterPanelOpen(!isFilterPanelOpen)}
              className={`inline-flex items-center justify-center px-3.5 h-10 text-xs font-semibold rounded-lg border cursor-pointer transition-colors ${
                isFilterPanelOpen || filterEntity !== 'All' || filterStaff !== 'All' || filterService !== 'All'
                  ? 'bg-rose-50 text-[#F5405E] border-rose-200'
                  : 'bg-white text-slate-700 border-slate-300'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5 mr-1.5 shrink-0" />
              Advanced Filters
            </button>
          </div>
        </div>

        {/* Advanced Filters Panel */}
        {isFilterPanelOpen && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3 border-t border-slate-100 animate-in slide-in-from-top duration-150">
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">Entity Type</label>
              <select
                value={filterEntity}
                onChange={(e) => setFilterEntity(e.target.value)}
                className="block w-full text-xs border border-slate-300 rounded-lg px-3 h-10 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
              >
                <option value="All">All Entities</option>
                {entityTypesList.map((ent) => (
                  <option key={ent} value={ent}>{ent}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">Assigned Staff</label>
              <select
                value={filterStaff}
                onChange={(e) => setFilterStaff(e.target.value)}
                className="block w-full text-xs border border-slate-300 rounded-lg px-3 h-10 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
              >
                <option value="All">All Staff</option>
                {staffList.map((st) => (
                  <option key={st.id} value={st.id}>{st.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">Services Availed</label>
              <select
                value={filterService}
                onChange={(e) => setFilterService(e.target.value)}
                className="block w-full text-xs border border-slate-300 rounded-lg px-3 h-10 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 cursor-pointer"
              >
                <option value="All">All Services</option>
                {servicesList.map((srv) => (
                  <option key={srv} value={srv}>{srv}</option>
                ))}
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Clients list table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        {filteredClients.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-sm font-semibold text-slate-500">No clients match your criteria.</p>
            <p className="text-xs text-slate-400 mt-1">Try modifying your filters or adding a new client master record.</p>
          </div>
        ) : (
          <div className="overflow-auto max-h-[70vh]">
            <table className="w-full text-left text-sm border-collapse">
              <thead className="sticky top-0 z-10 bg-slate-50 shadow-sm">
                <tr className="border-b border-slate-200 text-slate-500 text-xs font-bold uppercase tracking-wider">
                  <th className="py-3 px-4">Client ID</th>
                  <th className="py-3 px-4">Entity Legal Details</th>
                  <th className="py-3 px-4">Communications</th>
                  <th className="py-3 px-4">Tax Identifiers</th>
                  <th className="py-3 px-4">Assigned Staff</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredClients.map((client) => {
                  const staffName = client.assignedStaffName || 'Unassigned';
                  return (
                    <tr key={client.id} className="hover:bg-slate-50/50">
                      <td className="py-4 px-4 font-bold text-slate-900">{client.clientId}</td>
                      <td className="py-4 px-4">
                        <span className="font-extrabold text-slate-900 block">{client.name}</span>
                        {client.tradeName && <span className="text-xs text-slate-500 block">T/A: {client.tradeName}</span>}
                        <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-100 px-1 py-0.5 rounded mt-1 inline-block">{client.entityType}</span>
                      </td>
                      <td className="py-4 px-4 text-xs space-y-0.5">
                        {client.whatsappNumber ? (
                          <div className="text-slate-700">WhatsApp: <strong className="font-semibold">{client.whatsappNumber}</strong></div>
                        ) : (
                          client.mobileNumber && <div className="text-slate-600">Mobile: {client.mobileNumber}</div>
                        )}
                        {client.emailAddress && <div className="text-slate-500 truncate max-w-[180px]">{client.emailAddress}</div>}
                      </td>
                      <td className="py-4 px-4 text-xs space-y-0.5">
                        {client.gstin && <div className="text-slate-800 font-mono">GSTIN: <strong className="font-bold">{client.gstin}</strong></div>}
                        {client.pan && <div className="text-slate-500 font-mono">PAN: {client.pan}</div>}
                        {client.fssaiNumber && <div className="text-slate-500 font-mono">FSSAI: {client.fssaiNumber}</div>}
                      </td>
                      <td className="py-4 px-4">
                        <span className="inline-flex items-center text-xs font-semibold text-slate-700">
                          <UserCheck className="w-3.5 h-3.5 mr-1 text-slate-400" />
                          {staffName}
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          client.status === 'Active'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : client.status === 'Archived'
                            ? 'bg-purple-50 text-purple-700 border border-purple-200'
                            : 'bg-slate-100 text-slate-500 border border-slate-200'
                        }`}>
                          {client.status}
                        </span>
                      </td>
                      <td className="py-4 px-4 text-right">
                        <div className="flex items-center justify-end space-x-1">
                          {client.status === 'Active' ? (
                            <button
                              disabled={isSubmitting || isDeletingClient}
                              onClick={() => handleToggleStatus(client)}
                              title="Deactivate Client"
                              className="p-1.5 text-emerald-600 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              <Power className="w-4 h-4 text-emerald-500 hover:text-rose-500" />
                            </button>
                          ) : (
                            <button
                              disabled={isSubmitting || isDeletingClient}
                              onClick={() => handleToggleStatus(client)}
                              title="Reactivate Client"
                              className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              <Power className="w-4 h-4 text-slate-400 hover:text-emerald-500" />
                            </button>
                          )}
                          <button
                            disabled={isSubmitting || isDeletingClient}
                            onClick={() => handleOpenEditModal(client)}
                            title="Edit Client"
                            className="p-1.5 text-slate-500 hover:text-[#F5405E] hover:bg-rose-50 rounded-lg transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          {client.status !== 'Active' && currentUser?.role === 'Admin' && (() => {
                            const hasLinked = checkClientHasLinkedRecords(client);
                            return (
                              <button
                                disabled={isSubmitting || isDeletingClient || hasLinked}
                                onClick={() => handleDeleteClick(client)}
                                title={hasLinked ? "This client has linked records and cannot be permanently deleted." : "Permanently Delete Client"}
                                className={`p-1.5 rounded-lg transition-colors cursor-pointer disabled:opacity-50 ${
                                  hasLinked 
                                    ? 'text-slate-300 bg-slate-50 cursor-not-allowed' 
                                    : 'text-slate-400 hover:text-rose-600 hover:bg-rose-50'
                                }`}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            );
                          })()}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* FORM DIALOG MODAL (Create / Edit Client) */}
      
      {/* DISCARD CHANGES MODAL */}
      {isDiscardModalOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-sm overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
            <div className="p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-amber-100 mx-auto flex items-center justify-center mb-4">
                <AlertTriangle className="w-6 h-6 text-amber-600" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Discard Changes?</h3>
              <p className="text-sm text-slate-500">
                You have unsaved changes. Are you sure you want to discard them?
              </p>
            </div>
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-center gap-3">
              <button
                onClick={() => setIsDiscardModalOpen(false)}
                className="px-4 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-all"
              >
                Keep Editing
              </button>
              <button
                onClick={confirmDiscardChanges}
                className="px-4 py-2 text-sm font-bold text-white bg-amber-500 hover:bg-amber-600 rounded-lg transition-all shadow-sm"
              >
                Discard
              </button>
            </div>
          </div>
        </div>
      )}

      {isFormOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center sm:p-4">
          <div className="bg-white sm:rounded-2xl shadow-xl border-0 sm:border border-slate-100 max-w-2xl w-full h-full sm:h-auto sm:max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 border-b border-slate-100 bg-slate-50 flex items-center justify-between shrink-0">
              <h3 className="font-extrabold text-slate-900 text-lg">
                {editingClient ? 'Edit Client Record' : 'Create Client Record'}
              </h3>
              <button onClick={handleCloseModal} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
            </div>

            <form onSubmit={handleFormSubmit} className="flex-1 flex flex-col overflow-hidden relative">
              {isLoadingClientData ? (
                <div className="flex-1 flex flex-col items-center justify-center p-12 space-y-3 min-h-[400px]">
                  <span className="w-8 h-8 border-4 border-[#F5405E] border-t-transparent rounded-full animate-spin"></span>
                  <p className="text-sm font-bold text-slate-600 animate-pulse">Loading client data...</p>
                </div>
              ) : (
                <>
                  <div className="flex-1 p-6 overflow-y-auto space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">CLIENT CODE (EDITABLE) *</label>
                    <input
                      type="text"
                      required
                      value={formClientId}
                      onChange={(e) => setFormClientId(e.target.value)}
                      className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white font-medium focus:outline-none focus:ring-1 focus:ring-rose-500 text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Entity Type *</label>
                    <select
                      value={formEntityType}
                      onChange={(e) => setFormEntityType(e.target.value)}
                      className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white font-medium focus:outline-none focus:ring-1 focus:ring-rose-500"
                    >
                      {entityTypesList.map((ent) => (
                        <option key={ent} value={ent}>{ent}</option>
                      ))}
                    </select>
                  </div>

                  <div className="col-span-1 md:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Client Legal Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Apex Retail Solutions Pvt Ltd"
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      className={`w-full text-xs border ${formErrors.name ? 'border-rose-500 bg-rose-50/20' : 'border-slate-300'} rounded-lg p-2.5 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500`}
                    />
                    {formErrors.name && (
                      <p className="text-rose-500 text-[11px] font-semibold mt-1">{formErrors.name}</p>
                    )}
                  </div>

                  <div className="col-span-1 md:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Trade Name / Brand (Optional)</label>
                    <input
                      type="text"
                      placeholder="e.g. Apex Superstore"
                      value={formTradeName}
                      onChange={(e) => setFormTradeName(e.target.value)}
                      className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Primary Contact Person (Optional)</label>
                    <input
                      type="text"
                      placeholder="e.g. Suresh Kumar"
                      value={formPrimaryContactPerson}
                      onChange={(e) => setFormPrimaryContactPerson(e.target.value)}
                      className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Email Address (Optional)</label>
                    <input
                      type="email"
                      placeholder="e.g. billing@apexretail.in"
                      value={formEmail}
                      onChange={(e) => setFormEmail(e.target.value)}
                      className={`w-full text-xs border ${formErrors.email ? 'border-rose-500 bg-rose-50/20' : 'border-slate-300'} rounded-lg p-2.5 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500`}
                    />
                    {formErrors.email && (
                      <p className="text-rose-500 text-[11px] font-semibold mt-1">{formErrors.email}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Mobile Number (Optional)</label>
                    <input
                      type="tel"
                      placeholder="10-digit mobile number"
                      maxLength={10}
                      value={formMobile}
                      onChange={(e) => handleMobileChange(e.target.value)}
                      className={`w-full text-xs border ${formErrors.mobile ? 'border-rose-500 bg-rose-50/20' : 'border-slate-300'} rounded-lg p-2.5 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-mono`}
                    />
                    {formErrors.mobile && (
                      <p className="text-rose-500 text-[11px] font-semibold mt-1">{formErrors.mobile}</p>
                    )}
                  </div>

                  <div>
                    <div className="flex flex-wrap items-start justify-between gap-1 mb-1">
                      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">WhatsApp Number (Optional)</label>
                      <label className="inline-flex items-start gap-1 text-[10px] text-slate-500 font-bold cursor-pointer hover:text-rose-600 transition-colors whitespace-normal break-words">
                        <input
                          type="checkbox"
                          checked={sameAsMobile}
                          onChange={(e) => handleSameAsMobileChange(e.target.checked)}
                          className="rounded border-slate-300 text-rose-500 focus:ring-rose-500 h-3.5 w-3.5 cursor-pointer shrink-0 mt-0.5"
                        />
                        <span>Same as Mobile</span>
                      </label>
                    </div>
                    <input
                      type="tel"
                      placeholder="10-digit WhatsApp number"
                      maxLength={10}
                      disabled={sameAsMobile}
                      value={formWhatsapp}
                      onChange={(e) => setFormWhatsapp(e.target.value.replace(/\D/g, ''))}
                      className={`w-full text-xs border ${formErrors.whatsapp ? 'border-rose-500 bg-rose-50/20' : 'border-slate-300'} rounded-lg p-2.5 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-mono disabled:bg-slate-50 disabled:text-slate-400`}
                    />
                    {formErrors.whatsapp && (
                      <p className="text-rose-500 text-[11px] font-semibold mt-1">{formErrors.whatsapp}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">State (Optional)</label>
                    <input
                      type="text"
                      placeholder="e.g. West Bengal"
                      value={formState}
                      onChange={(e) => setFormState(e.target.value)}
                      className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">PIN Code (Optional)</label>
                    <input
                      type="text"
                      maxLength={6}
                      placeholder="e.g. 700001"
                      value={formPinCode}
                      onChange={(e) => setFormPinCode(e.target.value.replace(/\D/g, ''))}
                      className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-mono"
                    />
                  </div>

                  <div className="col-span-1 md:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Address (Optional)</label>
                    <textarea
                      rows={2}
                      placeholder="Full business location address..."
                      value={formAddress}
                      onChange={(e) => setFormAddress(e.target.value)}
                      className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">GSTIN (Optional)</label>
                    <input
                      type="text"
                      maxLength={15}
                      placeholder="15-digit GSTIN"
                      value={formGstin}
                      onChange={(e) => setFormGstin(e.target.value.toUpperCase())}
                      className={`w-full text-xs border ${formErrors.gstin ? 'border-rose-500 bg-rose-50/20' : 'border-slate-300'} rounded-lg p-2.5 bg-white font-mono uppercase focus:outline-none focus:ring-1 focus:ring-rose-500`}
                    />
                    {formErrors.gstin && (
                      <p className="text-rose-500 text-[11px] font-semibold mt-1">{formErrors.gstin}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">PAN (Optional)</label>
                    <input
                      type="text"
                      maxLength={10}
                      placeholder="10-digit PAN"
                      value={formPan}
                      onChange={(e) => setFormPan(e.target.value.toUpperCase())}
                      className={`w-full text-xs border ${formErrors.pan ? 'border-rose-500 bg-rose-50/20' : 'border-slate-300'} rounded-lg p-2.5 bg-white font-mono uppercase focus:outline-none focus:ring-1 focus:ring-rose-500`}
                    />
                    {formErrors.pan && (
                      <p className="text-rose-500 text-[11px] font-semibold mt-1">{formErrors.pan}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">CIN / LLPIN (Optional)</label>
                    <input
                      type="text"
                      placeholder="e.g. U51909MH2021PTC356789"
                      value={formCinLlp}
                      onChange={(e) => setFormCinLlp(e.target.value.toUpperCase())}
                      className={`w-full text-xs border ${formErrors.cinLlp ? 'border-rose-500 bg-rose-50/20' : 'border-slate-300'} rounded-lg p-2.5 bg-white font-mono uppercase focus:outline-none focus:ring-1 focus:ring-rose-500`}
                    />
                    {formErrors.cinLlp && (
                      <p className="text-rose-500 text-[11px] font-semibold mt-1">{formErrors.cinLlp}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">FSSAI License No. (Optional)</label>
                    <input
                      type="text"
                      maxLength={14}
                      placeholder="14-digit FSSAI"
                      value={formFssai}
                      onChange={(e) => setFormFssai(e.target.value.replace(/\D/g, ''))}
                      className={`w-full text-xs border ${formErrors.fssai ? 'border-rose-500 bg-rose-50/20' : 'border-slate-300'} rounded-lg p-2.5 bg-white font-mono focus:outline-none focus:ring-1 focus:ring-rose-500`}
                    />
                    {formErrors.fssai && (
                      <p className="text-rose-500 text-[11px] font-semibold mt-1">{formErrors.fssai}</p>
                    )}
                  </div>

                  {/* Custom Fields (Optional) - Replaces the empty grid slot below FSSAI */}
                  <div className="col-span-1 md:col-span-2 bg-slate-50 p-4 rounded-xl border border-slate-200/60 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-slate-800 uppercase tracking-wider">Custom Fields (Optional)</span>
                      <button
                        type="button"
                        onClick={handleAddCustomField}
                        className="text-[11px] font-extrabold text-[#F5405E] hover:text-rose-700 bg-rose-50 hover:bg-rose-100/70 px-2 py-1 rounded transition-colors cursor-pointer"
                      >
                        + Add Another Custom Field
                      </button>
                    </div>
                    
                    {formCustomFields.length === 0 ? (
                      <p className="text-[11px] text-slate-400 font-medium">No custom fields added yet. Click above to add editable custom credentials or numbers.</p>
                    ) : (
                      <div className="space-y-2">
                        {formCustomFields.map((cf, idx) => (
                          <div key={idx} className="flex gap-2 items-center">
                            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-2">
                              <input
                                type="text"
                                placeholder="e.g. MSME Number, GST Username, Trade Licence No."
                                value={cf.fieldName}
                                onChange={(e) => handleUpdateCustomField(idx, 'fieldName', e.target.value)}
                                className="w-full text-xs border border-slate-300 rounded-lg p-2 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-medium"
                              />
                              <input
                                type="text"
                                placeholder="Enter the corresponding value"
                                value={cf.fieldValue}
                                onChange={(e) => handleUpdateCustomField(idx, 'fieldValue', e.target.value)}
                                className="w-full text-xs border border-slate-300 rounded-lg p-2 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                              />
                            </div>
                            <button
                              type="button"
                              onClick={() => handleRemoveCustomField(idx)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer font-bold text-xs"
                              title="Remove field"
                            >
                              ✕
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Portal Credentials (Optional) */}
                  <div className="col-span-1 md:col-span-2 bg-slate-50 p-4 rounded-xl border border-slate-200/60 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-slate-800 uppercase tracking-wider">PORTAL CREDENTIALS (OPTIONAL)</span>
                      <button
                        type="button"
                        onClick={handleAddPortalCredential}
                        className="text-[11px] font-extrabold text-[#F5405E] hover:text-rose-700 bg-rose-50 hover:bg-rose-100/70 px-2 py-1 rounded transition-colors cursor-pointer"
                      >
                        + Add Another Credential
                      </button>
                    </div>

                    {formPortalCredentials.length === 0 ? (
                      <p className="text-[11px] text-slate-400 font-medium">No portal credentials added yet. Click above to add credentials for GST, Income Tax, MCA, etc.</p>
                    ) : (
                      <div className="space-y-3">
                        {formPortalCredentials.map((pc, idx) => (
                          <div key={idx} className="flex gap-2 items-start border-b border-slate-100 pb-3 last:border-0 last:pb-0">
                            <div className="flex-1 grid grid-cols-1 md:grid-cols-4 gap-3">
                              {/* Portal Name select or custom name */}
                              <div className="space-y-1">
                                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Portal Name</label>
                                <select
                                  value={pc.portalName}
                                  onChange={(e) => handleUpdatePortalCredential(idx, 'portalName', e.target.value)}
                                  className="w-full text-xs border border-slate-300 rounded-lg p-2 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-semibold text-slate-700"
                                >
                                  {["GST", "Income Tax", "MCA", "PF", "ESI", "FSSAI", "Other"].map(opt => (
                                    <option key={opt} value={opt}>{opt}</option>
                                  ))}
                                </select>
                                {pc.portalName === 'Other' && (
                                  <input
                                    type="text"
                                    placeholder="Enter Custom Portal Name"
                                    value={pc.customPortalName || ''}
                                    onChange={(e) => handleUpdatePortalCredential(idx, 'customPortalName', e.target.value)}
                                    className="w-full text-xs border border-slate-300 rounded-lg p-2 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-medium mt-1.5 animate-in slide-in-from-top-1 duration-150"
                                  />
                                )}
                              </div>

                              {/* Portal Login URL */}
                              <div className="space-y-1">
                                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Portal Login URL</label>
                                <input
                                  type="url"
                                  placeholder="Enter Login URL (e.g., https://...)"
                                  value={pc.portalUrl || ''}
                                  onChange={(e) => handleUpdatePortalCredential(idx, 'portalUrl', e.target.value)}
                                  className="w-full text-xs border border-slate-300 rounded-lg p-2 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-medium"
                                />
                              </div>

                              {/* User ID */}
                              <div className="space-y-1">
                                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">User ID</label>
                                <input
                                  type="text"
                                  placeholder="Enter User ID"
                                  value={pc.userId}
                                  onChange={(e) => handleUpdatePortalCredential(idx, 'userId', e.target.value)}
                                  className="w-full text-xs border border-slate-300 rounded-lg p-2 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-medium"
                                />
                              </div>

                              {/* Password with Eye icon toggle */}
                              <div className="space-y-1">
                                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Password</label>
                                <div className="relative">
                                  <input
                                    type={visiblePasswords[idx] ? "text" : "password"}
                                    placeholder="Enter Password"
                                    value={pc.password || ''}
                                    onChange={(e) => handleUpdatePortalCredential(idx, 'password', e.target.value)}
                                    className="w-full text-xs border border-slate-300 rounded-lg p-2 pr-8 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500 font-medium"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => togglePasswordVisibility(idx)}
                                    className="absolute right-2 top-2.5 text-slate-400 hover:text-slate-600 focus:outline-none cursor-pointer"
                                  >
                                    {visiblePasswords[idx] ? (
                                      <EyeOff className="w-4 h-4" />
                                    ) : (
                                      <Eye className="w-4 h-4" />
                                    )}
                                  </button>
                                </div>
                              </div>
                            </div>

                            {/* Remove button */}
                            <button
                              type="button"
                              onClick={() => handleRemovePortalCredential(idx)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer font-bold text-xs mt-5"
                              title="Remove credential"
                            >
                              ✕
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Services Availed (Optional) */}
                   <div className="col-span-1 md:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-wider">Services Availed (Optional)</label>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2 bg-slate-50 p-3 rounded-lg border border-slate-200/50">
                      {servicesList.map((srv) => {
                        const isChecked = formServicesAvailed.includes(srv);
                        return (
                          <label 
                            key={srv} 
                            className={`flex items-start gap-2 p-1.5 rounded-md cursor-pointer transition-colors text-xs font-semibold whitespace-normal break-words ${
                              isChecked ? 'bg-rose-50 text-[#F5405E]' : 'text-slate-600 hover:bg-slate-100'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => {
                                if (isChecked) {
                                  setFormServicesAvailed(formServicesAvailed.filter((s) => s !== srv));
                                } else {
                                  setFormServicesAvailed([...formServicesAvailed, srv]);
                                }
                              }}
                              className="rounded border-slate-300 text-rose-500 focus:ring-rose-500 h-3.5 w-3.5 cursor-pointer shrink-0 mt-0.5"
                            />
                            <span className="break-words whitespace-normal leading-tight">{srv}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  {/* Assign Primary Staff */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Assign Primary Staff</label>
                    <select
                      value={formAssignedStaff}
                      onChange={(e) => setFormAssignedStaff(e.target.value)}
                      className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                    >
                      <option value="">Unassigned</option>
                      {staffList.map((st) => (
                        <option key={st.id} value={st.id}>{st.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Active Status */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Active Status</label>
                    <select
                      value={formStatus}
                      onChange={(e) => setFormStatus(e.target.value as any)}
                      className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500"
                    >
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                      <option value="Archived">Archived</option>
                    </select>
                  </div>

                  {/* Internal Client Notes */}
                   <div className="col-span-1 md:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wider">Internal Client Notes (Optional)</label>
                    <textarea
                      rows={2}
                      placeholder="Enter special pricing agreements, filing quirks, director references..."
                      value={formNotes}
                      onChange={(e) => setFormNotes(e.target.value)}
                      className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                    />
                  </div>

                </div>
              </div>

              {/* Sticky Footer Area - Outside the scroll area */}
              <div className="sticky bottom-0 bg-white border-t border-slate-100 p-5 flex justify-end space-x-3 z-10 shadow-xs">
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 text-xs font-bold text-white bg-[#F5405E] hover:bg-rose-600 disabled:bg-rose-300 disabled:cursor-not-allowed rounded-lg shadow-sm cursor-pointer transition-all flex items-center gap-1.5"
                >
                  {isSubmitting ? (
                    <>
                      <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                      {editingClient ? 'Updating client...' : 'Saving...'}
                    </>
                  ) : (
                    editingClient ? 'Update Client' : 'Create Client'
                  )}
                </button>
              </div>
              </>
            )}

            </form>
          </div>
        </div>
      )}

      {/* IMPORT WIZARD MODAL */}
      <ImportWizard
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        title="Import Clients Database"
        fields={importFieldsDefinition}
        existingKeys={clients.map((c) => c.clientId)}
        duplicateCheckKey="clientId"
        onImport={handleImportedData}
      />

      {/* CUSTOM DELETION MODAL */}
      {isDeleteModalOpen && clientToDelete && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-md w-full flex flex-col overflow-hidden animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            
            {/* Header */}
            <div className="p-5 border-b border-slate-100 bg-slate-50 flex items-center space-x-2">
              <AlertTriangle className="w-5 h-5 text-rose-500" />
              <h3 className="font-extrabold text-slate-900 text-lg">
                Delete client?
              </h3>
            </div>

            {/* Body */}
            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                This action may affect linked compliance tasks, payments, reminders and documents.
              </p>

              {/* Client Profile Details Card */}
              <div className="p-4 bg-slate-50 border border-slate-150 rounded-xl space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400 font-bold uppercase tracking-wider">Client ID</span>
                  <span className="font-mono font-bold text-slate-800">{clientToDelete.clientId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-bold uppercase tracking-wider">Legal Name</span>
                  <span className="font-bold text-slate-800">{clientToDelete.name}</span>
                </div>
                {clientToDelete.tradeName && (
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-bold uppercase tracking-wider">Trade Name</span>
                    <span className="font-bold text-slate-800">{clientToDelete.tradeName}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-400 font-bold uppercase tracking-wider">Assigned Staff</span>
                  <span className="font-bold text-slate-800">
                    {clientToDelete.assignedStaffName || 'Unassigned'}
                  </span>
                </div>
              </div>

              {/* Download Backup Button */}
              <button
                type="button"
                onClick={handleDownloadBackup}
                className="w-full flex items-center justify-center space-x-2 py-2.5 px-4 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-xl text-xs transition-colors border border-indigo-200 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Client Backup</span>
              </button>

              {/* Dependency Check Area */}
              {isCheckingDependencies ? (
                <div className="flex flex-col items-center justify-center p-4 space-y-2">
                  <span className="w-6 h-6 border-2 border-rose-500 border-t-transparent rounded-full animate-spin"></span>
                  <p className="text-xs font-bold text-slate-500">Checking linked records…</p>
                </div>
              ) : dependencyCheckResult ? (
                <div className="space-y-4">
                  {/* Dependency Counts Summary */}
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                    <h4 className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Dependency Summary</h4>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs text-slate-600">
                      <div className="flex justify-between border-b border-slate-100 pb-1">
                        <span>Compliance Tasks</span>
                        <span className="font-bold text-slate-800">{dependencyCheckResult.tasksCount}</span>
                      </div>
                      <div className="flex justify-between border-b border-slate-100 pb-1">
                        <span>Reminders</span>
                        <span className="font-bold text-slate-800">{dependencyCheckResult.remindersCount}</span>
                      </div>
                      <div className="flex justify-between border-b border-slate-100 pb-1">
                        <span>Documents</span>
                        <span className="font-bold text-slate-800">{dependencyCheckResult.documentsCount}</span>
                      </div>
                      <div className="flex justify-between border-b border-slate-100 pb-1">
                        <span>Payments</span>
                        <span className="font-bold text-slate-800">{dependencyCheckResult.paymentsCount}</span>
                      </div>
                      <div className="flex justify-between border-b border-slate-100 pb-1">
                        <span>GST/ITR Filing History</span>
                        <span className="font-bold text-slate-800">{dependencyCheckResult.filingHistoryCount}</span>
                      </div>
                      <div className="flex justify-between border-b border-slate-100 pb-1">
                        <span>Reports Data Points</span>
                        <span className="font-bold text-slate-800">{dependencyCheckResult.reportsCount}</span>
                      </div>
                      <div className="flex justify-between border-b border-slate-100 pb-1">
                        <span>Notes & Notes History</span>
                        <span className="font-bold text-slate-800">{dependencyCheckResult.notesCount}</span>
                      </div>
                      <div className="flex justify-between border-b border-slate-100 pb-1">
                        <span>Activity/Audit Logs</span>
                        <span className="font-bold text-slate-800">{dependencyCheckResult.activityLogsCount}</span>
                      </div>
                    </div>
                  </div>

                  {dependencyCheckResult.hasDependencies ? (
                    <div className="space-y-3">
                      {/* Linked Warning */}
                      <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-lg font-semibold leading-relaxed">
                        This client cannot be deleted because compliance records exist. Please deactivate or archive the client instead.
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg font-medium leading-relaxed">
                        No linked operational records found. Permanent deletion is allowed.
                      </div>

                      {currentUser?.role === 'Admin' ? (
                        <div className="space-y-2">
                          <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">
                            To permanently delete this client, please type <strong className="text-rose-600 font-extrabold font-mono">DELETE</strong> below:
                          </label>
                          <input
                            type="text"
                            placeholder="Type DELETE"
                            value={deleteConfirmationText}
                            onChange={(e) => setDeleteConfirmationText(e.target.value)}
                            className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white font-mono font-bold uppercase focus:outline-none focus:ring-1 focus:ring-rose-500"
                          />
                        </div>
                      ) : (
                        <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-lg font-medium">
                          Only Administrators are allowed to permanently delete unused client records.
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ) : null}
            </div>

            {/* Footer */}
            <div className="p-5 border-t border-slate-100 bg-slate-50 flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => {
                  setIsDeleteModalOpen(false);
                  setClientToDelete(null);
                }}
                className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
              >
                Cancel
              </button>

              {currentUser?.role === 'Admin' && (
                <span
                  title={dependencyCheckResult?.hasDependencies ? "This client has linked records and cannot be permanently deleted." : "Permanently Delete Client"}
                  className="inline-block"
                >
                  <button
                    type="button"
                    disabled={
                      dependencyCheckResult?.hasDependencies ||
                      deleteConfirmationText !== 'DELETE' ||
                      isDeletingClient
                    }
                    onClick={handlePermanentDeleteSubmit}
                    className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 disabled:bg-rose-300 disabled:cursor-not-allowed rounded-lg shadow-sm cursor-pointer transition-colors flex items-center space-x-1"
                  >
                    {isDeletingClient ? (
                      <>
                        <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin mr-1.5"></span>
                        <span>Deleting client…</span>
                      </>
                    ) : (
                      <span>Permanently Delete</span>
                    )}
                  </button>
                </span>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
