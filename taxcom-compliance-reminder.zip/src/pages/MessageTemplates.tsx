import React, { useState, useEffect } from 'react';
import {
  FileText,
  Save,
  Undo2,
  CheckCircle2,
  Copy,
  Info,
  Plus,
  Search,
  Trash2,
  Mail,
  MessageSquare,
  X,
  ChevronLeft,
  MoreVertical,
  Pencil,
  AlertTriangle,
  Eye,
  Download,
  Power,
  Settings2,
  ToggleLeft,
  Type
} from 'lucide-react';
import { getTemplates, updateTemplate, createTemplate, deleteTemplate, getSignatureSettings } from '../db/storage';
import { MessageTemplate } from '../types';
import { useToast } from '../components/Toast';
import { useAuth } from '../components/AuthContext';

const CATEGORIES = [
  'GST',
  'Income Tax',
  'MCA',
  'ROC',
  'FSSAI',
  'DSC',
  'Trademark',
  'General',
  'Others'
];

const SAMPLE_VALUES: Record<string, string> = {
  clientName: 'ABC Enterprises',
  companyName: 'Taxcom Technologies LLP',
  staffName: 'Arvind Sharma',
  returnName: 'GSTR-3B Return',
  dueDate: '20 July 2026',
  amount: '₹12,500',
  invoiceNo: 'INV-2026-042',
  mobile: '+91 98765 43210',
  email: 'contact@abcenterprises.com',
  customMessage: 'Please review and approve the draft filing immediately.',
  period: 'June 2026',
  pendingDocuments: '• Purchase Invoice Create\n• Bank Statements (June 2026)',
  outstandingAmount: '12500',
  professionalFees: '15000',
  amountReceived: '2500'
};


const DEFAULT_SUBJECT = 'Compliance Notification: {{returnName}}';

export default function MessageTemplates() {
  const { currentUser } = useAuth();
  const isStaff = currentUser?.role === 'Staff';
  const isManager = currentUser?.role === 'Manager';
  const isAdmin = currentUser?.role === 'Admin';
  const { showToast } = useToast();
  const [templates, setTemplates] = useState<MessageTemplate[]>(() => getTemplates());

  useEffect(() => {
    const handleSync = () => {
      setTemplates(getTemplates());
    };
    window.addEventListener('database-sync', handleSync);
    return () => window.removeEventListener('database-sync', handleSync);
  }, []);
  
  // View state: 'list' or 'editor'
  const [view, setView] = useState<'list' | 'editor'>('list');

  // Search and filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedCommType, setSelectedCommType] = useState('All');

  // Editor states
  const [editingTemplate, setEditingTemplate] = useState<MessageTemplate | null>(null);
  const [templateToReset, setTemplateToReset] = useState<MessageTemplate | null>(null);
  const [templateName, setTemplateName] = useState('');
  const [category, setCategory] = useState('General');
  const [commType, setCommType] = useState<'WhatsApp' | 'Email' | 'Both'>('Both');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [activePreviewTab, setActivePreviewTab] = useState<'whatsapp' | 'email'>('whatsapp');

  // Delete Modal state
  const [templateToDelete, setTemplateToDelete] = useState<MessageTemplate | null>(null);

  // Dropdown state for card actions
    const [previewTemplate, setPreviewTemplate] = useState<MessageTemplate | null>(null);
  const [previewTab, setPreviewTab] = useState<'whatsapp' | 'email'>('whatsapp');
  
  const handleExportTemplate = (tmpl: MessageTemplate) => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(tmpl, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `template_${tmpl.id}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };
  
  const handleToggleActive = (tmpl: MessageTemplate) => {
    updateTemplate(tmpl.id, { isActive: tmpl.isActive === false ? true : false });
    setTemplates(getTemplates());
    showToast(`Template ${tmpl.isActive === false ? 'enabled' : 'disabled'}.`, 'success');
  };

  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = () => setActiveDropdown(null);
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  const openEditor = (tmpl?: MessageTemplate) => {
    if (tmpl) {
      setEditingTemplate(tmpl);
      setTemplateName(tmpl.templateName || tmpl.type || '');
      setCategory(tmpl.category || 'General');
      setCommType(tmpl.communicationType || 'Both');
      setSubject(tmpl.emailSubject || tmpl.subject || '');
      setBody(tmpl.messageBody || tmpl.body || '');
      setIsActive(tmpl.isActive !== false);
      if (tmpl.communicationType === 'Email') {
        setActivePreviewTab('email');
      } else {
        setActivePreviewTab('whatsapp');
      }
    } else {
      setEditingTemplate(null);
      setTemplateName('');
      setCategory('General');
      setCommType('Both');
      setSubject(DEFAULT_SUBJECT);
      
      setBody('Dear {{clientName}},\n\nYour {{returnName}} compliance deadline is approaching. Please submit your documents.\n\n{{signature}}');
      setIsActive(true);
      setActivePreviewTab('whatsapp');
    }
    setView('editor');
  };

  const closeEditor = () => {
    setView('list');
    setEditingTemplate(null);
  };

  const handleSave = () => {
    if (!templateName.trim()) {
      showToast('Template name is required', 'error');
      return;
    }
    if (!body.trim()) {
      showToast('Message body is required', 'error');
      return;
    }

    if (editingTemplate) {
      // Edit existing
      updateTemplate(editingTemplate.id, {
        templateName: templateName.trim(),
        category,
        communicationType: commType,
        emailSubject: subject.trim(),
        messageBody: body,
        isActive,
      });
      showToast(`Template "${templateName.trim()}" updated successfully!`, 'success');
    } else {
      // Create new
      createTemplate({
        templateName: templateName.trim(),
        category,
        communicationType: commType,
        emailSubject: subject.trim(),
        messageBody: body,
        isDefault: false,
        isActive,
        type: templateName.trim(),
        title: templateName.trim(),
        subject: subject.trim(),
        body: body,
      });
      showToast(`Template "${templateName.trim()}" created successfully!`, 'success');
    }

    setTemplates(getTemplates());
    closeEditor();
  };

  const handleResetToDefault = (tmpl: MessageTemplate) => {
    if (!tmpl.isDefault) return;
    setTemplateToReset(tmpl);
  };
  
  const confirmResetToDefault = () => {
    if (templateToReset) {
      let tmpl = templateToReset;
      let defaultSub = '';
      let defaultBody = '';
      let defaultCategory = 'General';
      let defaultCommType: 'WhatsApp' | 'Email' | 'Both' = 'Both';

      if (tmpl.id === 'tp-01') {
        defaultSub = 'Reminder: Upcoming GST Return Filing ({{returnName}})';
        defaultBody = 'Dear {{clientName}},\n\nThis is a gentle reminder that your {{returnName}} for the period of {{period}} is due on {{dueDate}}.\nPlease provide the necessary data and documents so we can process your filing on time.\n\nRegards,\n{{staffName}}\n{{companyName}}';
        defaultCategory = 'GST';
      } else if (tmpl.id === 'tp-02') {
        defaultSub = 'Important: Income Tax Return Filing Due Soon';
        defaultBody = 'Dear {{clientName}},\n\nYour Income Tax Return is approaching its due date on {{dueDate}}. Kindly ensure all relevant financial documents and investment proofs are submitted to us at the earliest to avoid any last-minute penalties.\n\nRegards,\n{{staffName}}\n{{companyName}}';
        defaultCategory = 'Income Tax';
      } else if (tmpl.id === 'tp-03') {
        defaultSub = 'Outstanding Payment Reminder - {{companyName}}';
        defaultBody = 'Dear {{clientName}},\n\nWe hope you are doing well. This is a reminder that a professional fee amount of ₹{{outstandingAmount}} is currently pending for your recent compliance services. Kindly clear the dues at your earliest convenience to maintain uninterrupted services.\n\nRegards,\n{{staffName}}\n{{companyName}}';
        defaultCategory = 'General';
      } else if (tmpl.id === 'tp-04') {
        defaultSub = 'Action Required: MCA Annual Filing Due';
        defaultBody = 'Dear {{clientName}},\n\nThis is an alert regarding your upcoming ROC compliances. The filing for {{returnName}} is due by {{dueDate}}. Please share the signed financials and director reports at your earliest convenience.\n\nRegards,\n{{staffName}}\n{{companyName}}';
        defaultCategory = 'MCA';
      } else if (tmpl.id === 'tp-05') {
        defaultSub = 'Successfully Filed: {{returnName}} for {{period}}';
        defaultBody = 'Dear {{clientName}},\n\nWe are pleased to inform you that your {{returnName}} for the period of {{period}} has been successfully filed and completed. Please find the acknowledgement details attached or saved in your portal.\n\nThank you for your cooperation.\n\nRegards,\n{{staffName}}\n{{companyName}}';
        defaultCategory = 'General';
      } else if (tmpl.id === 'tp-06') {
        defaultSub = 'Urgent: Digital Signature (DSC) Expiring Soon';
        defaultBody = 'Dear {{clientName}},\n\nThis is a gentle reminder that your Digital Signature Certificate (DSC) is approaching its expiry date on {{dueDate}}. An active DSC is mandatory for seamless MCA and GST filings. Kindly let us know so we can initiate the renewal process.\n\nRegards,\n{{staffName}}\n{{companyName}}';
        defaultCategory = 'MCA';
      } else if (tmpl.id === 'tp-07') {
        defaultSub = 'Reminder: Advance Tax Installment Due';
        defaultBody = 'Dear {{clientName}},\n\nPlease note that your next Advance Tax payment for the current financial year is due on {{dueDate}}. To avoid any interest penalties under sections 234B and 234C, kindly arrange for the tax computation and payment on time.\n\nRegards,\n{{staffName}}\n{{companyName}}';
        defaultCategory = 'Income Tax';
      } else if (tmpl.id === 'tp-08') {
        defaultSub = 'Reminder: License Renewal Approaching';
        defaultBody = 'Dear {{clientName}},\n\nYour business registration/license is scheduled to expire on {{dueDate}}. To ensure business continuity and avoid late fees, please provide the required renewal documents so we can process your application.\n\nRegards,\n{{staffName}}\n{{companyName}}';
        defaultCategory = 'Others';
      } else if (tmpl.id === 'tp-09') {
        defaultSub = 'Welcome to {{companyName}} - Compliance Simplified';
        defaultBody = 'Dear {{clientName}},\n\nWelcome to {{companyName}}! We are thrilled to have you onboard. Our team is committed to ensuring your business compliances, tax filings, and legal requirements are handled smoothly and on time. We look forward to a great professional relationship.\n\nRegards,\n{{staffName}}\n{{companyName}}';
        defaultCategory = 'General';
      } else if (tmpl.id === 'tp-custom-msg') {
        defaultSub = 'Custom Notification from {{companyName}}';
        defaultBody = 'Dear {{clientName}},\n\n{{customMessage}}\n\nRegards,\n{{staffName}}\n{{companyName}}';
        defaultCategory = 'General';
      }

      updateTemplate(tmpl.id, {
        emailSubject: defaultSub,
        messageBody: defaultBody,
        category: defaultCategory,
        communicationType: defaultCommType,
        isActive: true,
      });

      setTemplates(getTemplates());
      showToast(`Reset "${tmpl.templateName || tmpl.type}" to defaults.`, 'warning');
    }
  };

  const handleDuplicateTemplate = (tmpl: MessageTemplate) => {
    const copyName = `${tmpl.templateName || tmpl.type} Copy`;
    
    setEditingTemplate(null); // null means new template
    setTemplateName(copyName);
    setCategory(tmpl.category || 'General');
    setCommType(tmpl.communicationType || 'Both');
    setSubject(tmpl.emailSubject || tmpl.subject || '');
    setBody(tmpl.messageBody || tmpl.body || '');
    setIsActive(tmpl.isActive !== false);
    
  };

  const confirmDelete = () => {
    if (templateToDelete) {
      deleteTemplate(templateToDelete.id);
      setTemplates(getTemplates());
      showToast(`Deleted template "${templateToDelete.templateName || templateToDelete.type}"`, 'success');
      setTemplateToDelete(null);
    }
  };

  const renderPreview = (text: string) => {
    if (!text) return '';
    let rendered = text;

    const sigSettings = getSignatureSettings();
    let signature = '';
    if (sigSettings.style === 'Custom') {
      signature = sigSettings.customText;
    } else if (sigSettings.style === '{{staffName}} + {{companyName}}') {
      signature = '{{staffName}}, {{companyName}}';
    } else {
      signature = 'Team {{companyName}}';
    }
    rendered = rendered.replace(/\{\{signature\}\}/g, signature);
    Object.entries(SAMPLE_VALUES).forEach(([key, val]) => {
      const regex = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
      rendered = rendered.replace(regex, val);
    });
    return rendered;
  };

  const formatWhatsAppBody = (text: string) => {
    const rendered = renderPreview(text);
    const bolded = rendered.replace(/\*([^*]+)\*/g, '<strong>$1</strong>');
    return <div className="whitespace-pre-wrap font-sans text-xs text-slate-800 leading-relaxed" dangerouslySetInnerHTML={{ __html: bolded }} />;
  };

  const formatEmailBody = (text: string) => {
    const rendered = renderPreview(text);
    return <div className="whitespace-pre-wrap font-sans text-xs text-slate-700 leading-relaxed">{rendered}</div>;
  };

  // Filter templates
  const filteredTemplates = templates.filter(tmpl => {
    const name = (tmpl.templateName || tmpl.type || '').toLowerCase();
    const cat = (tmpl.category || 'General').toLowerCase();
    const type = (tmpl.communicationType || 'Both').toLowerCase();
    const content = (tmpl.messageBody || tmpl.body || '').toLowerCase();
    const searchLower = searchQuery.toLowerCase();
    
    const matchesSearch = name.includes(searchLower) || cat.includes(searchLower) || type.includes(searchLower) || content.includes(searchLower);
    const matchesCategory = selectedCategory === 'All' || tmpl.category === selectedCategory;
    const matchesComm = selectedCommType === 'All' || tmpl.communicationType === selectedCommType || tmpl.communicationType === 'Both' || selectedCommType === 'Both';

    return matchesSearch && matchesCategory && matchesComm;
  });

  const defaultTemplates = filteredTemplates.filter(t => t.isDefault);
  const customTemplates = filteredTemplates.filter(t => !t.isDefault);

  const tokenCategories = [
    {
      category: "System Tokens",
      tokens: [
        { name: '{{companyName}}', description: 'Your Company Name' },
        { name: '{{returnName}}', description: 'Return name' },
        { name: '{{dueDate}}', description: 'Due date' },
        { name: '{{period}}', description: 'Period' },
        { name: '{{pendingDocuments}}', description: 'Documents' },
      ]
    },
    {
      category: "Client Tokens",
      tokens: [
        { name: '{{clientName}}', description: "Client's legal name" },
        { name: '{{mobile}}', description: 'Mobile' },
        { name: '{{email}}', description: 'Email' },
      ]
    },
    {
      category: "Staff Tokens",
      tokens: [
        { name: '{{staffName}}', description: 'Assigned staff' },
      ]
    },
    {
      category: "Billing Tokens",
      tokens: [
        { name: '{{amount}}', description: 'Amount' },
        { name: '{{outstandingAmount}}', description: 'Outstanding' },
        { name: '{{invoiceNo}}', description: 'Invoice No' },
      ]
    },
    {
      category: "Custom Tokens",
      tokens: [
        { name: '{{customMessage}}', description: 'Custom Msg' },
        { name: '{{signature}}', description: 'Dynamic Signature' },
      ]
    }
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      
      {/* PREVIEW MODAL */}
      {previewTemplate && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-3xs flex items-center justify-center p-4 z-[100] animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden flex flex-col animate-in zoom-in-95 duration-150 max-h-[90vh]">
            <div className="flex justify-between items-center p-4 border-b border-slate-100 bg-slate-50">
              <h3 className="font-bold text-slate-900 text-lg flex items-center">
                <Eye className="w-5 h-5 text-indigo-500 mr-2" />
                Template Preview
              </h3>
              <button
                onClick={() => setPreviewTemplate(null)}
                className="text-slate-400 hover:text-slate-700 hover:bg-slate-200 p-2 rounded-xl transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto bg-slate-100/50 p-6 flex justify-center">
              {/* Reuse preview UI logic */}
              {(previewTemplate.communicationType === 'WhatsApp' || (!previewTemplate.communicationType || previewTemplate.communicationType === 'Both') && previewTab === 'whatsapp') ? (
                  <div className="w-full max-w-sm bg-[#efeae2] rounded-2xl overflow-hidden border border-slate-200 shadow-md flex flex-col font-sans h-fit">
                      <div className="bg-[#00a884] text-white p-3 flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center font-bold text-sm">T</div>
                        <div className="flex-1">
                          <p className="text-sm font-bold leading-none">Taxcom Technologies</p>
                          <p className="text-[10px] text-white/80 mt-1">Official Account</p>
                        </div>
                      </div>
                      <div className="p-4 flex-1 space-y-4">
                        <div className="bg-white rounded-lg p-2 mx-auto w-fit text-[10px] text-slate-500 font-medium">Today</div>
                        <div className="bg-[#d9fdd3] rounded-lg rounded-tr-none p-3 shadow-sm ml-auto max-w-[85%] text-slate-800 text-sm">
                          {formatWhatsAppBody(previewTemplate.messageBody || previewTemplate.body || '')}
                          <div className="flex justify-end text-[10px] text-slate-500 mt-1">
                            12:45 PM <span className="text-blue-500 ml-1">✓✓</span>
                          </div>
                        </div>
                      </div>
                    </div>
              ) : (
                    <div className="w-full bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-md flex flex-col font-sans h-fit">
                      <div className="bg-slate-50 border-b border-slate-100 p-3 flex gap-1.5">
                        <div className="w-3 h-3 rounded-full bg-rose-400"></div>
                        <div className="w-3 h-3 rounded-full bg-amber-400"></div>
                        <div className="w-3 h-3 rounded-full bg-emerald-400"></div>
                      </div>
                      <div className="p-4 border-b border-slate-100 space-y-2 text-sm text-slate-600 bg-slate-50/50">
                        <div><span className="font-semibold w-12 inline-block">From:</span> noreply@taxcom.co.in</div>
                        <div><span className="font-semibold w-12 inline-block">To:</span> {SAMPLE_VALUES.clientName}</div>
                        <div className="pt-2 border-t border-slate-200 text-slate-900 font-bold">
                          {renderPreview(previewTemplate.emailSubject || previewTemplate.subject || '')}
                        </div>
                      </div>
                      <div className="p-6 text-sm">
                        {formatEmailBody(previewTemplate.messageBody || previewTemplate.body || '')}
                      </div>
                    </div>
              )}
            </div>
            {(!previewTemplate.communicationType || previewTemplate.communicationType === 'Both') && (
              <div className="p-4 bg-white border-t border-slate-100 flex gap-2">
                 <button
                    onClick={() => setPreviewTab('whatsapp')}
                    className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-2 transition-all ${
                      previewTab === 'whatsapp'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50 border border-transparent'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4" />
                    WhatsApp
                  </button>
                  <button
                    onClick={() => setPreviewTab('email')}
                    className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-2 transition-all ${
                      previewTab === 'email'
                        ? 'bg-blue-50 text-blue-700 border border-blue-200'
                        : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50 border border-transparent'
                    }`}
                  >
                    <Mail className="w-4 h-4" />
                    Email
                  </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {templateToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-3xs flex items-center justify-center p-4 z-[100] animate-in fade-in duration-150">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-sm overflow-hidden flex flex-col animate-in zoom-in-95 duration-150">
            <div className="p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-rose-100 mx-auto flex items-center justify-center mb-4">
                <AlertTriangle className="w-6 h-6 text-rose-600" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Delete Template</h3>
              <p className="text-sm text-slate-500">
                Are you sure you want to permanently delete this template? This action cannot be undone.
              </p>
            </div>
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-center gap-3">
              <button
                onClick={() => setTemplateToDelete(null)}
                className="px-4 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-all"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-sm transition-all"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {view === 'list' ? (
        <>
          {/* Header & Controls */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div>
              <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center">
                <FileText className="w-6 h-6 mr-2.5 text-[#F43F5E]" />
                Template Management System
              </h1>
              <p className="text-sm text-slate-500 mt-1">
                Manage system and custom communication templates across all channels.
              </p>
            </div>
            {!isStaff && (
            <button
              onClick={() => openEditor()}
              className="inline-flex items-center justify-center px-5 py-2.5 text-sm font-bold text-white bg-[#F43F5E] hover:bg-rose-600 rounded-xl shadow-sm transition-all cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4 mr-1.5" />
              New Template
            </button>
            )}
          </div>

          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search templates by name, content, or category..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm font-medium text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#F43F5E]/20 focus:border-[#F43F5E]"
              />
            </div>
            <div className="flex gap-3">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-semibold text-slate-600 focus:outline-none focus:ring-2 focus:ring-[#F43F5E]/20 min-w-[140px]"
              >
                <option value="All">All Categories</option>
                {CATEGORIES.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
              <select
                value={selectedCommType}
                onChange={(e) => setSelectedCommType(e.target.value)}
                className="bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-semibold text-slate-600 focus:outline-none focus:ring-2 focus:ring-[#F43F5E]/20 min-w-[140px]"
              >
                <option value="All">All Channels</option>
                <option value="WhatsApp">WhatsApp</option>
                <option value="Email">Email</option>
                <option value="Both">Both</option>
              </select>
            </div>
          </div>

          {/* Template Grid */}
          <div className="space-y-8">
            {/* System Templates */}
            {defaultTemplates.length > 0 && (
              <section>
                <h2 className="text-sm font-bold uppercase tracking-widest text-slate-400 mb-4 ml-1">System Default Templates</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                  {defaultTemplates.map((tmpl) => (
                    <div key={tmpl.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col transition-all hover:shadow-md">
                      <div className="p-5 border-b border-slate-100 flex-1">
                        <div className="flex justify-between items-start mb-3">
                          <h3 className="font-bold text-slate-900 pr-4 line-clamp-2">{tmpl.templateName || tmpl.type}</h3>
                          <div className="flex gap-1 shrink-0">
                            {tmpl.communicationType === 'WhatsApp' && <MessageSquare className="w-4 h-4 text-emerald-500" />}
                            {tmpl.communicationType === 'Email' && <Mail className="w-4 h-4 text-blue-500" />}
                            {(tmpl.communicationType === 'Both' || !tmpl.communicationType) && (
                              <>
                                <MessageSquare className="w-4 h-4 text-emerald-500" />
                                <Mail className="w-4 h-4 text-blue-500" />
                              </>
                            )}
                          </div>
                        </div>
                        <p className="text-xs text-slate-500 line-clamp-3 mb-4 leading-relaxed font-mono bg-slate-50 p-2 rounded-lg border border-slate-100">
                          {tmpl.messageBody || tmpl.body}
                        </p>
                        <div className="flex gap-2">
                          <span className="inline-flex px-2 py-1 rounded-md text-[10px] font-bold bg-slate-100 text-slate-600">
                            {tmpl.category || 'General'}
                          </span>
                          <span className={`inline-flex px-2 py-1 rounded-md text-[10px] font-bold ${tmpl.isActive !== false ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                            {tmpl.isActive !== false ? 'Active' : 'Disabled'}
                          </span>
                        </div>
                      </div>
                      <div className="bg-slate-50/50 p-3 flex justify-between items-center gap-2">
                        {!isStaff && (<>
                        <button
                          onClick={() => openEditor(tmpl)}
                          className="flex-1 inline-flex items-center justify-center px-3 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
                        >
                          <Pencil className="w-3.5 h-3.5 mr-1.5" />
                          Edit
                        </button>
                        <div className="relative">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveDropdown(activeDropdown === tmpl.id ? null : tmpl.id);
                            }}
                            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition-colors"
                          >
                            <MoreVertical className="w-4 h-4" />
                          </button>
                          {activeDropdown === tmpl.id && (
                            <div className="absolute right-0 bottom-full mb-1 w-48 bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden z-10 py-1">
                              <button
                                onClick={() => { setActiveDropdown(null); handleDuplicateTemplate(tmpl); }}
                                className="w-full text-left px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center"
                              >
                                <Copy className="w-3.5 h-3.5 mr-2 text-slate-400" />
                                Duplicate
                              </button>
                              <button
                                onClick={() => { setActiveDropdown(null); handleResetToDefault(tmpl); }}
                                className="w-full text-left px-4 py-2 text-xs font-semibold text-amber-700 hover:bg-amber-50 flex items-center"
                              >
                                <Undo2 className="w-3.5 h-3.5 mr-2 text-amber-500" />
                                Reset to Default
                              </button>
                            </div>
                          )}
                        </div>
                        </>)}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Custom Templates */}
            <section>
              <h2 className="text-sm font-bold uppercase tracking-widest text-slate-400 mb-4 ml-1">Custom Templates</h2>
              {customTemplates.length === 0 ? (
                <div className="bg-white border border-dashed border-slate-300 rounded-2xl p-12 text-center">
                  <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <FileText className="w-6 h-6 text-slate-400" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 mb-1">No custom templates found</h3>
                  <p className="text-xs text-slate-500">Create a new template to get started with custom communications.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                  {customTemplates.map((tmpl) => (
                    <div key={tmpl.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col transition-all hover:shadow-md">
                      <div className="p-5 border-b border-slate-100 flex-1">
                        <div className="flex justify-between items-start mb-3">
                          <h3 className="font-bold text-slate-900 pr-4 line-clamp-2">{tmpl.templateName}</h3>
                          <div className="flex gap-1 shrink-0">
                            {tmpl.communicationType === 'WhatsApp' && <MessageSquare className="w-4 h-4 text-emerald-500" />}
                            {tmpl.communicationType === 'Email' && <Mail className="w-4 h-4 text-blue-500" />}
                            {tmpl.communicationType === 'Both' && (
                              <>
                                <MessageSquare className="w-4 h-4 text-emerald-500" />
                                <Mail className="w-4 h-4 text-blue-500" />
                              </>
                            )}
                          </div>
                        </div>
                        <p className="text-xs text-slate-500 line-clamp-3 mb-4 leading-relaxed font-mono bg-slate-50 p-2 rounded-lg border border-slate-100">
                          {tmpl.messageBody || tmpl.body}
                        </p>
                        <div className="flex gap-2">
                          <span className="inline-flex px-2 py-1 rounded-md text-[10px] font-bold bg-rose-50 text-rose-700">
                            {tmpl.category || 'General'}
                          </span>
                          <span className={`inline-flex px-2 py-1 rounded-md text-[10px] font-bold ${tmpl.isActive !== false ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                            {tmpl.isActive !== false ? 'Active' : 'Disabled'}
                          </span>
                        </div>
                      </div>
                      <div className="bg-slate-50/50 p-3 flex justify-between items-center gap-2">
                        {!isStaff && (
                          <>
                        <button
                          onClick={() => openEditor(tmpl)}
                          className="flex-1 inline-flex items-center justify-center px-3 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
                        >
                          <Pencil className="w-3.5 h-3.5 mr-1.5" />
                          Edit
                        </button>
                        <button
                          onClick={() => handleDuplicateTemplate(tmpl)}
                          className="flex-1 inline-flex items-center justify-center px-3 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
                        >
                          <Copy className="w-3.5 h-3.5 mr-1.5" />
                          Duplicate
                        </button>
                        <div className="relative">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveDropdown(activeDropdown === tmpl.id ? null : tmpl.id);
                            }}
                            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition-colors"
                          >
                            <MoreVertical className="w-4 h-4" />
                          </button>
                          {activeDropdown === tmpl.id && (
                            <div className="absolute right-0 bottom-full mb-1 w-48 bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden z-10 py-1">
                              {isAdmin && (
<button
                                onClick={() => { setActiveDropdown(null); setTemplateToDelete(tmpl); }}
                                className="w-full text-left px-4 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 flex items-center"
                              >
                                <Trash2 className="w-3.5 h-3.5 mr-2 text-rose-500" />
                                Delete
                              </button>
)}
                            </div>
                          )}
                        </div>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </div>
        </>
      ) : (
        /* EDITOR VIEW */
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white/90 backdrop-blur-md p-4 rounded-2xl border border-slate-200 shadow-sm sticky top-2 z-40">
            <div className="flex items-center gap-3">
              <button
                onClick={closeEditor}
                className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <div>
                <h2 className="text-lg font-black text-slate-900 tracking-tight">
                  {editingTemplate ? (editingTemplate.isDefault ? 'Edit System Template' : 'Edit Custom Template') : 'Create New Template'}
                </h2>
                <p className="text-xs text-slate-500 line-clamp-1">
                  {editingTemplate?.isDefault ? 'Some fields are restricted for system defaults.' : 'Fully customize your communication template.'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                onClick={closeEditor}
                className="flex-1 sm:flex-none px-4 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="flex-1 sm:flex-none inline-flex items-center justify-center px-5 py-2 text-sm font-bold text-white bg-[#F43F5E] hover:bg-rose-600 rounded-xl shadow-sm transition-all"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Template
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Form Column */}
            <div className="lg:col-span-7 xl:col-span-8 bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
              <div className="p-6 space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Template Name</label>
                    <input
                      type="text"
                      value={templateName}
                      disabled={editingTemplate?.isDefault}
                      onChange={(e) => setTemplateName(e.target.value)}
                      className="w-full border border-slate-200 rounded-xl p-3 text-sm font-semibold text-slate-800 disabled:opacity-60 disabled:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all"
                      placeholder="e.g. GST Pending Custom Alert"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Category</label>
                      <select
                        value={category}
                        disabled={editingTemplate?.isDefault}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full border border-slate-200 rounded-xl p-3 text-sm font-semibold text-slate-800 disabled:opacity-60 disabled:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all"
                      >
                        {CATEGORIES.map(cat => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Channel</label>
                      <select
                        value={commType}
                        disabled={editingTemplate?.isDefault}
                        onChange={(e) => {
                          const val = e.target.value as any;
                          setCommType(val);
                          if (val === 'WhatsApp') setActivePreviewTab('whatsapp');
                          if (val === 'Email') setActivePreviewTab('email');
                        }}
                        className="w-full border border-slate-200 rounded-xl p-3 text-sm font-semibold text-slate-800 disabled:opacity-60 disabled:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all"
                      >
                        <option value="WhatsApp">WhatsApp</option>
                        <option value="Email">Email</option>
                        <option value="Both">Both</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <input
                    type="checkbox"
                    id="editor-active-checkbox"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="w-4 h-4 text-rose-500 border-slate-300 rounded focus:ring-rose-500"
                  />
                  <label htmlFor="editor-active-checkbox" className="text-sm font-bold text-slate-700 cursor-pointer">
                    Enable Template
                    <span className="block text-[11px] text-slate-500 font-medium mt-0.5">Disabled templates will not be available for dispatch.</span>
                  </label>
                </div>

                {(commType === 'Email' || commType === 'Both') && (
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Email Subject Line</label>
                    <input
                      type="text"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      placeholder="Subject line..."
                      className="w-full border border-slate-200 rounded-xl p-3 text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all"
                    />
                  </div>
                )}

                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500">Message Body</label>
                    <span className="text-[10px] font-mono font-bold text-slate-400">{body.length} chars</span>
                  </div>
                  <textarea
                    rows={12}
                    value={body}
                    onChange={(e) => setBody(e.target.value)}
                    placeholder="Type your message here..."
                    className="w-full border border-slate-200 rounded-xl p-4 bg-slate-50/50 text-sm font-mono text-slate-800 leading-relaxed focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all resize-y"
                  />
                </div>

                {/* Tokens Cheatsheet */}
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
                  <h4 className="text-xs font-bold text-slate-700 flex items-center mb-3">
                    <Info className="w-4 h-4 mr-1.5 text-blue-500" />
                    Available Dynamic Tokens
                  </h4>
                  <div className="space-y-4 max-h-60 overflow-y-auto pr-2">
                    {tokenCategories.map((cat, idx) => (
                      <div key={idx}>
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 border-b border-slate-200 pb-1">{cat.category}</div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2">
                          {cat.tokens.map((tok) => (
                            <div key={tok.name} className="flex flex-col">
                              <span className="font-mono text-xs font-bold text-rose-600">{tok.name}</span>
                              <span className="text-[10px] font-medium text-slate-500">{tok.description}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Preview Column */}
            <div className="lg:col-span-5 xl:col-span-4 flex flex-col gap-4">
              
              <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col">
                <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    Live Preview
                  </span>
                </div>

                {commType === 'Both' && (
                  <div className="flex p-2 bg-slate-50 border-b border-slate-100">
                    <button
                      onClick={() => setActivePreviewTab('whatsapp')}
                      className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-2 transition-all ${
                        activePreviewTab === 'whatsapp'
                          ? 'bg-white text-emerald-700 shadow-sm border border-slate-200'
                          : 'text-slate-500 hover:text-slate-700'
                      }`}
                    >
                      <MessageSquare className="w-4 h-4" />
                      WhatsApp
                    </button>
                    <button
                      onClick={() => setActivePreviewTab('email')}
                      className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-2 transition-all ${
                        activePreviewTab === 'email'
                          ? 'bg-white text-blue-700 shadow-sm border border-slate-200'
                          : 'text-slate-500 hover:text-slate-700'
                      }`}
                    >
                      <Mail className="w-4 h-4" />
                      Email
                    </button>
                  </div>
                )}

                <div className="p-5 bg-slate-100/50 flex justify-center min-h-[400px]">
                  {(commType === 'WhatsApp' || (commType === 'Both' && activePreviewTab === 'whatsapp')) ? (
                    
                    /* WhatsApp Simulation */
                    <div className="w-full max-w-sm bg-[#efeae2] rounded-2xl overflow-hidden border border-slate-200 shadow-md flex flex-col font-sans">
                      <div className="bg-[#00a884] text-white p-3 flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center font-bold text-sm">T</div>
                        <div className="flex-1">
                          <p className="text-sm font-bold leading-none">Taxcom Technologies</p>
                          <p className="text-[10px] text-white/80 mt-1">Official Account</p>
                        </div>
                      </div>
                      <div className="p-4 flex-1 space-y-4">
                        <div className="bg-white rounded-lg p-2 mx-auto w-fit text-[10px] text-slate-500 font-medium">Today</div>
                        <div className="bg-[#d9fdd3] rounded-lg rounded-tr-none p-3 shadow-sm ml-auto max-w-[85%] text-slate-800 text-sm">
                          {formatWhatsAppBody(body)}
                          <div className="flex justify-end text-[10px] text-slate-500 mt-1">
                            12:45 PM <span className="text-blue-500 ml-1">✓✓</span>
                          </div>
                        </div>
                      </div>
                    </div>

                  ) : (
                    
                    /* Email Simulation */
                    <div className="w-full bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-md flex flex-col font-sans">
                      <div className="bg-slate-50 border-b border-slate-100 p-3 flex gap-1.5">
                        <div className="w-3 h-3 rounded-full bg-rose-400"></div>
                        <div className="w-3 h-3 rounded-full bg-amber-400"></div>
                        <div className="w-3 h-3 rounded-full bg-emerald-400"></div>
                      </div>
                      <div className="p-4 border-b border-slate-100 space-y-2 text-sm text-slate-600 bg-slate-50/50">
                        <div><span className="font-semibold w-12 inline-block">From:</span> noreply@taxcom.co.in</div>
                        <div><span className="font-semibold w-12 inline-block">To:</span> {SAMPLE_VALUES.clientName}</div>
                        <div className="pt-2 border-t border-slate-200 text-slate-900 font-bold">
                          {renderPreview(subject)}
                        </div>
                      </div>
                      <div className="p-6 text-sm">
                        {formatEmailBody(body)}
                      </div>
                    </div>

                  )}
                </div>
              </div>
              
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
