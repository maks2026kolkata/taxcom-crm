import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Grid,
  List
} from 'lucide-react';
import { getTasks,
  getClientById, getClients, getStaff } from '../db/storage';
import { ComplianceTask } from '../types';

export default function CalendarView() {
  const [tasks, setTasks] = useState<ComplianceTask[]>(() => getTasks());

  React.useEffect(() => {
    const handleSync = () => {
      setTasks(getTasks());
    };
    window.addEventListener('database-sync', handleSync);
    return () => window.removeEventListener('database-sync', handleSync);
  }, []);
  const clientsList = getClients();
  const staffList = getStaff();

  // Calendar State
  const [currentDate, setCurrentDate] = useState(new Date()); // Defaults to actual current system month/year
  const [viewMode, setViewMode] = useState<'month' | 'week'>('month');

  // Filters State
  const [filterClient, setFilterClient] = useState('All');
  const [filterStaff, setFilterStaff] = useState('All');
  const [filterCategory, setFilterCategory] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');
  const [filterPriority, setFilterPriority] = useState('All');

  // Helper date generators
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay(); // 0 = Sunday, 1 = Monday, etc.
  };

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const handleToday = () => {
    setCurrentDate(new Date());
  };

  // Filter tasks
  const filteredTasks = tasks.filter((t) => {
    if (t.isDeleted) return false;
    const matchClient = filterClient === 'All' || t.clientId === filterClient;
    const matchStaff = filterStaff === 'All' || t.assignedStaffId === filterStaff;
    const matchCategory = filterCategory === 'All' || t.serviceCategory === filterCategory;
    const matchStatus = filterStatus === 'All' || t.status === filterStatus;
    const matchPriority = filterPriority === 'All' || t.priority === filterPriority;

    return matchClient && matchStaff && matchCategory && matchStatus && matchPriority;
  });

  // Check color mapping for tasks
  const getTaskColorClass = (task: ComplianceTask) => {
    const today = new Date();
    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    if (task.status === 'Completed' || task.status === 'Filed') {
      return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    }
    if (task.dueDate < todayStr) {
      return 'bg-rose-50 text-rose-700 border-rose-200';
    }
    if (task.dueDate === todayStr) {
      return 'bg-amber-50 text-amber-700 border-amber-200';
    }
    return 'bg-blue-50 text-blue-700 border-blue-200';
  };

  // Render Month Calendar Layout
  const renderMonthGrid = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);

    const blanks = Array(firstDay).fill(null);
    const days: (number | null)[] = [...blanks];
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i);
    }

    // chunk days into weeks (rows of 7)
    const rows: (number | null)[][] = [];
    let activeRow: (number | null)[] = [];
    days.forEach((day, index) => {
      activeRow.push(day);
      if (activeRow.length === 7 || index === days.length - 1) {
        // fill out last row
        while (activeRow.length < 7) activeRow.push(null);
        rows.push(activeRow);
        activeRow = [];
      }
    });

    const today = new Date();
    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

    return (
      <div className="border border-slate-200 rounded-xl bg-white shadow-xs overflow-x-auto">
        <div className="w-full min-w-[700px]">
          <div className="grid grid-cols-7 bg-slate-50 border-b border-slate-200 text-center font-semibold text-[10px] md:text-xs py-2 text-slate-500 uppercase tracking-wider">
            <div><span className="hidden md:inline">Sunday</span><span className="md:hidden">S</span></div>
            <div><span className="hidden md:inline">Monday</span><span className="md:hidden">M</span></div>
            <div><span className="hidden md:inline">Tuesday</span><span className="md:hidden">T</span></div>
            <div><span className="hidden md:inline">Wednesday</span><span className="md:hidden">W</span></div>
            <div><span className="hidden md:inline">Thursday</span><span className="md:hidden">T</span></div>
            <div><span className="hidden md:inline">Friday</span><span className="md:hidden">F</span></div>
            <div><span className="hidden md:inline">Saturday</span><span className="md:hidden">S</span></div>
          </div>
          <div className="divide-y divide-slate-200">
            {rows.map((row, rowIdx) => (
              <div key={rowIdx} className="grid grid-cols-7 divide-x divide-slate-200 min-h-[80px] md:min-h-[100px]">
                {row.map((day, dayIdx) => {
                  if (day === null) {
                    return <div key={dayIdx} className="bg-slate-50/50 p-1 md:p-2"></div>;
                  }

                  const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                  const dayTasks = filteredTasks.filter(t => t.dueDate === dateStr);
                  const isToday = dateStr === todayStr;

                  return (
                    <div key={dayIdx} className={`p-2 space-y-1.5 flex flex-col justify-between ${isToday ? 'bg-amber-50/20' : ''}`}>
                      <div className="flex items-center justify-between">
                        <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${
                          isToday ? 'bg-[#F5405E] text-white font-extrabold shadow-sm' : 'text-slate-600'
                        }`}>
                          {day}
                        </span>
                        {isToday && <span className="text-[8px] font-bold text-[#F5405E] uppercase animate-pulse">Today</span>}
                      </div>

                      <div className="flex-1 space-y-1 overflow-y-auto max-h-[80px] pt-1">
                        {dayTasks.map((task) => (
                          <div
                            key={task.id}
                            className={`text-[9px] px-1.5 py-1 rounded border leading-tight truncate font-semibold cursor-pointer hover:shadow-xs transition-shadow ${getTaskColorClass(task)}`}
                            title={`${getClientById(task.clientId)?.name || task.clientName}: ${task.returnName}`}
                          >
                            {(getClientById(task.clientId)?.name || task.clientName).split(' ')[0]} – {task.returnName.split(' ')[0]}
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  // Render Weekly layout dynamically focused on the week containing currentDate
  const renderWeekGrid = () => {
    const current = new Date(currentDate);
    const dayOfWeek = current.getDay();
    const sunday = new Date(current);
    sunday.setDate(current.getDate() - dayOfWeek);

    const weekDays = Array.from({ length: 7 }, (_, i) => {
      const d = new Date(sunday);
      d.setDate(sunday.getDate() + i);
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const dateVal = String(d.getDate()).padStart(2, '0');
      const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      return {
        name: dayNames[i],
        date: `${year}-${month}-${dateVal}`,
        label: String(d.getDate())
      };
    });

    const today = new Date();
    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

    return (
      <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
        {weekDays.map((wd) => {
          const dayTasks = filteredTasks.filter(t => t.dueDate === wd.date);
          const isToday = wd.date === todayStr;
          return (
            <div key={wd.date} className={`p-4 rounded-xl border bg-white shadow-xs min-h-[300px] flex flex-col justify-between ${
              isToday ? 'border-[#F5405E] ring-1 ring-[#F5405E]/20' : 'border-slate-200'
            }`}>
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{wd.name}</span>
                  <span className={`text-md font-black px-2 py-0.5 rounded ${
                    isToday ? 'bg-[#F5405E] text-white' : 'text-slate-700 bg-slate-100'
                  }`}>
                    {wd.label}
                  </span>
                </div>

                <div className="space-y-2 mt-3 flex-1 overflow-y-auto max-h-[220px]">
                  {dayTasks.length === 0 ? (
                    <span className="text-[10px] text-slate-300 italic block py-2">No deadlines</span>
                  ) : (
                    dayTasks.map((task) => (
                      <div
                        key={task.id}
                        className={`p-2.5 rounded-lg border text-xs font-bold leading-normal shadow-2xs ${getTaskColorClass(task)}`}
                      >
                        <span className="text-[9px] uppercase tracking-wider font-extrabold block text-rose-500 mb-0.5">
                          {task.serviceCategory}
                        </span>
                        <strong className="block truncate">{getClientById(task.clientId)?.name || task.clientName}</strong>
                        <span className="block font-medium text-slate-500 text-[10px] truncate mt-0.5">{task.returnName}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {isToday && (
                <div className="mt-3 bg-rose-50 text-[10px] font-bold text-[#F5405E] p-1 text-center rounded">
                  ★ Current Focus Day
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  const monthsList = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const serviceCategories = [
    'GST', 'Income Tax', 'TDS', 'MCA or ROC', 'LLP Compliance',
    'FSSAI', 'PF', 'ESI', 'Professional Tax', 'Trade Licence',
    'DSC Renewal', 'Udyam', 'IEC', 'Trademark', 'Custom Service'
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center">
            <CalendarIcon className="w-6 h-6 mr-2.5 text-[#F5405E]" />
            Taxcom Technologies Compliance Calendar
          </h1>
          <p className="text-xs text-slate-500">
            Interactive monthly and weekly planning views mapped to regulatory compliance deadlines.
          </p>
        </div>

        {/* Calendar Navigation and View Switcher */}
        <div className="flex items-center gap-2">
          <div className="inline-flex rounded-lg border border-slate-200 bg-white p-1">
            <button
              onClick={() => setViewMode('month')}
              className={`px-3 py-1.5 text-xs font-bold rounded-md flex items-center ${
                viewMode === 'month' ? 'bg-[#F5405E] text-white' : 'text-slate-600 hover:text-slate-800'
              }`}
            >
              <Grid className="w-3.5 h-3.5 mr-1" />
              Monthly Grid
            </button>
            <button
              onClick={() => setViewMode('week')}
              className={`px-3 py-1.5 text-xs font-bold rounded-md flex items-center ${
                viewMode === 'week' ? 'bg-[#F5405E] text-white' : 'text-slate-600 hover:text-slate-800'
              }`}
            >
              <List className="w-3.5 h-3.5 mr-1" />
              Weekly Columns
            </button>
          </div>

          <button
            onClick={handleToday}
            className="px-3 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
          >
            Today
          </button>
        </div>
      </div>

      {/* Interactive Filters Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        <div>
          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Client Filter</label>
          <select
            value={filterClient}
            onChange={(e) => setFilterClient(e.target.value)}
            className="block w-full text-xs border border-slate-300 rounded-lg p-2 bg-white"
          >
            <option value="All">All Clients</option>
            {clientsList.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Staff Filter</label>
          <select
            value={filterStaff}
            onChange={(e) => setFilterStaff(e.target.value)}
            className="block w-full text-xs border border-slate-300 rounded-lg p-2 bg-white"
          >
            <option value="All">All Staff</option>
            {staffList.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Compliance type</label>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="block w-full text-xs border border-slate-300 rounded-lg p-2 bg-white"
          >
            <option value="All">All Compliances</option>
            {serviceCategories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Filing status</label>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="block w-full text-xs border border-slate-300 rounded-lg p-2 bg-white"
          >
            <option value="All">All Statuses</option>
            <option value="Not Started">Not Started</option>
            <option value="Documents Pending">Documents Pending</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed / Filed</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Priority filter</label>
          <select
            value={filterPriority}
            onChange={(e) => setFilterPriority(e.target.value)}
            className="block w-full text-xs border border-slate-300 rounded-lg p-2 bg-white"
          >
            <option value="All">All Priorities</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
            <option value="Urgent">Urgent</option>
          </select>
        </div>
      </div>

      {/* Calendar Header with navigation labels */}
      {viewMode === 'month' && (
        <div className="flex items-center justify-between bg-white px-5 py-3 rounded-xl border border-slate-200 shadow-2xs">
          <h2 className="text-md font-bold text-slate-900 flex items-center">
            {monthsList[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h2>
          <div className="flex items-center space-x-1.5">
            <button
              onClick={handlePrevMonth}
              className="p-1.5 hover:bg-slate-100 rounded-lg border border-slate-200"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleNextMonth}
              className="p-1.5 hover:bg-slate-100 rounded-lg border border-slate-200"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Colour indicators legend */}
      <div className="p-3 bg-slate-100/50 border border-slate-200/50 rounded-lg flex flex-wrap gap-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">
        <span className="flex items-center">
          <span className="w-3 h-3 bg-rose-100 border border-rose-300 rounded-md mr-1.5 inline-block"></span>
          Overdue Deadline
        </span>
        <span className="flex items-center">
          <span className="w-3 h-3 bg-amber-100 border border-amber-300 rounded-md mr-1.5 inline-block"></span>
          Due Today
        </span>
        <span className="flex items-center">
          <span className="w-3 h-3 bg-blue-100 border border-blue-300 rounded-md mr-1.5 inline-block"></span>
          Upcoming Deadline
        </span>
        <span className="flex items-center">
          <span className="w-3 h-3 bg-emerald-100 border border-emerald-300 rounded-md mr-1.5 inline-block"></span>
          Completed / Filed
        </span>
      </div>

      {/* Calendar Rendering container */}
      <div>
        {viewMode === 'month' ? renderMonthGrid() : renderWeekGrid()}
      </div>

    </div>
  );
}
