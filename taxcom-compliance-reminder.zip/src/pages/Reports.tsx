import React, { useState, useRef } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import {
  TrendingUp,
  FileText,
  BarChart2,
  Calendar,
  AlertTriangle,
  History,
  CheckCircle,
  Download,
  Printer,
  ChevronRight,
  TrendingDown
} from 'lucide-react';
import { getTasks, getReminderHistory, getClients, getClientById } from '../db/storage';
import { ComplianceTask, ReminderHistoryItem } from '../types';
import { useToast } from '../components/Toast';

export default function Reports() {
  const { showToast } = useToast();
  const [tasks, setTasks] = useState<ComplianceTask[]>(() => getTasks());
  const [history, setHistory] = useState<ReminderHistoryItem[]>(() => getReminderHistory());
  const reportRef = useRef<HTMLDivElement>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  React.useEffect(() => {
    const handleSync = () => {
      setTasks(getTasks());
      setHistory(getReminderHistory());
    };
    window.addEventListener('database-sync', handleSync);
    return () => window.removeEventListener('database-sync', handleSync);
  }, []);
  const clientsList = getClients();

  // Active Report Tab Selection
  const [activeReportTab, setActiveReportTab] = useState<'overdue' | 'client' | 'outstanding' | 'history'>('overdue');

  // Filter criteria states
  const [clientFilter, setClientFilter] = useState('All');

  // Get current system date in YYYY-MM-DD format
  const getFormattedDateTime = () => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    let hours = d.getHours();
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    const formattedHours = String(hours).padStart(2, '0');
    return {
      todayStr: `${year}-${month}-${day}`,
      formattedDateTime: `${year}-${month}-${day} ${formattedHours}:${minutes} ${ampm}`
    };
  };
  const { todayStr, formattedDateTime } = getFormattedDateTime();

  // Report compilations
  const overdueTasksList = tasks.filter(t => !t.isDeleted && t.status !== 'Completed' && t.status !== 'Filed' && t.dueDate < todayStr);
  
  const clientWiseSummaries = clientsList.map(c => {
    const clientTasks = tasks.filter(t => !t.isDeleted && t.clientId === c.id);
    const total = clientTasks.length;
    const completed = clientTasks.filter(t => t.status === 'Completed' || t.status === 'Filed').length;
    const pending = total - completed;
    const totalBilled = clientTasks.reduce((sum, t) => sum + t.professionalFees, 0);
    const totalOwed = clientTasks.reduce((sum, t) => sum + t.outstandingAmount, 0);

    return {
      clientId: c.clientId,
      name: c.name,
      totalCount: total,
      completedCount: completed,
      pendingCount: pending,
      billingTotal: totalBilled,
      outstandingTotal: totalOwed,
    };
  });

  const outstandingFeesList = tasks.filter(t => !t.isDeleted && t.outstandingAmount > 0);

  const handlePrint = async () => {
    if (!reportRef.current) return;
    try {
      setIsGeneratingPdf(true);
      showToast("Generating PDF... Please wait", "success");
      
      const canvas = await html2canvas(reportRef.current, {
        scale: 2,
        useCORS: true,
        logging: false
      });
      
      const imgWidth = 210; // A4 width in mm
      const pageHeight = 297; // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      
      const doc = new jsPDF('p', 'mm');
      let position = 0;
      
      doc.addImage(canvas.toDataURL('image/jpeg', 1.0), 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
      
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        doc.addPage();
        doc.addImage(canvas.toDataURL('image/jpeg', 1.0), 'JPEG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      
      doc.save(`Taxcom_Report_${new Date().toISOString().split('T')[0]}.pdf`);
      showToast("PDF generated successfully", "success");
    } catch (err) {
      console.error("PDF generation failed:", err);
      showToast("Failed to generate PDF. Please try again.", "error");
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // CSV exports for specific report tabs
  const handleExportCSV = () => {
    let csvRows: any[][] = [];
    let filename = 'taxcom_report.csv';

    if (activeReportTab === 'overdue') {
      filename = 'taxcom_overdue_compliance_report.csv';
      csvRows = [
        ['Client Name', 'Category', 'Form/Return Name', 'Period', 'Filing Due Date', 'Outstanding Docs'],
        ...overdueTasksList.map(t => [
          getClientById(t.clientId)?.name || t.clientName,
          t.serviceCategory,
          t.returnName,
          t.filingPeriod,
          t.dueDate,
          t.documentsPending.join(', ') || 'None'
        ])
      ];
    } else if (activeReportTab === 'client') {
      filename = 'taxcom_client_wise_compliance_totals.csv';
      csvRows = [
        ['Client ID', 'Client Legal Name', 'Total Tasks', 'Completed', 'Pending', 'Billed Fees (₹)', 'Owed Balance (₹)'],
        ...clientWiseSummaries.map(c => [
          c.clientId,
          c.name,
          c.totalCount.toString(),
          c.completedCount.toString(),
          c.pendingCount.toString(),
          c.billingTotal.toString(),
          c.outstandingTotal.toString()
        ])
      ];
    } else if (activeReportTab === 'outstanding') {
      filename = 'taxcom_outstanding_ledgers_report.csv';
      csvRows = [
        ['Client Name', 'Filing Return', 'Filing Due Date', 'Billed Fees (₹)', 'Collected (₹)', 'Outstanding Due (₹)'],
        ...outstandingFeesList.map(t => [
          getClientById(t.clientId)?.name || t.clientName,
          t.returnName,
          t.dueDate,
          t.professionalFees.toString(),
          t.amountReceived.toString(),
          t.outstandingAmount.toString()
        ])
      ];
    } else if (activeReportTab === 'history') {
      filename = 'taxcom_reminder_dispatch_audit_trail.csv';
      csvRows = [
        ['Date/Time Sent', 'Client Name', 'Filing Task Name', 'Sent Method', 'Dispatched By', 'Remarks/Feedback'],
        ...history.map(h => [
          h.sentDateTime,
          getClientById(h.clientId)?.name || h.clientName,
          h.taskName,
          h.sentMethod,
          h.sentBy,
          h.remarks
        ])
      ];
    }

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      csvRows.map((e) => e.map((val) => `"${val.replace(/"/g, '""')}"`).join(',')).join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Report downloaded as CSV spreadsheet!', 'success');
  };

  return (
    <div ref={reportRef} className="space-y-6 animate-in fade-in duration-200 bg-slate-50 p-2 sm:p-0">
      
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0 print:hidden">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center">
            <BarChart2 className="w-6 h-6 mr-2.5 text-[#F5405E]" />
            Taxcom Technologies Compliance Reports & Auditing
          </h1>
          <p className="text-xs text-slate-500">
            Generate and export printable compliance metrics, collection rates, and staff-generated reminder histories.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handlePrint}
            disabled={isGeneratingPdf}
            className="inline-flex items-center justify-center h-10 px-3.5 text-xs font-bold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 shadow-2xs cursor-pointer transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Printer className={`w-4 h-4 mr-1.5 text-slate-500 shrink-0 ${isGeneratingPdf ? 'animate-pulse' : ''}`} />
            {isGeneratingPdf ? 'Generating PDF...' : 'Print Report'}
          </button>
          
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center justify-center h-10 px-4 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm cursor-pointer transition-colors"
          >
            <Download className="w-4 h-4 mr-1.5 shrink-0" />
            Export CSV
          </button>
        </div>
      </div>

      {/* Tabs list selector buttons */}
      <div className="flex overflow-x-auto whitespace-nowrap gap-2 border-b border-slate-200 pb-px print:hidden scrollbar-none">
        <button
          onClick={() => setActiveReportTab('overdue')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer ${
            activeReportTab === 'overdue'
              ? 'border-b-[#F5405E] text-[#F5405E]'
              : 'border-b-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Overdue Compliance Deadlines
        </button>
        <button
          onClick={() => setActiveReportTab('client')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer ${
            activeReportTab === 'client'
              ? 'border-b-[#F5405E] text-[#F5405E]'
              : 'border-b-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Client-wise Status Summary
        </button>
        <button
          onClick={() => setActiveReportTab('outstanding')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer ${
            activeReportTab === 'outstanding'
              ? 'border-b-[#F5405E] text-[#F5405E]'
              : 'border-b-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Outstanding Fee Ledgers
        </button>
        <button
          onClick={() => setActiveReportTab('history')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer ${
            activeReportTab === 'history'
              ? 'border-b-[#F5405E] text-[#F5405E]'
              : 'border-b-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Dispatch & Contact Audit Trail
        </button>
      </div>

      {/* Active Report Rendering table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden p-6 space-y-4">
        
        {/* Print only watermark header */}
        <div className="hidden print:block text-center space-y-1 pb-6 border-b border-slate-300">
          <h2 className="text-xl font-extrabold text-slate-900 uppercase">Taxcom Technologies LLP</h2>
          <p className="text-xs text-slate-500">Legal Made Easy | Official Internal Audit Report</p>
          <p className="text-[10px] text-slate-400">Generated on: {formattedDateTime} | Confidential</p>
        </div>

        {activeReportTab === 'overdue' && (
          <div className="space-y-4">
            <h3 className="text-sm font-extrabold text-rose-600 flex items-center">
              <AlertTriangle className="w-4 h-4 mr-1.5 animate-pulse" />
              Critical Overdue dead-lines checklist (Filing date prior to {todayStr})
            </h3>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
                    <th className="py-2.5 px-3">Client Legal Name</th>
                    <th className="py-2.5 px-3">Category</th>
                    <th className="py-2.5 px-3">Filing Return Name</th>
                    <th className="py-2.5 px-3">Period</th>
                    <th className="py-2.5 px-3">Due Date</th>
                    <th className="py-2.5 px-3">Documents Pending</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {overdueTasksList.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400 italic">No compliance forms are currently overdue! Amazing work.</td>
                    </tr>
                  ) : (
                    overdueTasksList.map(t => (
                      <tr key={t.id} className="hover:bg-slate-50/50">
                        <td className="py-3 px-3 font-bold text-slate-900">{getClientById(t.clientId)?.name || t.clientName}</td>
                        <td className="py-3 px-3 font-semibold text-rose-600">{t.serviceCategory}</td>
                        <td className="py-3 px-3 font-semibold text-slate-800">{t.returnName}</td>
                        <td className="py-3 px-3 text-slate-600">{t.filingPeriod}</td>
                        <td className="py-3 px-3 font-bold text-rose-600">{t.dueDate}</td>
                        <td className="py-3 px-3 font-medium text-slate-500">
                          {t.documentsPending.join(', ') || <span className="text-emerald-600">None</span>}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeReportTab === 'client' && (
          <div className="space-y-4">
            <h3 className="text-sm font-extrabold text-slate-800">
              Aggregated Client-wise Compliance and Account Totals
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
                    <th className="py-2.5 px-3">Client ID</th>
                    <th className="py-2.5 px-3">Client Legal Name</th>
                    <th className="py-2.5 px-3 text-center">Total Tasks</th>
                    <th className="py-2.5 px-3 text-center">Completed</th>
                    <th className="py-2.5 px-3 text-center">Pending</th>
                    <th className="py-2.5 px-3">Billed Fees (₹)</th>
                    <th className="py-2.5 px-3">Owed Balance (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {clientWiseSummaries.map(c => (
                    <tr key={c.clientId} className="hover:bg-slate-50/50">
                      <td className="py-3 px-3 font-mono font-bold text-slate-500">{c.clientId}</td>
                      <td className="py-3 px-3 font-bold text-slate-900">{c.name}</td>
                      <td className="py-3 px-3 text-center font-bold text-slate-700">{c.totalCount}</td>
                      <td className="py-3 px-3 text-center font-bold text-emerald-600">{c.completedCount}</td>
                      <td className="py-3 px-3 text-center font-bold text-rose-600">{c.pendingCount}</td>
                      <td className="py-3 px-3 font-semibold text-slate-700">₹{c.billingTotal}</td>
                      <td className="py-3 px-3 font-bold text-[#F5405E] bg-rose-50/10">₹{c.outstandingTotal}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeReportTab === 'outstanding' && (
          <div className="space-y-4">
            <h3 className="text-sm font-extrabold text-[#F5405E]">
              Client Professional Fee Balance Ledgers
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
                    <th className="py-2.5 px-3">Client Name</th>
                    <th className="py-2.5 px-3">Filing Return</th>
                    <th className="py-2.5 px-3">Due Date</th>
                    <th className="py-2.5 px-3">Billed Fee</th>
                    <th className="py-2.5 px-3">Collected Amount</th>
                    <th className="py-2.5 px-3">Outstanding Balance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {outstandingFeesList.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400 italic">All professional accounts are completely cleared!</td>
                    </tr>
                  ) : (
                    outstandingFeesList.map(t => (
                      <tr key={t.id} className="hover:bg-slate-50/50">
                        <td className="py-3 px-3 font-bold text-slate-900">{getClientById(t.clientId)?.name || t.clientName}</td>
                        <td className="py-3 px-3 font-semibold text-slate-700">{t.returnName}</td>
                        <td className="py-3 px-3 text-slate-500">{t.dueDate}</td>
                        <td className="py-3 px-3 font-semibold text-slate-700">₹{t.professionalFees}</td>
                        <td className="py-3 px-3 font-semibold text-emerald-600">₹{t.amountReceived}</td>
                        <td className="py-3 px-3 font-bold text-rose-600 bg-rose-50/30">₹{t.outstandingAmount}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeReportTab === 'history' && (
          <div className="space-y-4">
            <h3 className="text-sm font-extrabold text-emerald-600 flex items-center">
              <CheckCircle className="w-4 h-4 mr-1.5" />
              Client Dispatch Communication Audit Trail Logs
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
                    <th className="py-2.5 px-3">Date/Time Sent</th>
                    <th className="py-2.5 px-3">Client Name</th>
                    <th className="py-2.5 px-3">Filing Return Form</th>
                    <th className="py-2.5 px-3">Channel Method</th>
                    <th className="py-2.5 px-3">Dispatched By</th>
                    <th className="py-2.5 px-3">Audit Remarks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {history.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400 italic">No communication dispatches recorded yet in this session.</td>
                    </tr>
                  ) : (
                    history.map((h, i) => (
                      <tr key={i} className="hover:bg-slate-50/50">
                        <td className="py-3 px-3 text-slate-500">{h.sentDateTime}</td>
                        <td className="py-3 px-3 font-bold text-slate-900">{getClientById(h.clientId)?.name || h.clientName}</td>
                        <td className="py-3 px-3 font-semibold text-slate-700">{h.taskName}</td>
                        <td className="py-3 px-3">
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                            h.sentMethod === 'WhatsApp'
                              ? 'bg-emerald-100 text-emerald-800'
                              : h.sentMethod === 'Email'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-slate-100 text-slate-800'
                          }`}>
                            {h.sentMethod}
                          </span>
                        </td>
                        <td className="py-3 px-3 font-semibold text-slate-600">{h.sentBy}</td>
                        <td className="py-3 px-3 text-slate-500 italic max-w-[200px] truncate" title={h.remarks}>{h.remarks}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

      </div>

    </div>
  );
}
