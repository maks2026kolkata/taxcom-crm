import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';

admin.initializeApp();

const db = admin.firestore();
const fcm = admin.messaging();

/**
 * Scheduled Cloud Function running daily at 8:00 AM Asia/Kolkata
 * Timezone Cron representation in UTC:
 * 8:00 AM IST is 2:30 AM UTC (IST is UTC + 5:30)
 * Cron: '30 2 * * *'
 */
export const taxcomDailyComplianceCheck = functions.pubsub
  .schedule('30 2 * * *')
  .timeZone('Asia/Kolkata')
  .onRun(async (context) => {
    console.log('Starting Taxcom Technologies Daily Compliance Check...');
    
    // 1. Fetch incomplete tasks
    const incompleteStatuses = [
      'Not Started',
      'Documents Pending',
      'Client Confirmation Pending',
      'In Progress',
      'Ready to File',
      'On Hold'
    ];

    const tasksSnapshot = await db.collection('tasks')
      .where('isDeleted', '!=', true)
      .where('status', 'in', incompleteStatuses)
      .get();

    if (tasksSnapshot.empty) {
      console.log('No active incomplete tasks found.');
      return null;
    }

    // 2. Fetch active settings for reminders
    const settingsSnapshot = await db.collection('reminder_settings').get();
    const enabledIntervals: string[] = [];
    settingsSnapshot.forEach(doc => {
      if (doc.data().enabled) {
        enabledIntervals.push(doc.data().interval);
      }
    });

    console.log(`Enabled reminder intervals: ${enabledIntervals.join(', ')}`);

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStr = today.toISOString().split('T')[0];

    let remindersCreated = 0;

    for (const doc of tasksSnapshot.docs) {
      const task = doc.data();
      const taskId = doc.id;
      const dueDateStr = task.dueDate; // Format YYYY-MM-DD
      const dueDate = new Date(dueDateStr);
      dueDate.setHours(0, 0, 0, 0);

      // Diff in days (dueDate - today)
      const diffTime = dueDate.getTime() - today.getTime();
      const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

      let matchedInterval: string | null = null;

      if (diffDays === 15) matchedInterval = '15 days before';
      else if (diffDays === 7) matchedInterval = '7 days before';
      else if (diffDays === 3) matchedInterval = '3 days before';
      else if (diffDays === 1) matchedInterval = '1 day before';
      else if (diffDays === 0) matchedInterval = 'On the due date';
      else if (diffDays < 0) matchedInterval = 'Daily after becoming overdue';

      if (!matchedInterval || !enabledIntervals.includes(matchedInterval)) {
        continue;
      }

      // 3. Check for duplicates (same task, same interval, and if daily-overdue: created today)
      const duplicateQuery = db.collection('reminders')
        .where('taskId', '==', taskId)
        .where('intervalType', '==', matchedInterval);

      const dupSnapshot = await duplicateQuery.get();
      let isDuplicate = false;

      if (!dupSnapshot.empty) {
        if (matchedInterval === 'Daily after becoming overdue') {
          // Check if any was created today
          dupSnapshot.forEach(dupDoc => {
            const dupCreatedDateStr = dupDoc.data().createdAt.split('T')[0];
            if (dupCreatedDateStr === todayStr) {
              isDuplicate = true;
            }
          });
        } else {
          isDuplicate = true;
        }
      }

      if (isDuplicate) {
        console.log(`Duplicate found for Task ${taskId} with interval "${matchedInterval}". Skipping.`);
        continue;
      }

      // 4. Create reminder document
      const reminderRef = db.collection('reminders').doc();
      const newReminder = {
        id: reminderRef.id,
        taskId,
        taskName: task.returnName,
        clientId: task.clientId,
        clientName: task.clientName,
        serviceCategory: task.serviceCategory,
        dueDate: task.dueDate,
        intervalType: matchedInterval,
        status: 'Pending',
        createdAt: new Date().toISOString(),
      };

      await reminderRef.set(newReminder);
      remindersCreated++;

      // 5. Audit Log Entry
      const auditRef = db.collection('audit_logs').doc();
      await auditRef.set({
        id: auditRef.id,
        action: 'System Reminder Auto-Run',
        targetId: taskId,
        targetName: task.returnName,
        userId: 'system',
        userName: 'Scheduled 8:00 AM IST Cron',
        timestamp: new Date().toISOString(),
        newValue: `Automatically generated reminder "${matchedInterval}" for ${task.clientName}`
      });

      // 6. Send Push Notification via FCM to the assigned staff member
      const staffId = task.assignedStaffId;
      if (!staffId) continue;

      // Fetch staff push tokens
      const staffTokensSnapshot = await db.collection('staff_tokens')
        .where('staffId', '==', staffId)
        .get();

      if (staffTokensSnapshot.empty) {
        console.log(`No push tokens found for staff ${staffId}.`);
        continue;
      }

      const tokens: string[] = [];
      staffTokensSnapshot.forEach(tokenDoc => {
        tokens.push(tokenDoc.data().token);
      });

      const payload = {
        notification: {
          title: 'Taxcom Technologies CRM',
          body: `${task.clientName} – ${task.returnName} is due in ${diffDays >= 0 ? diffDays + ' days' : Math.abs(diffDays) + ' days (OVERDUE)'}.`,
        },
        data: {
          url: `/reminders?id=${reminderRef.id}`,
          click_action: 'FLUTTER_NOTIFICATION_CLICK' // Standard trigger for actions
        }
      };

      try {
        const response = await fcm.sendMulticast({
          tokens,
          notification: payload.notification,
          data: payload.data
        });
        console.log(`Push notifications sent successfully. Success: ${response.successCount}, Failure: ${response.failureCount}`);
      } catch (err) {
        console.error('Error sending push notifications via FCM:', err);
      }
    }

    console.log(`Compliance run completed. Generated ${remindersCreated} reminders.`);
    return null;
  });
